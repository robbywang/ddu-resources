/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.lc.ebsc;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import org.apache.log4j.Logger;

import com.nortel.cdma.comm.tcp.Utils;
import com.nortel.cdma.common.alarm.interfaces.AlarmDefinition;
import com.nortel.cdma.common.internationalization.CemsAlarmTextMessageCategory;
import com.nortel.cdma.common.internationalization.ProbableCauseMessageCategory;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.service.common.util.AlarmUtil;
import com.nortel.cdma.service.csl.lc.ebsc.xml.ElcParameterEnum;

/**
 * This class writes EBSC log records to the Stream Log Server(SLS).
 */
public class EBSCSocketDataWriter implements LogRecordWriter {
    /**
     * Instance of Log4j Logger.
     */
    private static final Logger log4jDebugLogger =
        Logger.getLogger(EBSCSocketDataWriter.class);

    /**
     * Destination host IP address.
     */
    private String mDestinationAddress;

    /**
     * Remote port to write to.
     */
    private int mOutPort;

    /**
     * Socket channel connecting to SLS.
     */
    private SocketChannel mSocketChannel = null;

    /**
     * The underlying socket connecting to SLS.
     */
    private Socket mSocket = null;

    /**
     * Retry interval for connecting to SLS.
     */
    private int mConnectRetryInterval;

    /**
     * Timeout in milliseconds for connecting to SLS.
     */
    private int mConnectTimeout;

    /**
     * Number of retries connecting to SLS before raising an alarm.
     */
    private int mConnectRetryAlarmThreshold;

    /**
     * set to true when Socket Data Writer is started.
     */
    private volatile boolean mIsStarted = false;

    /**
     * Flag indicating if an alarm has been raised. A null indicates that
     * the information is not available.
     */
    private Boolean  mAlarmHasBeenRaised = null;

    /**
     * Delay (in ms) between successive log messages indicating IO error on write.
     */
    private static final int IOERROR_DEBOUNCE_DELAY = 60000;

    /**
     *  Timestamp for IO error message debounce.
     */
    private long mlIOErrorTimestamp = 0L;

    /**
     * Constructor.
     *
     * @param configParams  The configuration parameters for EBSC log collector
     */
    public EBSCSocketDataWriter(EBSCLogCollectorParameters configParams) {
        mDestinationAddress = (String)configParams.getParameter(
            ElcParameterEnum.ipAddress);

        mOutPort = (Integer)configParams.getParameter(
            ElcParameterEnum.outPort);

        mConnectRetryInterval = (Integer)configParams.getParameter(
            ElcParameterEnum.connectRetryInterval);

        mConnectTimeout = (Integer)configParams.getParameter(
            ElcParameterEnum.connectTimeout);

        mConnectRetryAlarmThreshold = (Integer)configParams.getParameter(
            ElcParameterEnum.connectRetryAlarmThreshold);
    }

    /**
     * Starts up socket data writer.
     *
     * @throws InitializationFailureException if there is problem starting up
     */
    public void startup() throws InitializationFailureException {
        if (mIsStarted) {
            log4jDebugLogger.info("Already started, canceling startup request.");

            return;
        }

        mIsStarted = true;

        connectToSLS();

        log4jDebugLogger.info("Startup completed");
    }

    /**
     * Shuts down the socket data writer.
     */
    public void shutdown() {
        if (!mIsStarted) {
            log4jDebugLogger.info("Already down, canceling the shutdown request");

            return;
        }

        mIsStarted = false;
        closeSocket();

        log4jDebugLogger.info("Shutdown completed");
    }

    /**
     * Restart the socket data writer.
     */
    public void restart() {
        connectToSLS();
    }

    /**
     * Connects to SLS and raises an alarm after failing a predefined
     * number of tries.
     *
     */
    private synchronized void connectToSLS() {
        int     numRetries = 0;

        while( (mSocketChannel == null) && mIsStarted ) {
            boolean  operationSucceeded = false;

            try {
                mSocketChannel = SocketChannel.open();
                mSocket = mSocketChannel.socket();

                InetSocketAddress remoteAddress =
                    new InetSocketAddress(mDestinationAddress, mOutPort);

                mSocket.connect(remoteAddress, mConnectTimeout);

                // Disables Nagle's algorithm which buffers small packets
                // to improve performance
                mSocket.setTcpNoDelay(true);

                mSocketChannel.configureBlocking(false);

                operationSucceeded = true;
            }
            catch(IOException e) {
                log4jDebugLogger.error("Met I/O error trying to connect to SLS. "
                    + "Retry after some delay.", e);
            }
            finally {
                if(! operationSucceeded) {
                    closeSocket();
                }
            }

            if (operationSucceeded) {
                break;
            }

            numRetries++;

            if (log4jDebugLogger.isInfoEnabled()) {
                log4jDebugLogger.info("Failed on try number " + numRetries);
            }

            if (numRetries > mConnectRetryAlarmThreshold) {
                if (log4jDebugLogger.isInfoEnabled()) {
                    log4jDebugLogger.info("Failed number of tries = "
                        + numRetries + "(>" + mConnectRetryAlarmThreshold + "), "
                        + "Raise alarm.");
                }

                raiseOrClearAlarm(true);
            }

            // Perform predefine delay and try again.
            performDelay(mConnectRetryInterval);
        }

        if(mSocketChannel != null) {
            log4jDebugLogger.info("Connect to SLS succeeded");

            raiseOrClearAlarm(false);
        }
    }

    /**
     * Raises or clears an alarm when connection to SLS is closed or reopened.
     *
     * @param isRaise If true indicates a raise, otherwise a clear
     */
    private void raiseOrClearAlarm(boolean isRaise) {
        // If the alarm flag is null, raise or clear the alarm
        if (mAlarmHasBeenRaised != null &&
            isRaise == mAlarmHasBeenRaised) {
            // Nothing to do - the alarm has already been raised/cleared
            return;
        }

        String debugMsg = isRaise ? "Raise alarm" : "Clear alarm";
        log4jDebugLogger.info(debugMsg);

        int  alarmType  = AlarmDefinition.EVENT_TYPE_COMMUNICATIONS;

        int  severity   = AlarmDefinition.SEVERITY_MINOR;

        int  messageKey =
            CemsAlarmTextMessageCategory.CEMS_CSLProfile_2_0;

        int  probableCause =
            ProbableCauseMessageCategory.CONNECTION_ESTAB_ERROR;

        Object[]  args       = null;

        AlarmUtil alarmUtil = AlarmUtil.getInstance();
        if (alarmUtil.raiseOrClearAlarmOnCSLProfileME(isRaise, alarmType, severity,
            messageKey, probableCause, args)) {
            mAlarmHasBeenRaised = isRaise;
        }
        else {
            log4jDebugLogger.error("Unable to raise/clear alarm \"connection to"
                + " SLS is closed\"");
        }
    }

    /**
     * Performs the specified delay.
     *
     * @param delay  The delay in milliseconds
     */
    private void performDelay(int delay) {
        try {
            Thread.sleep(delay);
        }
        catch(InterruptedException e) {
            // Ignore
        }
    }

    /**
     * Closes the SLS socket connection.
     */
    private synchronized void closeSocket() {
        if (mSocket != null) {
            try {
                mSocket.close();
            }
            catch(IOException e) {
                log4jDebugLogger.error("Failed to close socket.", e);
            }
            mSocket = null;
        }


        if (mSocketChannel != null) {
            try {
                mSocketChannel.close();
            }
            catch(IOException e) {
                log4jDebugLogger.error("Failed to close socket channel.", e);
            }
            mSocketChannel = null;
        }

    }

    /**
     * Writes log data to the stream log server.
     * @param buf the buffer to write to the stream log server
     */
    public synchronized void writeByteBuffer(ByteBuffer buf) {

        if (!mIsStarted) {
            return;
        }

        // Second attempt is needed to avoid data loss on reconnect
        for (int iRetries = 2; iRetries > 0; iRetries--) {
            if (mSocketChannel == null) {  // May be null because of a shutdown
                return;
            }

            try {
                Utils.write(mSocketChannel, buf);
                return;
            }
            catch(IOException e) {
                long lCurrentTime = System.currentTimeMillis();

                if ((lCurrentTime - mlIOErrorTimestamp) > IOERROR_DEBOUNCE_DELAY) {

                    log4jDebugLogger.error("Error writing log record to the SLS, connection may be closed."
                        + "Attempting to reconnect.", e);
                    mlIOErrorTimestamp = lCurrentTime;
                }
            }

            closeSocket();
            connectToSLS();
        }
    }
}
