/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */
package com.nortel.cdma.service.csl.lc.ebsc;

import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.service.csl.common.CSLAttributeChangeEventFilter;
import com.nortel.cdma.service.csl.common.CSLEventManager;
import com.nortel.cdma.service.csl.common.UploadProfileCSLInfo;
import com.nortel.cdma.service.notification.Event;
import com.nortel.cdma.service.notification.NotificationException;

import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.elements.AttributeGroup;
import com.nortel.cdma.common.data.event.ManagedElementAttributeChangeEvent;
import com.nortel.cdma.common.InvalidArgumentException;
import com.nortel.cdma.gsf.ResourceUnavailableException;

import org.apache.log4j.Logger;

/**
 * This class describes an ELC event manager as how to  interact with Notification Service. That is,
 * subscribing the CSL related events, handling the incoming events and publishing the CSL events
 * if any.
 */

public class ELCEventManager extends CSLEventManager  {

  /**
   * A static field to hold the instance of this class.
   */
  private static ELCEventManager moInstance = null;

  /**
   * Instance of Log4j.Logger.
   */
  private final static Logger log4jDebugLogger = Logger.getLogger(ELCEventManager.class);

  /**
   * The writer used to write log records to SLS socket.
   */
  private EBSCSocketDataWriter mSocketDataWriter = null;

  /**
   * The reader used to read log records from the stream.
   */
  private EBSCSocketDataReader mSocketDataReader = null;

  /**
   * Get the singleton instance of the ELC EventManager.
   * @return CSLEventManager object instance
   */
  public static synchronized ELCEventManager getInstance() {
    if(moInstance == null) {
      moInstance = new ELCEventManager();
    }
    return moInstance;
  }

  /**
   * Creates an instance of this class.
   */
  public ELCEventManager() {
    super();
  }

  /**
   * Receives incoming events from Notification service.
   * Implementation of NotificationEventListener interface.
   * @param moEvent the received notification
   */
  public synchronized void handleNotificationEvent(Event moEvent) {

    if (moEvent == null) {
      log4jDebugLogger.error("Got null event");
      return;
    }
    if(moEvent instanceof ManagedElementAttributeChangeEvent) {

      ManagedElementAttributeChangeEvent event = (ManagedElementAttributeChangeEvent)moEvent;

      ManagedElement me = event.getManagedElement();
      if(me == null) {
        log4jDebugLogger.error("Got null event");
        return;
      }

      handleSpecificAttributeGroupUpdate(me);
    }
  }

  /**
   * Help method to subscribe CSL related events.
   * @throws com.nortel.cdma.gsf.ResourceUnavailableException
   */
  protected void subscribeEvents() throws ResourceUnavailableException {
    if (moNotificationServiceRef == null) {
      throw new ResourceUnavailableException("CSLEventManager:",
        "subscribeEvents()");
    }

    Exception moException = null;
    try {
      moNotificationServiceRef.subscribe(this,  new UploadProfileChangeEventFilter());
      moNotificationServiceRef.subscribe(this,  new CSLAttributeChangeEventFilter());
    }
    catch (ResourceUnavailableException e) {
      moException = e;
    }
    catch (InvalidArgumentException e) {
      moException = e;
    }
    catch (NotificationException e) {
      moException = e;
    }

    if (moException != null) {
      log4jDebugLogger.error("Unable to subscribe CSL related events", moException);
    }
  }

  /**
   * Set EBSCSocketDataWriter in order to handle attribute updates.
   * @param moEBSCSocketDataWriter the EBSCSocketDataWriter instance
   */
  public void setEBSCSocketDataWriter(EBSCSocketDataWriter moEBSCSocketDataWriter) {
    if (moEBSCSocketDataWriter == null) {
      log4jDebugLogger.error("got null EBSCSocketDataWriter");
    }
    else {
      mSocketDataWriter = moEBSCSocketDataWriter;
    }
  }

  /**
   * Set EBSCSocketDataReader in order to handle attribute updates.
   * @param moEBSCSocketDataReader the EBSCSocketDataWriter instance
   */
  public void setEBSCSocketDataReader(EBSCSocketDataReader moEBSCSocketDataReader) {
    if (moEBSCSocketDataReader == null) {
      log4jDebugLogger.error("got null EBSCSocketDataReader");
    }
    else {
      mSocketDataReader = moEBSCSocketDataReader;
    }
  }


  /**
   *  Retrieves the the updated attribute group from the desired ManagedElement
   *  and handles the changes.
   * @param me the ManagedElement object which contains the updated attribute group
   */
  protected void handleSpecificAttributeGroupUpdate (ManagedElement me) {

    UploadProfileCSLInfo oUPInfo = new UploadProfileCSLInfo (me);

    if (oUPInfo.isValid()) {
       short destPortId = oUPInfo.getDestinationPortId();

    if (mSocketDataReader != null) {
        mSocketDataReader.handleUploadProfileInfoUpdate(destPortId);
      }
    }

     /*
    //handle attribute change for CSLProfile.ATTGRP_OverloadFilter
    AttributeGroup oOverloadAttGrp = CSLUtil.getOverloadFilterGrpFrom(me);
    if (oOverloadAttGrp != null) {
      if (mSocketDataReader != null) {
        mSocketDataReader.updateOverloadAttributeFilter();
      }
    }
    */
  }
}


