/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.lc.ebsc;

/**
 * This interface defines a control message handler.
 */
public interface ControlMessageHandler {

  /**
   * This method handles the control message.
   *
   * @param msgCode  The message code
   * @param msgDescription  The message description
   */
  public void handleControlMessage(int msgCode, String msgDescription);
}