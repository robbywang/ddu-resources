/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved
 */

package com.nortel.cdma.service.csl.lc.ebsc;

import com.nortel.cdma.common.data.autogen.FQTN;
import com.nortel.cdma.common.data.autogen.LocalName;
import com.nortel.cdma.common.data.elements.FullyQualifiedTypeName;
import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.elements.AttributeGroup;
import com.nortel.cdma.common.data.event.ManagedElementAttributeChangeEvent;
import com.nortel.cdma.service.notification.Event;
import com.nortel.cdma.service.notification.EventFilter;
import com.nortel.cdma.service.csl.common.CSLUtil;
import org.apache.log4j.Logger;

/**
 * Filter class used to get ManagedElementAttributeChangeEvent.
 */
public class UploadProfileChangeEventFilter extends EventFilter {

  /**
   * Instance of Log4j.Logger.
   */
  private final static Logger log4jDebugLogger = Logger.getLogger(UploadProfileChangeEventFilter.class);

  /**
   * The event filter name.
   */
  private final static String EVENT_FILTER_NAME = "UploadProfileChangeEventFilter";

  /**
   * Constructor.
   */
  public UploadProfileChangeEventFilter() {
  }

  /**
   * Return the target ManagedElementAttributeChangeEvent class.
   * @return the event class
   */
  public Class getEventClass() {
    return ManagedElementAttributeChangeEvent.class;
  }

  /**
   * Catches all the events from the event class specified by this filter.
   * @param notifEvent the event in the notification service queue
   * @return boolean if the event matches; false otherwise
   */
  public boolean eventMatches(Event notifEvent) {

    boolean bResult = false;

    if (notifEvent == null) {
      return false;
    }

    if (notifEvent instanceof ManagedElementAttributeChangeEvent) {

      ManagedElementAttributeChangeEvent event =
        (ManagedElementAttributeChangeEvent) notifEvent;

      ManagedElement me = event.getManagedElement();
      if (me != null) {
        FullyQualifiedTypeName meType = me.getTypeName();

        FullyQualifiedTypeName oEBSCFdn = FQTN.ELM_eBSC.TYPE_NAME;
        if (meType.equals(oEBSCFdn)){    

	    String szUploadProfileInfo = LocalName.ELM_eBSC.ATTGRP_UploadProfileInfo_GRP.TYPE_NAME;
	    AttributeGroup moAttGrp = me.getAttributeGroup(szUploadProfileInfo);
	    if ( moAttGrp  != null) {
		log4jDebugLogger.debug("received CSL attribute change event: " + notifEvent.toString());
		bResult = true;
          }
        }
      }
    }
    return bResult;
  }

  /**
   * Returns the name of the filter.
   * @return name (string) the name.
   */
  public String getName() {
    return EVENT_FILTER_NAME;
  }
}
