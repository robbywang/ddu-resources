/*
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.lc.ebsc;

// Service Common
import com.nortel.cdma.service.common.xml.XMLTag;

// csl
import com.nortel.cdma.service.csl.lc.ebsc.xml.ElcParameterEnum;
import com.nortel.cdma.service.csl.lc.ebsc.xml.ElcXMLReader;

// java
import java.io.File;

import java.util.HashMap;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * This class stores the configuration parameters for the EBSC log
 * collector.
 *
 */
public class EBSCLogCollectorParameters {
  /**
   * Instance of Log4j Logger. 
   */
  private static final Logger log4jDebugLogger = 
                 Logger.getLogger(EBSCLogCollectorParameters.class);

  /**
   * Tag used to retrieve the ELC configuration file.
   */
  private final String TAG_CONFIG_FILE = "ELCXML";

  /**
   * Tag used to retrieve the active properties used by ELC.
   */
  private final String TAG_ACTIVE_PROFILE = "ELCCAP";

  /**
   * Constant represents the configuration file path.
   */
  private static final String CONFIG_FILE_PATH = "/opt/cems/cfg/csl/elc.xml";

  /**
   * Constant represents the default active properties.
   */
  private final String DEFAULT_ACTIVE_PROPERTIES_NAME = "default";

  /**
   * The active set of properties.
   */
  private HashMap<XMLTag, Object> mActivePropertiesMap;

  /**
   * Constructor.
   *
   * @param properties The properties specifying the file path to elc.xml
                       and the name of the active properties  
   */
  public EBSCLogCollectorParameters(Properties properties) {
    // Initializes configuration parameters with default values
    mActivePropertiesMap = new HashMap<XMLTag, Object>();

    for (ElcParameterEnum parameter : ElcParameterEnum.values()) {
      mActivePropertiesMap.put(parameter, parameter.getDefaultValue()); 
    }
    
    // Overrides default configuration parameters with properties if we can
    if (properties == null) {
      log4jDebugLogger.error("Null properties passed in. " +
                            "Use default configuration parameters.");

      return;
    }

    String configFilePath = (String) properties.get(TAG_CONFIG_FILE);

    if (configFilePath == null) {
      log4jDebugLogger.error("Cannot get config file path from properties."
         + " Use default config file: " + CONFIG_FILE_PATH);

      configFilePath = CONFIG_FILE_PATH;
    }

    File configFile = new File(configFilePath);

    if ((configFile == null) || !configFile.exists()
                             || !configFile.canRead()) {
      log4jDebugLogger.error("Cannot find or cannot read config file:"
        + configFilePath + ". Use default configuration parameters.");

      return;
    }

    String activePropertiesName = (String) properties.get(TAG_ACTIVE_PROFILE);

    if(activePropertiesName == null) {
      log4jDebugLogger.error("Cannot get the active properties name from " +
                             "properties. Use default active properties name: "
                             + DEFAULT_ACTIVE_PROPERTIES_NAME);

      activePropertiesName = DEFAULT_ACTIVE_PROPERTIES_NAME;
    }

    HashMap<String, HashMap<XMLTag, Object>>  propertiesMap =
                              ElcXMLReader.readSchema(configFilePath);

    HashMap<XMLTag, Object>  activePropertiesMap =
                                   propertiesMap.get(activePropertiesName);

    if (activePropertiesMap != null) {
      mActivePropertiesMap = activePropertiesMap;
    }
    else {
      log4jDebugLogger.error("Cannot get active properties named: " + 
        activePropertiesName + " from config file:" + configFilePath +
        ". Use default configuration parameters.");
    }
  }

  /**
   * Returns the value as an Object for the specified configuration parameter.
   *
   * @param param  The configuration parameter
   *
   * @return The value as an Object for the specified configuration parameter
   */
  public Object getParameter(ElcParameterEnum param) {
    return mActivePropertiesMap.get(param);
  }

  /**
   * Returns a string representation of the configuration parameters.
   */
  public String toString() {
    String str =
      "\nEBSC Log Collector Configuration Parameters:" +
      "\n    ipAddress = " + (String)getParameter(ElcParameterEnum.ipAddress) +
      "\n    outport = " + (Integer)getParameter(ElcParameterEnum.outPort) +
      "\n    inport = " + (Integer)getParameter(ElcParameterEnum.inPort) +
      "\n    threadPoolSize = " +
                 (Integer)getParameter(ElcParameterEnum.threadPoolSize) +
      "\n    connectBackLog = " + 
                 (Integer)getParameter(ElcParameterEnum.connectBackLog) +
      "\n    connectRetryInterval = " + 
                 (Integer)getParameter(ElcParameterEnum.connectRetryInterval) +
      "\n    connectTimeout = " + 
                 (Integer)getParameter(ElcParameterEnum.connectTimeout)  +
      "\n    connectRetryAlarmThreshold = " + 
                 (Integer)getParameter(ElcParameterEnum.connectRetryAlarmThreshold) +
      "\n    logqueuecapacity = " + 
                 (Integer)getParameter(ElcParameterEnum.logQueueCapacity) +
      "\n    fairShareRecordCount = " +
                 (Integer)getParameter(ElcParameterEnum.fairShareRecordCount) +
      "\n    noDataSleep = " +
                 (Integer)getParameter(ElcParameterEnum.noDataSleep) +
      "\n    noDataSleepIncrement = " +
                 (Integer)getParameter(ElcParameterEnum.noDataSleepIncrement) +
      "\n    enforcesingleconnection = " +
                 (Boolean)getParameter(ElcParameterEnum.moEnforceSingleConnection) +
      "\n    noDataMaxRetryBeforeClose = " +
                 (Integer)getParameter(ElcParameterEnum.noDataMaxRetryBeforeClose) +
      "\n    noDataRetryInternal = " +
                 (Integer)getParameter(ElcParameterEnum.noDataRetryInternal) +
      "\n    channelReaderBufferSize = " +
                 (Integer)getParameter(ElcParameterEnum.channelReaderBufferSize) +
      "\n    overloadConsecutiveReads = " +
                 (Integer)getParameter(ElcParameterEnum.overloadConsecutiveReads) +
      "\n";

    return str;
  }
}
