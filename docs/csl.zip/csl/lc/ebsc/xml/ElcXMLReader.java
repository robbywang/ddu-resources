/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.lc.ebsc.xml;

// Service
import com.nortel.cdma.service.common.xml.XMLReaderUtil;
import com.nortel.cdma.service.common.xml.XMLTag;

// Java
import java.util.ArrayList;
import java.util.HashMap;

import org.w3c.dom.Element;

import org.apache.log4j.Logger;

/**
 * This class reads the ELC configuration xml file to build a collection
 * of configuration parameters for the EBSC log collector.
 */
public class ElcXMLReader {
  /**
   * Instance of Log4j Logger.
   */
  private final static Logger log4jDebugLogger = 
                              Logger.getLogger(ElcXMLReader.class);

  /**
   * Constant represents the root node name in the ELC xml file.
   */
  private final static String SCHEMA_ELC = "schemaelc";

  /**
   * Private constructor so nobody can instantiate this class.
   */
  private ElcXMLReader() {
  }

  /**
   * Parses the specified configuration xml file to return a collection
   * of configuration parameters.
   *
   * @param file  The ELC config file name
   *
   * @return a collection of ELC configuration parameters
   */
  public static HashMap<String, HashMap<XMLTag, Object>> 
                                       readSchema(String file) {

    HashMap<String, HashMap<XMLTag, Object>> propertiesMap =
      new HashMap<String, HashMap<XMLTag, Object>>();

    Element root = XMLReaderUtil.getRootNode(file, SCHEMA_ELC);

    if (root == null) {
      log4jDebugLogger.error("cannot find root node: " + SCHEMA_ELC
        + " in ELC xml config file: " + file + ". Empty configuration"
        + " parameter collection returned.");

      return propertiesMap;
    }

    ArrayList<Element> propertiesList = 
              XMLReaderUtil.getElementsByTagName(root, "properties");

    if (propertiesList.size() == 0) {
      log4jDebugLogger.error("cannot find \"properties\" tag in ELC "
        + "xml config file: " + file + ". Empty configuration"
        + " parameter collection returned.");

      return propertiesMap;
    }

    for (Element elem : propertiesList) {
      String propertiesName = XMLReaderUtil.getStringValueForTag(elem, "name");

      if (propertiesName == null) {
        propertiesName = "default";
      }

      HashMap<XMLTag, Object> xmlTagMap = new HashMap<XMLTag, Object>();

      for (ElcParameterEnum parameter : ElcParameterEnum.values()) {
        Object value = XMLReaderUtil.getValueForTag(elem, parameter);

        if (value != null) {
          xmlTagMap.put(parameter, value);   
        }
        else {
          xmlTagMap.put(parameter, parameter.getDefaultValue()); 
        }
      }

      propertiesMap.put(propertiesName, xmlTagMap);
    }

    return propertiesMap;
  }
}
