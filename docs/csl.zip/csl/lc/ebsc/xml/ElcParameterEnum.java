/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.lc.ebsc.xml;

import com.nortel.cdma.service.common.xml.XMLTag;

/**
 * This enumeration-class represents the EBSC Log Collector (ELC)
 * configuration parameters.
 */
public enum ElcParameterEnum implements XMLTag {
  /**
   * The destination IP address.
   */
  ipAddress("ipaddress", "127.0.0.1", String.class),

  /**
   * The outgoing port number.
   */
  outPort("outport", 5258, Integer.class),

  /**
   * The incoming port number.
   */
  inPort("inport", 5257, Integer.class),

  /**
   * The number of connection back log.
   */
  connectBackLog("connectbacklog", 20, Integer.class),

  /**
   * The thread pool size.
   */
  threadPoolSize("threadpoolsize", 20, Integer.class),

  /**
   * The connection retry interval in milliseconds.
   */
  connectRetryInterval("connectretryinterval", 60000, Integer.class),

  /**
   * The connection timeout in milliseconds.
   */
  connectTimeout("connecttimeout", 5000, Integer.class),

  /**
   * The number of connection retries before an alarm is raised.
   */
  connectRetryAlarmThreshold("connectretryalarmthreshold", 5, Integer.class),

  /**
   * The maximum capacity of the log queue.
   */
  logQueueCapacity("logqueuecapacity", 10000, Integer.class),

  /**
   * The default value of fairsharerecordcount.
   */
  fairShareRecordCount("fairsharerecordcount", 100, Integer.class),

  /**
   * The default value of nodatasleep.
   */
  noDataSleep("nodatasleep", 20, Integer.class),

  /**
   * The default value of nodatasleepincrement.
   */
  noDataSleepIncrement("nodatasleepincrement", 20, Integer.class),

  /**
   * The default value of enforcesingleconnection.
   */
  moEnforceSingleConnection("enforcesingleconnection", true, Boolean.class),

  /**
   * The default value of nodatamaxretrybeforeclose.
   */
  noDataMaxRetryBeforeClose("nodatamaxretrybeforeclose", 100, Integer.class),

  /**
   * The default value of nodataretryinternal.
   */
  noDataRetryInternal("nodataretryinternal", 3, Integer.class),

  /**
   * The default value of channelreaderbuffersize.
   */
  channelReaderBufferSize("channelreaderbuffersize", 10240, Integer.class),

  /**
   * The default value of overloadConsecutiveReads.
   */
  overloadConsecutiveReads("overloadconsecutivereads", 50, Integer.class);

  /**
   * The name of the ELC parameter.
   */
  private final String mName;

  /**
   * The default value of the ELC parameter.
   */
  private final Object mDefaultValue;

  /**
   * The class of the ELC parameter.
   */
  private final Class  mClass;

  /**
   * Constructor.
   * 
   * @param tagName       The name of the ELC parameter
   * @param defaultValue  The default value of the ELC parameter
   * @param tagClass      The class of the ELC parameter
   */
  private ElcParameterEnum(String tagName, Object defaultValue, Class tagClass) {
    mName = tagName;
    mDefaultValue = defaultValue;
    mClass = tagClass;
  }

  /**
   * XML Tag name accessor.
   *
   * @return the xml tag name
   */
  public String getName() {
    return mName;
  }

  /**
   * XML Tag default value accessor.
   *
   * @return the xml tag default value as Object
   */
  public Object getDefaultValue() {
    return mDefaultValue;
  }

  /**
   * XML Tag class accessor.
   *
   * @return the xml tag class
   */
  public Class getTagClass() {
    return mClass;
  }
}
