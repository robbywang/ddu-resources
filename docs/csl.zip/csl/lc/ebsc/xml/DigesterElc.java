/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.lc.ebsc.xml;

import com.nortel.cdma.service.common.xml.Digester;
import com.nortel.cdma.service.common.xml.Schema;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;

import java.io.File;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.apache.log4j.Logger;

/**
 * This class builds the EBSC Log Collector schema from parsing the configuration
 * xml file.
 */
public class DigesterElc extends Digester {
  /**
   * Instance of Log4j Logger.
   */
  private final static Logger log4jDebugLogger = 
                              Logger.getLogger(DigesterElc.class);

  /**
   * Constructor.
   *
   * @param oXml the configuration file
   * @throws InitializationFailureException
   * @throws InvalidDeploymentException
   */
  public DigesterElc(File oXml) throws
    InitializationFailureException, InvalidDeploymentException {
    super(oXml);
  }

  /**
   * Returns the ELC schema.
   *
   * @return the ELC schema
   */
  public SchemaElc getSchema() {
    return (SchemaElc)moSchema;
  }

  /**
   * Parse the EBSC Log Collector configuration xml file.
   *
   * @param oXml the configuration file
   *
   * @return the SchemaElc object
   */
  protected SchemaElc parseXml(File oXml) {
    String    filePath = oXml.getPath();
    Document  elcSchemaDoc = getDocument(filePath);

    if (elcSchemaDoc == null) {
      log4jDebugLogger.error("Null returned from calling getDocument()"
                             + " on ELC configuration xml file.");
      return null;
    }

    NodeList elcSchemaNodes =
      elcSchemaDoc.getElementsByTagName("schemaelc");

    if (elcSchemaNodes == null || elcSchemaNodes.getLength() == 0) {
      log4jDebugLogger.error("Missing schemaelc tag in file: " + filePath);

      return null;
    }

    // Process only the first one
    Node elcSchemaNode = elcSchemaNodes.item(0);

    SchemaElc oSchemaElc = new SchemaElc();

    NodeList  elcEntityNodes = elcSchemaNode.getChildNodes();
    
    if (elcEntityNodes == null) {
      log4jDebugLogger.error("Missing child nodes under schemaelc tag in file: "
                             + filePath);
       return null;
    }

    int  entityCount = elcEntityNodes.getLength();

    for (int i = 0; i < entityCount; i++) {
      Node  entityNode = elcEntityNodes.item(i);

      if (!(entityNode instanceof Element)) {
        continue;   // Something we aren't interested in, like comments
      }

      Element entity = (Element)entityNode;

      String  entityType = entity.getLocalName();

      //==========================================================
      //        <schemaelc>
      //                <properties>
      //                  <name>default</name>
      //                  <ipaddress>127.0.0.1</ipaddress>
      //                  <outport>5258</outport>
      //                   <inport>5257</inport>
      //                <properties>
      //        </schemaelc>
      //==========================================================
      if (! entityType.equalsIgnoreCase("properties")) {
        log4jDebugLogger.error("Ignoring unexpected element: " + entity);

        continue;
      }

      String szName = getStringValueForTag(entity, "name");

      if (szName == null) {
        szName = "default";
      }

      String szIpAddress = getStringValueForTag(entity, "ipaddress");

      String szOutport = getStringValueForTag(entity, "outport");

      String szInport = getStringValueForTag(entity, "inport");

      String connectBackLog = getStringValueForTag(entity, "connectbacklog");

      String threadPoolSize = getStringValueForTag(entity, "threadpoolsize");

      String connectRetryInterval = getStringValueForTag(entity,
                                                       "connectretryinterval");

      String connectTimeout = getStringValueForTag(entity, "connecttimeout");

      String connectRetryAlarmThreshold = getStringValueForTag(entity,
                                                  "connectretryalarmthreshold");

      String logQueueCapacity = getStringValueForTag(entity, "logqueuecapacity");

      String fairShareRecordCount = getStringValueForTag(entity, "fairsharerecordcount");

      String noDataSleep = getStringValueForTag(entity, "nodatasleep");

      String noDataSleepIncrement = getStringValueForTag(entity, "nodatasleepincrement");

      String enforceSingleConnection = getStringValueForTag(entity, "enforcesingleconnection");

      String noDataMaxRetryBeforeClose = getStringValueForTag(entity, "nodatamaxretrybeforeclose");

      String noDataRetryInternal = getStringValueForTag(entity, "nodataretryinternal");

      String channelReaderBufferSize = getStringValueForTag(entity, "channelreaderbuffersize");

      String overloadConsecutiveReads = getStringValueForTag(entity, "overloadconsecutivereads");

      Properties oProperties = extractTokens(entity);

      oProperties.put("name", szName);

      if (szIpAddress != null) {
        oProperties.put("ipaddress", szIpAddress);
      }

      if (szOutport != null) {
        oProperties.put("outport", szOutport);
      }

      if (szInport != null) {
        oProperties.put("inport", szInport);
      }

      if (connectBackLog != null) {
        oProperties.put("connectbacklog", connectBackLog);
      }

      if (threadPoolSize != null) {
        oProperties.put("threadpoolsize", threadPoolSize);
      }

      if (connectRetryInterval != null) {
        oProperties.put("connectRetryInterval", connectRetryInterval);
      }

      if (connectTimeout != null) {
        oProperties.put("connecttimeout", connectTimeout);
      }

      if (connectRetryAlarmThreshold != null) {
        oProperties.put("connectretryalarmthreshold", connectRetryAlarmThreshold);
      }

      if (logQueueCapacity != null) {
        oProperties.put("logqueuecapacity", logQueueCapacity);
      }

      if (fairShareRecordCount != null) {
        oProperties.put("fairsharerecordcount", fairShareRecordCount);
      }

      if (noDataSleep != null) {
        oProperties.put("nodatasleep", noDataSleep);
      }

      if (noDataSleepIncrement != null) {
        oProperties.put("nodatasleepincrement", noDataSleepIncrement);
      }

        if (enforceSingleConnection != null) {
        oProperties.put("enforcesingleconnection", enforceSingleConnection);
      }

      if (noDataMaxRetryBeforeClose != null) {
        oProperties.put("nodatamaxretrybeforeclose", noDataMaxRetryBeforeClose);
      }

      if (noDataRetryInternal != null) {
        oProperties.put("nodataretryinternal", noDataRetryInternal);
      }

      if (channelReaderBufferSize != null) {
        oProperties.put("channelreaderbuffersize", channelReaderBufferSize);
      }

      if (overloadConsecutiveReads != null) {
        oProperties.put("overloadconsecutivereads", overloadConsecutiveReads);
      }

      oSchemaElc.addProperties( szName, oProperties );
    }

    return oSchemaElc;
  }

  /**
   * Datafill the policy object caches based on the CSLSchema
   * object which contains user specification.
   *
   * @param oSchema the file manager schema
   */
  protected void buildObjects(Schema oSchema) {
    // not needed since the Schema is the cache
  }
}
