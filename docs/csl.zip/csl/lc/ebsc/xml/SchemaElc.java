/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.lc.ebsc.xml;

import com.nortel.cdma.service.common.xml.Schema;
import java.util.Collection;
import java.util.TreeMap;
import java.util.Properties;

/**
 * This class describes a DigesterElc which details the contents of the ELC schema.
 * It contains methods used to retrieve ELC data structures.
 */
public class SchemaElc extends Schema {

  /**
   * Hashtable of SectionManager objects.
   */
  private TreeMap<String, Properties> moCollectionProperties;

  /**
   * Default constructor.
   */
  public SchemaElc() {
    moCollectionProperties = new TreeMap<String, Properties>();
  }

  /**
   * Gets the list of Properties objects.
   * @return  Collection of Properties objects.
   */
  public Collection<Properties> getProperties() {

    return ( moCollectionProperties.values() );
  }

  /**
   * Adds a Properties object to the internal collection.
   * @param szName the name of the Properties.
   * @param oProperties the Properties to store.
   */
  public void addProperties(String szName, Properties oProperties) {
    moCollectionProperties.put(szName, oProperties);
  }

  /**
   * Gets the Properties object corresponding to the name provided.
   * @param szName the name of the Properties
   * @return the Properties object corresponding to the name provided
   */
  public Properties getProperty( String szName ) {
    return ( moCollectionProperties.get( szName ) );
  }

  /**
   * Returns a string representation of the object contents.
   * @return the content of this object
   */

  public String toString() {
    String newline = System.getProperty( "line.separator" );
    StringBuffer buf = new StringBuffer();

    Collection [] vArray = { getProperties() };

    String [] tagArray = { "Properties" };

    int i = 0 ;

    for (Collection col: vArray) {
      buf.append( "------- ").append( tagArray[i++] ).append( newline );

      if (!col.isEmpty()) {
        String itemType = col.getClass().getName();
        
        buf.append( "------- " ).append( itemType ).append( " defined in the elc.xml file -------" ).
            append( newline );
        
        for(Object item: col){
          buf.append( item ).append( newline );
        }
      }
    }

    return buf.toString();
  }
}
