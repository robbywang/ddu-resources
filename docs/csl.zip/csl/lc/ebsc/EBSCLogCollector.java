/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.lc.ebsc;

// GSF
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import com.nortel.cdma.gsf.ResourceUnavailableException;
import com.nortel.cdma.gsf.ShutdownFailureException;

import com.nortel.cdma.gsf.service.Service;
import com.nortel.cdma.gsf.service.JRMPServiceInterface;

import com.nortel.cdma.gsf.util.ParameterInfo;

// java
import java.rmi.RemoteException;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

/**
 * This class describes an EBSC log collector that collects stream
 * log records from EBSC subsystems socket connections and sends them 
 * to the Streaming Log Server (SLS).
 */
public class EBSCLogCollector extends Service
  implements JRMPServiceInterface, ControlMessageHandler {
  /**
   * Instance of Log4j Logger.
   */
  private static final Logger log4jDebugLogger =
    Logger.getLogger(EBSCLogCollector.class);

  /**
   * Control message enum.
   */
  private enum ELCControlCode {
    /**
     * The signal to shutdown the EBSC log collector.
     */
    SHUTDOWN,

    /**
     * The signal to restart the EBSCSocketDataReader.
     */
    RESTART_READER,

    /**
     * The signal to restart the EBSCSocketDataWriter.
     */
    RESTART_WRITER,

    /**
     * The signal to restart the EBSC log collector.
     */
    RESTART
  }

  /**
   * The writer used to write log records to SLS socket.
   */
  private EBSCSocketDataWriter mSocketDataWriter = null;

  /**
   * The reader used to read log records from EBSC sockets.
   */
  private EBSCSocketDataReader mSocketDataReader = null;

  /**
   * The parameters used to configure the EBSC log collector.
   */
  private EBSCLogCollectorParameters mConfigParams = null;

  /**
   * Initialization status.
   */
  private boolean mIsStarted = false;

  /**
   * Flag to indicate whether shutting down is in progress.
   */
  private boolean mIsShuttingDown = false;

  /**
   * The one and only instance of the EBSC log collector.
   */
  private static EBSCLogCollector mInstance = null;

  /**
   *  ELCEventManager reference.
   */
  private ELCEventManager moEventManager = null;

  /**
   * Constructor.
   *
   * @throws RemoteException   
   */
  public EBSCLogCollector() throws RemoteException {
    super();
    moEventManager = ELCEventManager.getInstance();
  }

  /**
   * Returns the sole instance of the EBSC Log Collector.
   *
   * @return the sole instance of the EBSC Log Collector
   *
   * @throws RemoteException
   */
  public synchronized static EBSCLogCollector getInstance()
    throws RemoteException {

    if (mInstance == null) {
      mInstance = new EBSCLogCollector();
    }
    return mInstance;
  }

  /**
   * Starts up the EBSC Log Collector.
   *
   * @throws InitializationFailureException upon initialization failure
   * @throws ResourceUnavailableException upon no available resource
   * @throws InvalidDeploymentException upon invalid deployment
   */
  public void startup() throws InitializationFailureException,
    ResourceUnavailableException,
    InvalidDeploymentException {
    if (mIsStarted) {
      log4jDebugLogger.debug("Already started.");

      throw new InitializationFailureException("EBSCLogCollector ",
        "EBSCLogCollector is already started.");
    }

    if(mConfigParams == null) {
      // Uses default configuration parameters
      mConfigParams = new EBSCLogCollectorParameters(null);
    }

    mSocketDataWriter = new EBSCSocketDataWriter(mConfigParams);

    mSocketDataWriter.startup();

    mSocketDataReader = new EBSCSocketDataReader(mConfigParams, mSocketDataWriter);

    mSocketDataReader.startup();

    //start ELCEventManager and assign SocketDataWriter & SocketDataReader to it for event processing
    moEventManager.start();
    publishSocketDataWriterForEventManager();

    publishSocketDataReaderForEventManager();

    mIsStarted = true;
  }

  /**
   * Shuts down the EBSC Log Collector.
   *
   * @throws ShutdownFailureException if unable to shut down the service
   */
  public void shutdown() throws ShutdownFailureException {
    if (!mIsStarted) {
      log4jDebugLogger.debug("Already shutdown, canceling shutdown request.");

      return;
    }

    if (mIsShuttingDown) {
      log4jDebugLogger.debug("Shutdown is in progress, reject another "
        + "shutdown request.");

      return;
    }

    mIsShuttingDown  = true;

    if(mSocketDataReader != null) {
      mSocketDataReader.shutdown();
    }

    if(mSocketDataWriter != null) {
      mSocketDataWriter.shutdown();
    }

    moEventManager.stop();

    mIsStarted = false;

    mIsShuttingDown  = false;
  }

  /**
   * Gets the properties for the EBSCLogCollector Service.
   * @return the service parameter array.
   */
  public ParameterInfo[] getRequiredProperties() {
    return ( new ParameterInfo[]{
      new ParameterInfo("elcName",
        "elcValue",
        "elcDesc")
    } );
  }

  /**
   * Configures the EBSC Log Collector.
   *
   * @param  properties  The properties containing the EBSCLogCollector
   *                     configuration information
   */
  public void configure(Properties properties) {
    mConfigParams = new EBSCLogCollectorParameters(properties);

    log4jDebugLogger.debug(mConfigParams);
  }

  /**
   * Returns the EBSC log collector configuration parameters.
   *
   * @return the EBSC log collector configuration parameters
   */
  public EBSCLogCollectorParameters getConfigParameters() {
    return mConfigParams;
  }

  /**
   * Handles the control message.
   *
   * @param  msgCode  The control message code
   * @param  msgDescription  The control message description
   */
  public void handleControlMessage(int msgCode, String msgDescription) {
    if (log4jDebugLogger.isEnabledFor(Level.DEBUG)) {
      StringBuffer buf = new StringBuffer();
      buf.append("Processing control record: msgCode = ").append(msgCode);

      if (msgDescription != null && msgDescription.length() != 0) {
        buf.append(", description= ").append(msgDescription);
      }

      log4jDebugLogger.debug(buf.toString());
    }

    for (ELCControlCode ctrlCode : ELCControlCode.values()) {
      if (msgCode == ctrlCode.ordinal()) {
        handleControlMessage(ctrlCode, msgDescription);
      }   
    }
  }

  /**
   * Handles the control message.
   *
   * @param ctrlCode  The control message enum
   * @param msgDescription  The control message description
   */
  private void handleControlMessage(ELCControlCode ctrlCode, 
                                    String msgDescription) {

    log4jDebugLogger.info("Processing " + ctrlCode);

    switch(ctrlCode) {
      case SHUTDOWN:
        handleShutdown();
        break;

      case RESTART_READER:
        handleReaderRestart();
        break;

      case RESTART_WRITER:
        handleWriterRestart();
        break;

      case RESTART:
        handleWriterRestart();
        handleReaderRestart();
        break;

      default:
        log4jDebugLogger.error("Invalid control code: " + ctrlCode);
    }
  }

  /**
   * Handles shutdown.
   */
  private void handleShutdown() {
    log4jDebugLogger.info("Shutdown EBSC log collector...");

    try {
      shutdown();

      log4jDebugLogger.info("Shutdown EBSC log collector completed.");
    }
    catch(ShutdownFailureException e) {
      log4jDebugLogger.error("Shutdown EBSCLogCollector - failed.", e);
    }
  }

  /**
   * Handles restart the EBSC socket data reader.
   */
  private void handleReaderRestart() {
    log4jDebugLogger.info("Restart EBSC socket data reader...");

    boolean operationSucceeded = mSocketDataReader.restart();

    /*
    if (! operationSucceeded && getState() == FrameworkState.RUNNING) {
      log4jDebugLogger.warn("Cannot restart reader, set service to DEGRADED");

      try {
        super.changeServiceState(FrameworkState.DEGRADED);
      }
      catch(IllegalArgumentException e) {
        log4jDebugLogger.warn("Illegal state transition from " +
          getState() + " to DEGRADED");
      }
    }
    */

    log4jDebugLogger.info("Restart EBSC socket data reader succeeded = "
      + operationSucceeded);
  }

  /**
   * Handles restart the EBSC socket data writer.
   */
  private void handleWriterRestart() {
    mSocketDataWriter.restart();

    log4jDebugLogger.info("EBSC socket data writer restarted.");
  }

  /**
   * Publishes intialized EBSCSocketDataWriter to ELCEventManager.
   */
  private void publishSocketDataWriterForEventManager() {
    moEventManager.setEBSCSocketDataWriter(mSocketDataWriter);
  }

   /**
   * Publishes intialized EBSCSocketDataReaderr to ELCEventManager.
   */
  private void publishSocketDataReaderForEventManager() {
    moEventManager.setEBSCSocketDataReader(mSocketDataReader);
  }
}
