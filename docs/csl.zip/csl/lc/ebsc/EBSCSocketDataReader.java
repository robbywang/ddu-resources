/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.lc.ebsc;

// GSF
import com.nortel.cdma.gsf.InitializationFailureException;

// CSL
import com.nortel.cdma.service.csl.common.CSPControlRecordData;
import com.nortel.cdma.service.csl.common.CSPControlRecordHeader;
import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.service.csl.common.UploadProfileCSLInfo;
import com.nortel.cdma.common.internationalization.CallSummaryLogMessageCategory;
import com.nortel.cdma.service.csl.lc.ebsc.xml.ElcParameterEnum;
import com.nortel.cdma.service.common.overload.OverloadController;
import com.nortel.cdma.service.common.overload.OverloadInterface;

// java
import java.io.EOFException;
import java.io.IOException;

import java.nio.ByteBuffer;
import java.nio.BufferUnderflowException;

import java.nio.channels.SocketChannel;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.Selector;
import java.nio.channels.SelectableChannel;
import java.nio.channels.SelectionKey;
import java.nio.channels.Pipe;

import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import org.apache.log4j.Level;

/**
 * This class reads log records from EBSC subsystem socket connections.
 */
public class EBSCSocketDataReader implements OverloadInterface {
    /**
     * Instance of Log4j Logger.
     */
    private static final Logger log4jDebugLogger = Logger.getLogger(EBSCSocketDataReader.class);

    /**
     * Record length size in bytes.
     */
    private static final byte RECORD_LENGTH_SIZE = 2;

    /**
     * Flag indicating if ELC is overloaded.
     */
    private boolean mbHasSetELCOverloadFlag;

    /**
     * Constant represents the CSP control record source Id.
     * 1=ELC, 2=SLS
     */
    private final static byte SOURCE_ID_ELC = 0x1;

    /**
     * Constant represents the ELC control record log type.
     */
    private final static byte LOG_TYPE_ELC = 0x14;

    /**
     * Signaling code.
     */
    private final static byte RC_ADD_TO_READ = 0x1;

    /**
     * Port to listen on.
     */
    private int mInPort;

    /**
     * The maximum number of records to read from a channel in a read-session.
     */
    private int miFairShareRecordCount;

    /**
     * The initial number of milliseconds to sleep if there is no data on
     * a channel.
     */
    private int miNoDataSleep;

    /**
     * The additional number of milliseconds to sleep if there is no data on
     * a channel, during the internal loop.
     */
    private int miNoDataSleepIncrement;

    /**
     * Flag indicates if ELC reader needs to force single connection per PMC.
     */
    private boolean mbEnforceSingleConnection;

    /**
     * The maximum number of attempts to read data from a channel before
     * closing it.
     */
    private int miNoDataMaxRetryBeforeClose;

    /**
     * The maximum number of attempts to read data from a channel, during
     * the internal read-and-wait loop.
     */
    private int miNoDataRetryInternal;

    /**
     * The buffer size for reading data from channels.
     */
    private int miChannelReaderBufferSize;

    /**
     * Maximum backlog for accepting incoming connections.
     */
    private int mConnectBackLog;

    /**
     * Server Socket channel that listens to client socket connections.
     */
    private ServerSocketChannel mServerSocketChannel = null;

    /**
     * Server Socket.
     */
    private ServerSocket mServerSocket = null;

    /**
     * Selector that does IO multiplexing.
     */
    private Selector mSelector = null;

    /**
     * Thread that handles client connections.
     */
    private Thread mSelectorThread = null;

    /**
     * Thread used to initiate channel read operations using a fair-share
     * algorithm.
     */
    private Thread mChannelReadThread = null;

    /**
     * Pipe that contains signaling code for returning sockets to
     * the selector.
     */
    private Pipe  mReturnSignalingChannel = null;

    /**
     * The read end of the return signal pipe.
     */
    private Pipe.SourceChannel  mReadEnd = null;

    /**
     * Queue that contains sockets returning to the selector.
     */
    private LinkedBlockingQueue<SocketChannel> mReturnSockets = null;

    /**
     * The list of socket channels to read from.
     */
    private List<SocketChannelWrapper> moSocketChannelWrappers =
        Collections.synchronizedList(new LinkedList<SocketChannelWrapper>());

    /**
     * Synchronization object to access the return channel.
     */
    private Object returnChannelLock = new Object();

    /**
     * Set to true if socket data reader is started.
     */
    private boolean mIsStarted = false;

    /**
     * Set to true when the process is requested to shut down.
     */
    private volatile boolean mIsShuttingDown = false;

    /**
     * Number of threads that services the EBSC socket connections.
     */
    private int mThreadPoolSize;

    /**
     * Thread pool executor.
     */
    private ExecutorService mExecutor = null;

    /**
     * A Collection of client socket channels.
     */
    private Vector<SocketChannel> mClientSockets = null;

    /**
     * Number of subsystem log records received in the last time period.
     */
    private long mNumLogsReceived = 0L;

    /**
     * Number of subsystem log records received since startup.
     */
    private long mTotalLogsReceived = 0L;

    /**
     * Number of subsystem log records dropped in the last time period.
     */
    private long mNumLogsDropped = 0L;

    /**
     * Number of subsystem log records dropped since startup.
     */
    private long mTotalLogsDropped = 0L;

    /**
     * Number of bytes received in the last time period.
     */
    private long mNumBytesReceived = 0L;

    /**
     * Number of bytes received since startup.
     */
    private long mTotalBytesReceived = 0L;

    /**
     * Number of bytes dropped in the last time period.
     */
    private long mNumBytesDropped = 0L;

    /**
     * Number of bytes dropped since startup.
     */
    private long mTotalBytesDropped = 0L;

    /**
     * Timer to periodically send CSP control records.
     */
    private Timer mSendControlRecordTimer;

    /**
     * Number of consecutive max byte read which may trigger overload control.
     */
    private int miOverloadConsecutiveReads = 100;

    /**
     * Attribute filter used to drop log data under the overloading condition.
     */
    private LinkedList<Integer> mOverLoadingLogTypeFilters;

    /**
     * Flag indicates if this class needs to handle the overloading action request.
     */
    private boolean mbHandleOverloading = false;

    /**
     * Delay (in ms) between successive log messages indicating IO error on accept.
     */
    private static final int IOERROR_DEBOUNCE_DELAY = 60000;

    /**
     *  Timestamp for register error message debounce.
     */
    private long mlRegisterIOErrorTimestamp = 0L;

    /**
     *  Timestamp for accept error message debounce.
     */
    private long mlAcceptIOErrorTimestamp = 0L;

    /**
     * OverloadController reference.
     */
    private OverloadController moOverloadControllerRef;

    /**
     * The writer.
     */
    private LogRecordWriter mWriter;

    /**
     * The byte array used to drain SocketChannels prior to closing them.
     */
    private byte[] mabBufferDrain;

    /**
     * The ByteBuffer used to drain SocketChannels prior to closing them.
     */
    private ByteBuffer moByteBufferDrain;

    /**
     * Formatting string to configure date formatter.
     */
    private static String mszDateFormatterString = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * Date formatter object.
     */
    private static SimpleDateFormat mDateFormatter = new SimpleDateFormat(mszDateFormatterString);
    /**
     * Header info for  byte lost report.
     */
    private static final String HEADER_BYTE_LOST_REPORT = "CSLINFO.HEAD.ELC, Report Time, Logs Received, " +
        "Total Logs Received, Bytes Received, Total Bytes Received, Logs Dropped, " +
        "Total Logs Dropped, Bytes Dropped, Total Bytes Dropped";

    /**
     * Data info for  byte lost report.
     */
    private static final String DATA_BYTE_LOST_REPORT = "CSLINFO.DATA.ELC";

    /**
     * Constructor.
     *
     * @param configParams  The configuration parameters for EBSC log collector
     *                      it is shared by all the readers and the writer threads
     * @param writer        The record writer
     *
     */
    public EBSCSocketDataReader(EBSCLogCollectorParameters configParams,
                                LogRecordWriter writer) {

        mabBufferDrain = new byte[64 * 1024];
        moByteBufferDrain = ByteBuffer.wrap( mabBufferDrain );

        miFairShareRecordCount = (Integer)configParams.getParameter(
            ElcParameterEnum.fairShareRecordCount);

        miNoDataSleep = (Integer)configParams.getParameter(
            ElcParameterEnum.noDataSleep);

        miNoDataSleepIncrement = (Integer)configParams.getParameter(
            ElcParameterEnum.noDataSleepIncrement);

        mbEnforceSingleConnection = (Boolean)configParams.getParameter(
            ElcParameterEnum.moEnforceSingleConnection);

        miNoDataMaxRetryBeforeClose = (Integer)configParams.getParameter(
            ElcParameterEnum.noDataMaxRetryBeforeClose);

        miNoDataRetryInternal = (Integer)configParams.getParameter(
            ElcParameterEnum.noDataRetryInternal);

        miChannelReaderBufferSize = (Integer)configParams.getParameter(
            ElcParameterEnum.channelReaderBufferSize);

        miOverloadConsecutiveReads = (Integer)configParams.getParameter(
            ElcParameterEnum.overloadConsecutiveReads);

        mWriter = writer;

        mConnectBackLog = (Integer)configParams.getParameter(
            ElcParameterEnum.connectBackLog);


        mThreadPoolSize = (Integer)configParams.getParameter(
            ElcParameterEnum.threadPoolSize);

        mClientSockets = new Vector<SocketChannel>();

        mOverLoadingLogTypeFilters = new LinkedList<Integer> ();

        moOverloadControllerRef  = OverloadController.getInstance();
    }


    /**
     * Starts up the socket data reader.
     *
     * @throws InitializationFailureException if there is problem starting up
     */
    public synchronized void startup() throws InitializationFailureException {
        if (mIsStarted) {
            log4jDebugLogger.info("Already started, canceling startup request.");

            return;
        }


        /* The following low value attributes will be filtered out during CPU overloading
        <value name="SLOG_LOG_NEIGHBOR_LIST_TUNING_ARRAY" displayname="LogNeighborListTuningArray">0x05</value>
        <value name="SLOG_LOG_ACTIVE_SET_NL_UPDATE" displayname="LogActiveSetNeighborListUpdate">0x06</value>
        <value name="SLOG_LOG_SCH_ACTIVE_SET_CHANGE" displayname="LogSCHActiveSetChange">0x07</value>
        <value name="SLOG_LOG_ROUND_TRIP_DELAY" displayname="LogRoundTripDelay">0x08</value>
        <value name="SLOG_LOG_LINK_FER_DATA" displayname="LogLinkFERData">0x09</value>
        */
        mOverLoadingLogTypeFilters.addAll(Arrays.asList(new Integer[]{0,1,2,3,4,10,11,12,13,14,15,16,17,18,19,20,21,22,23}));

        //read the Source PortId from DB.
        getInPortIDFromDB();

        moOverloadControllerRef.register( this );

        mExecutor = Executors.newFixedThreadPool(mThreadPoolSize);

        mIsStarted = true;

        openServerSocket();

        // Starts the timer to send CSP control record every 30 minutes,
        // on the hour and half hour.
        mSendControlRecordTimer = new Timer();

        long  period = 30*60*1000L;  // 30 minutes in milliseconds

        long  currentTime = System.currentTimeMillis();

        long  delay = period - currentTime%period;  // milliseconds till next half hour

        mSendControlRecordTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                sendControlRecord();
            }
        }, delay, period);



        log4jDebugLogger.info("startup completed!\n");
    }

    /**
     * Retrieve the get the destination port Id from the database.
     */
    private void getInPortIDFromDB () {

        UploadProfileCSLInfo oUPinfo = CSLUtil.getUploadProfileInfoAttGrp();

        if (oUPinfo.isValid()) {
            int tmpPortId = oUPinfo.getDestinationPortId();
            if (tmpPortId != -1) {
                mInPort = tmpPortId;
            }
        }
    }

    /**
     * Shuts down the socket data reader.
     */
    public synchronized void shutdown() {
        if (!mIsStarted) {
            log4jDebugLogger.info("Already shutdown, canceling shutdown request");

            return;
        }

        mIsShuttingDown = true;

        mIsStarted = false;

        moOverloadControllerRef.deregister( this );

        mSelectorThread.interrupt();

        mChannelReadThread.interrupt();

        mExecutor.shutdown();

        boolean  result = false;

        long     shutdownTimeout = 5000;  // milliseconds

        try {
            result = mExecutor.awaitTermination(shutdownTimeout,
                TimeUnit.MILLISECONDS);
        }
        catch(InterruptedException e) {
            //ignore
        }

        if (!result) {
            log4jDebugLogger.error("Failed to shut down mExecutor in " +
                shutdownTimeout + "milliseconds.");
        }

        mSendControlRecordTimer.cancel();

        closeAll();



        mIsShuttingDown = false;

        log4jDebugLogger.info("shutdown completed!\n");
    }

    /**
     * Restart the socket data reader.
     *
     * @return true if the reader is restarted, false otherwise.
     *
     */
    public boolean restart() {
        boolean operationSucceeded = true;

        shutdown();

        try {
            Thread.sleep(5000);
        }
        catch(InterruptedException e) {
            //ignore.
        }

        try {
            startup();
        }
        catch (InitializationFailureException e){
            operationSucceeded = false;
        }

        if (log4jDebugLogger.isDebugEnabled()) {
            log4jDebugLogger.debug("restart succeeded = " + operationSucceeded);
        }
        return operationSucceeded;
    }

    /**
     * Restart the socket data reader.
     *
     * @return true if the reader is restarted, false otherwise.
     *
     */
    public boolean selectiveRestart() {
        boolean operationSucceeded = true;

        selectiveShutdown();

        try {
            Thread.sleep(5000);
        }
        catch(InterruptedException e) {
            //ignore.
        }

        try {
            selectiveStartup();
        }
        catch (InitializationFailureException e){
            operationSucceeded = false;
        }

        if (log4jDebugLogger.isDebugEnabled()) {
            log4jDebugLogger.debug("selective restart succeeded = " + operationSucceeded);
        }
        return operationSucceeded;
    }

    /**
     * Starts up the socket data reader.
     *
     * @throws InitializationFailureException if there is problem starting up
     */
    public synchronized void selectiveStartup() throws InitializationFailureException {
        if (mIsStarted) {
            log4jDebugLogger.info("Already started, canceling selective startup request.");

            return;
        }

        mExecutor = Executors.newFixedThreadPool(mThreadPoolSize);

        mIsStarted = true;

        openServerSocket();

        log4jDebugLogger.info("selective startup completed!\n");
    }

    /**
     * Shuts down the socket data reader.
     */
    public synchronized void selectiveShutdown() {
        if (!mIsStarted) {
            log4jDebugLogger.info("Already shutdown, canceling shutdown request");

            return;
        }

        if (mIsShuttingDown){
            log4jDebugLogger.info("Already shutdown, canceling shutdown request");

            return;
        }

        mIsShuttingDown = true;

        mIsStarted = false;

        mSelectorThread.interrupt();

        mChannelReadThread.interrupt();

        mExecutor.shutdown();

        boolean  result = false;

        long     shutdownTimeout = 5000;  // milliseconds

        try {
            result = mExecutor.awaitTermination(shutdownTimeout,
                TimeUnit.MILLISECONDS);
        }
        catch(InterruptedException e) {
            //ignore
        }

        if (!result) {
            log4jDebugLogger.error("Failed to shut down mExecutor in " +
                shutdownTimeout + "milliseconds.");
        }

        closeAll();



        mIsShuttingDown = false;

        log4jDebugLogger.info("selective shutdown completed!\n");
    }

    /**
     * Opens the server socket to accept client connections.
     */
    private void openServerSocket()  {
        boolean operationSucceeded = false;

        //close the outstanding server and client sockets and then open a new one
        closeServerClientSocket();

        try {

            mServerSocketChannel = ServerSocketChannel.open();

            mServerSocketChannel.configureBlocking(false);

            mServerSocket = mServerSocketChannel.socket();

            mServerSocket.setReuseAddress(true);

            InetSocketAddress isa = new InetSocketAddress(mInPort);

            mServerSocket.bind(isa, mConnectBackLog);

            operationSucceeded = true;
        }
        catch (IOException e) {
            log4jDebugLogger.error("Unable to open server socket at port " + mInPort + " " +
                "to accept incoming connections.", e);
        }
        finally {
            if (! operationSucceeded) {
                closeAll();
                return;
            }
        }

        try {
            configSelector();
        }
        catch(IOException e) {
            log4jDebugLogger.error("Unable to configure selector", e);

            closeAll();
            return;
        }

        mSelectorThread = new Thread("EBSCSocketDataReader selector thread") {
            public void run() {

                handleSelection();
            }
        };
        mSelectorThread.start();

        mChannelReadThread = new Thread("EBSCSocketDataReader Channel Read") {
            public synchronized void run() {
                while (mIsStarted) {
                    try {
                        wait();
                    }
                    catch(InterruptedException e) {
                    }

                    SocketChannelWrapper oSocketChannelWrapper = null;

                    do {
                        oSocketChannelWrapper = null;

                        synchronized(moSocketChannelWrappers) {
                            if (! moSocketChannelWrappers.isEmpty()) {
                                oSocketChannelWrapper = moSocketChannelWrappers.remove(0);
                            }
                        }

                        final SocketChannelWrapper oSocketChannelWrapperToReadFrom =
                            oSocketChannelWrapper;

                        if (oSocketChannelWrapperToReadFrom != null) {
                            Runnable r = new Runnable() {
                                public void run() {

                                    if (handleRead(oSocketChannelWrapperToReadFrom)) {

                                        moSocketChannelWrappers.add(oSocketChannelWrapperToReadFrom);

                                    }
                                    else {
                                        if (log4jDebugLogger.isInfoEnabled()) {
                                            String sWrapper = oSocketChannelWrapperToReadFrom.toString();
                                            log4jDebugLogger.info(
                                                "Read total bytes: " +
                                                oSocketChannelWrapperToReadFrom.getTotalBytesRead() +
                                                " from channel: " + sWrapper);
                                        }
                                    }

                                    synchronized(mChannelReadThread) {
                                        mChannelReadThread.notifyAll();
                                    }
                                }
                            };

                            mExecutor.execute(r);
                        }
                    } while (oSocketChannelWrapper != null);
                }
            }
        };
        mChannelReadThread.start();

        log4jDebugLogger.info("Open server socket succeeded!");
    }

    /**
     * Configures the selector.
     *
     * @throws IOException
     */
    private void configSelector() throws IOException {
        // Creates a return pipe to return socket channel from the
        // service threads to the selector.
        mReturnSignalingChannel = Pipe.open();

        mReadEnd = mReturnSignalingChannel.source();

        mReturnSockets = new LinkedBlockingQueue<SocketChannel>();

        mReadEnd.configureBlocking(false);

        mSelector = Selector.open();

        mReadEnd.register(mSelector, SelectionKey.OP_READ);

        mServerSocketChannel.register(mSelector, SelectionKey.OP_ACCEPT);
    }

    /**
     * Thread function to handle events on the selector.
     *
     * When new event arrives:
     * (1) if this is a new connection request, accepts and register it with the
     *      selector for read events.
     * (2) if this is event on the return channel, places the returned
     *     channel into the selector.
     * (3) if this is a READ event at polled channel, removes this channel
     *     from the selector, dispatched it to the service thread.
     */
    private void handleSelection() {
        try {

            while (mIsStarted) {
                int numKeys = 0;

                try {

                    numKeys = mSelector.select();
                }
                catch(IOException e) {

                    if (mIsStarted) {
                        log4jDebugLogger.error("Selector.select() met I/O error", e);
                    }

                    continue;
                }
                catch (Exception e) {
                    log4jDebugLogger.error(e);
                    continue;
                }

                if (log4jDebugLogger.isDebugEnabled()) {
                    log4jDebugLogger.debug("Selector stops, numKeys = " + numKeys);
                }
                if (numKeys == 0) {
                    continue;
                }

                Set<SelectionKey> skeys = mSelector.selectedKeys();

                Iterator<SelectionKey> it = skeys.iterator();

                Vector<SocketChannel> oVectorConnections = new Vector<SocketChannel>();

                while (it.hasNext()) {
                    SelectionKey readyKey = it.next();
                    it.remove();

                    if (! readyKey.isValid()) {
                        // Channel was cancelled in the background
                        log4jDebugLogger.debug("Invalid readyKey. Skip it.");

                        continue;
                    }

                    if(readyKey.isAcceptable()) {
                        SocketChannel oSocketChannelNewConnection = getNewConnection();

                        if (oSocketChannelNewConnection == null) {
                            continue;
                        }

                        if (log4jDebugLogger.isInfoEnabled()) {
                            log4jDebugLogger.info("Accepted incoming connection, open channels=" + mClientSockets.size());
                        }

                        oVectorConnections.add( oSocketChannelNewConnection );

                        continue;
                    }

                    final SelectableChannel sc = readyKey.channel();

                    if (sc == mReadEnd) {
                        // "READ event" on returned channel - means channel was
                        // returned to the selector from service thread.
                        SocketChannel returnedChannel = null;

                        try {
                            returnedChannel= getFromReturnChannel();
                        }
                        catch(IOException e) {
                            log4jDebugLogger.error("Met I/O error calling getFromReturnChannel.", e);

                            continue;
                        }

                        if (returnedChannel == null ) {
                            log4jDebugLogger.error("getFromReturnChannel() returned null channel");

                            continue;
                        }

                        if(! returnedChannel.isOpen()) {
                            if (log4jDebugLogger.isInfoEnabled()) {
                                log4jDebugLogger.info("Returned channel is closed, don't register it with the selector.");
                            }

                            continue;
                        }

                        try {
                            returnedChannel.configureBlocking(false);
                            returnedChannel.register(mSelector, SelectionKey.OP_READ);
                        }
                        catch(IOException e) {
                            log4jDebugLogger.error("Unable to register returnChannel - " +
                                returnedChannel + " with selector. Execution continues.", e);

                            continue;
                        }
                    }
                    else {
                        // Client socket connection, deselects it from the selector
                        // and processes it.
                        if (log4jDebugLogger.isInfoEnabled()) {
                            log4jDebugLogger.info("Processing read event on: " + (SocketChannel)sc);
                        }
                        readyKey.cancel();

                        SocketChannelWrapper channelWrapper =
                            new SocketChannelWrapper((SocketChannel) sc,
                                miChannelReaderBufferSize,miFairShareRecordCount);

                        if (mbEnforceSingleConnection ) {
                            boolean bShouldClose = false;

                            synchronized (mClientSockets) {

                                String szIpAddressNew = channelWrapper.getRemoteIpAddress();
                                int iPortNew = channelWrapper.getRemotePort();

                                log4jDebugLogger.info("handleSelection::new  IP Address is '" + szIpAddressNew + "', port "
                                    + iPortNew + "'");

                                Iterator oIterator = mClientSockets.iterator();

                                while ( oIterator.hasNext() ) {
                                    SocketChannel oCurrent = (SocketChannel) oIterator.next();
                                    Socket oSocket = oCurrent.socket();
                                    String szIpAddressCurrent = null;

                                    if (oSocket == null) {
                                        //   bShouldClose = true;
                                        log4jDebugLogger.info("handleSelection::null socket");
                                    }
                                    else {
                                        InetAddress oIP = oSocket.getInetAddress();

                                        if (oIP == null) {
                                            log4jDebugLogger.info("handleSelection::null InetAddress");

                                            //    bShouldClose = true;
                                        }
                                        else {
                                            szIpAddressCurrent = oIP.getHostAddress();

                                            log4jDebugLogger.info("handleSelection::current IP Address is " + szIpAddressCurrent);

                                            if ( szIpAddressCurrent.equalsIgnoreCase(szIpAddressNew)) {
                                                //if the new connection from the same port, keep it active; otherwise,
                                                //close the old socket connection and open a new one

                                                int iRemotePortCurrent = oSocket.getPort();

                                                if (iRemotePortCurrent != iPortNew) {
                                                    bShouldClose = true;
                                                }
                                            }
                                        }
                                    }

                                    if ( bShouldClose == true ) {
                                        try {
                                            int iBytesRead = oCurrent.read(moByteBufferDrain);
                                            log4jDebugLogger.info("handleSelection::drained " + iBytesRead + " from " + szIpAddressCurrent);
                                            mNumBytesReceived += iBytesRead;
                                            mNumBytesDropped += iBytesRead;
                                        }
                                        catch (IOException e) {
                                            log4jDebugLogger.error("Unable to read data from SocketChannel of '" + szIpAddressCurrent + "'", e);
                                        }
                                        finally {
                                            try {
                                                log4jDebugLogger.info("handleSelection::closing socket channel for " + szIpAddressCurrent);

                                                oCurrent.close();
                                            }
                                            catch (IOException e) {
                                                log4jDebugLogger.error("Unable to close SocketChannel of '" + szIpAddressCurrent + "'", e);
                                            }
                                            finally {
                                                log4jDebugLogger.info("handleSelection::removing stale connection from list for " + szIpAddressCurrent);

                                                oIterator.remove();
                                                moSocketChannelWrappers.remove(oCurrent);
                                                oVectorConnections.remove(oCurrent);
                                            }
                                        }
                                    }
                                }

                                log4jDebugLogger.info("handleSelection::mClientSockets.size() after process is " + mClientSockets.size());
                            }
                        }

                        synchronized (moSocketChannelWrappers) {
                            moSocketChannelWrappers.add(channelWrapper);
                        }

                        synchronized(mChannelReadThread) {
                            mChannelReadThread.notifyAll();
                        }
                    }
                }
                synchronized (mClientSockets) {
                    mClientSockets.addAll( oVectorConnections );
                }
            }
        }
        finally { // Time to shut down
            closeAll();
        }

        if (log4jDebugLogger.isInfoEnabled()) {
            log4jDebugLogger.info(Thread.currentThread().getName() + " stopped.\n");
        }
    }

    /**
     * Retrieve the new Socket Channel.
     * @return  the SocketChannel object
     */
    private SocketChannel getNewConnection() {
        SocketChannel connection = null;
        boolean successFlag = false;

        try {
            try {
                connection = mServerSocketChannel.accept();
            }
            catch(IOException e) {
                long lCurrentTime = System.currentTimeMillis();

                if ((lCurrentTime - mlAcceptIOErrorTimestamp) > IOERROR_DEBOUNCE_DELAY) {
                    log4jDebugLogger.error("IOException when accepting channel, open channels="
                        + mClientSockets.size(), e);
                    mlAcceptIOErrorTimestamp = lCurrentTime;
                }
            }

            if (connection == null) {
                log4jDebugLogger.info("accept() returned null socket channel.");
            }
            else {
                if (log4jDebugLogger.isInfoEnabled()) {
                    log4jDebugLogger.info("Accepted incoming connection, open channels=" + mClientSockets.size());
                }

                try {
                    connection.configureBlocking(false);
                    connection.register(mSelector, SelectionKey.OP_READ);

                    if (log4jDebugLogger.isInfoEnabled()) {
                        log4jDebugLogger.info("Registered incoming connection for read event: " + connection);
                    }

                    successFlag = true;
                }
                catch(IOException e) {
                    long lCurrentTime = System.currentTimeMillis();

                    if ((lCurrentTime - mlRegisterIOErrorTimestamp) > IOERROR_DEBOUNCE_DELAY) {

                        log4jDebugLogger.error("IOException when registering with selector for "
                            + " socket channel: " + connection, e);
                        mlRegisterIOErrorTimestamp = lCurrentTime;
                    }
                }
            }
        }
        finally {
            if (! successFlag) {
                try {
                    if (connection != null) {
                        connection.close();
                        connection = null;
                    }
                }
                catch (IOException e) {
                    log4jDebugLogger.error("Unable to close SocketChannel", e);
                    connection = null;
                }
            }
        }

        return connection;
    }

    /**
     * Thread function that reads log records from the socket.
     *
     * @param channelWrapper  The wrapper for socket channel to read from
     *
     * @return true if reading from this channel can continue, false otherwise
     */
    private boolean handleRead(SocketChannelWrapper channelWrapper) {
        boolean  closeSocket = false;

        SocketChannel channel = channelWrapper.getSocketChannel();

        if (channel == null) {
            log4jDebugLogger.error("Null socket channel passed in.");

            return false;
        }

        ByteBuffer readBuf = channelWrapper.getReadByteBuffer();
        ByteBuffer writeBuf = channelWrapper.getWriteByteBuffer();

        int bytesRead = 0;

        try {
            if (! channelWrapper.hasReadingStarted()) {
                channelWrapper.setHasReadingStarted(true);

                bytesRead = readFromByteBuffer(channel, readBuf);

                readBuf.flip();

                writeBuf.position(0);
                writeBuf.limit(0);
                writeBuf.flip();

                channelWrapper.addBytesRead(bytesRead);
            }

            int iRecordsLeftToProcess = channelWrapper.getFairShareIncrement();

            if (! readBuf.hasRemaining()) {
                if (writeBuf.limit() > 0) {
                    mWriter.writeByteBuffer(writeBuf);
                    writeBuf.limit(0);
                }

                readBuf.compact();
                bytesRead = readFromByteBuffer(channel, readBuf);
                readBuf.flip();

                if (bytesRead == -1) {
                    iRecordsLeftToProcess = 0;

                    closeSocket = true;
                }
                else {
                    channelWrapper.addBytesRead(bytesRead);
                }
            }

            while (iRecordsLeftToProcess  > 0 && mIsStarted) {
                try {
                    int recLen = 0;
                    boolean success = false;

                    do {
                        try {
                            recLen = readBuf.getShort() & 0xFFFF;

                            success = true;
                        }
                        catch(BufferUnderflowException e) {

                            if (writeBuf.limit() > 0) {
                                mWriter.writeByteBuffer(writeBuf);
                                writeBuf.limit(0);
                            }

                            readBuf.compact();

                            bytesRead = readFromByteBuffer(channel, readBuf);

                            if (bytesRead == -1) {
                                throw new EOFException();
                            }
                            else {
                                channelWrapper.addBytesRead(bytesRead);
                            }

                            readBuf.flip();
                            writeBuf.flip();

                            if (bytesRead == 0) {
                                channelWrapper =  setELCOverloadInfo(channelWrapper, false);
                                int readAttempts =
                                    channelWrapper.incrementUnsuccessfulReadAttempts();

                                if (readAttempts >= miNoDataMaxRetryBeforeClose) {
                                    log4jDebugLogger.info("Maximum number of unsuccessful " +
                                        "reads reached for channel: " +
                                        channel + ".");
                                    closeSocket = true;

                                    return false;
                                }
                                else if (readAttempts == 3) {
                                    channelWrapper.decrementFairShareRecordCount();
                                }
                                return true;
                            }
/*                            else if (bytesRead == miChannelReaderBufferSize ) {
                                int iConsecutiveMaxReads = channelWrapper.increaseNumberConsecutiveMaxReads();

                                if (iConsecutiveMaxReads == miOverloadConsecutiveReads) {

                                    //call OverloadController to set the overload flag
                                    channelWrapper =  setELCOverloadInfo(channelWrapper, true);
                                }
//                                else {
//                                    if ( (1.0 * iConsecutiveMaxReads) / miOverloadConsecutiveReads > 0.40) {
//                                        channelWrapper.incrementFairShareRecordCount();
//                                        iRecordsLeftToProcess += channelWrapper.getFairShareIncrement();
//                                    }
//                                }
                            }
                            else {
                                channelWrapper =  setELCOverloadInfo(channelWrapper, false);
                            }
                            channelWrapper.resetUnsuccessfulReadAttempts();*/
                            
                            iRecordsLeftToProcess = evaluateRecordsLeftToProcess(bytesRead, channelWrapper, channel, iRecordsLeftToProcess);  
                        }
                    } while (! success);

                    if (! success) {
                        log4jDebugLogger.error("Unable to read the length for channel: " +
                            channel);
                        break;
                    }

                    int payloadLen = recLen - RECORD_LENGTH_SIZE;

                    if (readBuf.remaining() < payloadLen) {

                        if (writeBuf.limit() > 0) {
                            mWriter.writeByteBuffer(writeBuf);
                            writeBuf.limit(0);
                        }

                        // Reset the buffer position before the length
                        readBuf.position(readBuf.position() - RECORD_LENGTH_SIZE);


                        do {
                            readBuf.compact();
                            bytesRead = readFromByteBuffer(channel, readBuf);

                          iRecordsLeftToProcess = evaluateRecordsLeftToProcess(bytesRead, channelWrapper, channel, iRecordsLeftToProcess);
                            
                            readBuf.flip();

                            if (bytesRead == -1) {
                                log4jDebugLogger.error("EOF while reading payload from channel: " +
                                    channel);
                                throw new EOFException();
                            }
                            else {
                                if (bytesRead == 0) {
                                    int readAttempts =
                                        channelWrapper.incrementUnsuccessfulReadAttempts();

                                    if (readAttempts >= miNoDataMaxRetryBeforeClose) {
                                        log4jDebugLogger.info("Maximum number of unsuccessful " +
                                            "reads reached for channel: " +
                                            channel + ".");
                                        closeSocket = true;
                                        return false;
                                    }

                                    return true;
                                }

                                channelWrapper.addBytesRead(bytesRead);

                                channelWrapper.resetUnsuccessfulReadAttempts();
                            }
                        } while (readBuf.remaining() < recLen);

                        readBuf.position(RECORD_LENGTH_SIZE);
                        // Reset the current position to the beginning of the payload
                        // because out side the "if" we skip over payloadLen

                        writeBuf.flip();
                    }

                    //drop un-required the log data based on the user preference
                    //in CSLPRofile.AttributeFilterGroup. Only apply for data log
                    boolean bAllowLogType = true;

                    if (mbHandleOverloading) {
                        bAllowLogType = isLogTypeAllowed(readBuf);
                    }

                    // Skip over the payload in the read buffer
                    readBuf.position(readBuf.position() + payloadLen);

                    int iNewPosition = writeBuf.limit() + recLen;

                    if (iNewPosition < 0 ){
                        log4jDebugLogger.error("Invalid Position: '" + iNewPosition + "'. Resetting to 0.");

                        iNewPosition = 0;
                    }
                    else {
                        int iCapacity = writeBuf.capacity();

                        if ( iNewPosition > iCapacity ) {
                            log4jDebugLogger.error("Invalid Capacity: '" + iNewPosition + "'. Max Capacity: '"
                                + iCapacity + "'. Resetting to " + iCapacity );

                            iNewPosition = iCapacity;
                        }
                    }

                    synchronized(this) {
                        mNumLogsReceived++;
                        mNumBytesReceived += recLen;
                    }

                    if (bAllowLogType == true) {
                        writeBuf.limit(iNewPosition);
                    }
                    else {
                        if (writeBuf.hasRemaining()) {
                            mWriter.writeByteBuffer(writeBuf);
                            synchronized(this) {
                                mNumLogsDropped++;
                                mNumBytesDropped += recLen;
                            }
                        }
                        writeBuf.limit(iNewPosition);
                        writeBuf.position(iNewPosition);
                    }
                }
                finally {
                    iRecordsLeftToProcess--;
                }
            }
        }
        catch (EOFException e) {
            if (log4jDebugLogger.isDebugEnabled()) {
                log4jDebugLogger.debug("Socket closed by subsystem - " + channel);
            }
            closeSocket = true;
        }
        catch (IOException e) {
            log4jDebugLogger.warn("Met I/O error reading log record from socket: "
                + channel + ". Close it.", e);

            closeSocket = true;
        }
        catch (Exception e) {
            log4jDebugLogger.warn("Met a Runtime Exception reading log record from socket: ", e);

            closeSocket = true;
        }
        finally {

            if (writeBuf.limit() > 0) {
                mWriter.writeByteBuffer(writeBuf);
                writeBuf.limit(0);
            }

            readBuf.compact();
            readBuf.flip();

            if (!mIsStarted) {
                closeSocket = true;
            }

            if (closeSocket) {
                if (channel != null) {
                    try {
                        if (channel.isConnected()) {
                            channel.close();
                        }
                    }
                    catch(IOException ie) {
                        log4jDebugLogger.error("Unable to close socket:" + channel, ie);
                    }
                }

                try {
                    putToReturnChannel(channel);
                }
                catch (IOException e) {
                    log4jDebugLogger.error("Unable to return channel to selector - " +
                        channel, e);
                }
                channelWrapper = setELCOverloadInfo(channelWrapper, false);
                return false;
            }
        }

        return true;
    }

    /**
     * Set ELC overload info in Overload controller and in SocketChannelWrapper object.
     * @param socketChannel The SocketChannelWrapper object
     * @param trigger a boolean flag indicating if ELC reader is overloaded
     * @return SocketChannelWrapper object
     */
    private SocketChannelWrapper setELCOverloadInfo(SocketChannelWrapper socketChannel,
                                                    boolean trigger) {
        if (trigger) {
            if (hasSetELCOverloadFlag() == false) {
                setELCOverloadFlag(trigger);
                moOverloadControllerRef.setMaxReadTrigger(trigger);
                log4jDebugLogger.warn("ELC consecutive " + miOverloadConsecutiveReads + " times read " + miChannelReaderBufferSize + " bytes logs at " + new Date());
            }
        }
        else {
            if (hasSetELCOverloadFlag()) {
                setELCOverloadFlag(trigger);
                moOverloadControllerRef.setMaxReadTrigger(trigger);
                socketChannel.resetNumberConsecutiveMaxReads();
                log4jDebugLogger.warn("ELC comes back to normal condition at " + new Date());
            }
        }
        return socketChannel;
    }

    /**
     * Places the channel into return pipe for returning to selector.
     *
     * This is done in two steps:
     * (1) channel itself is placed into returnDataChannel
     * (2) message about that placed into signalling channel
     *
     * @param channel  the channel to return
     *
     * @throws IOException if there is problem with the return channel.
     */
    private void putToReturnChannel(SocketChannel channel)
        throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(1);

        buffer.put(RC_ADD_TO_READ);

        buffer.flip();

        synchronized (returnChannelLock) {
            Pipe.SinkChannel writeEnd = mReturnSignalingChannel.sink();

            if (writeEnd != null) {
                writeEnd.write(buffer);

                mReturnSockets.offer(channel);
            }
        }
    }

    /**
     * Gets channel from the return pipe.
     *
     * This is done in two steps:
     * (1) channel itself is extracted from returnDataChannel
     * (2) message about the extracted from signalling channel
     *
     * @return channel extracted from the return pipe
     *
     * @throws IOException if there is problem with the return channel.
     */
    private SocketChannel getFromReturnChannel() throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(1);
        SocketChannel channel = null;

        synchronized (returnChannelLock) {
            if (mReadEnd != null) {
                mReadEnd.read(buffer);

                channel = mReturnSockets.poll();
            }
        }
        return channel;
    }

    /**
     * Sends a CSP control record on statistics of the received/dropped logs.
     */
    private void sendControlRecord() {

        synchronized(this) {
            mTotalLogsReceived += mNumLogsReceived;
            mTotalBytesReceived += mNumBytesReceived;
            mTotalBytesDropped += mNumBytesDropped;
            mTotalLogsDropped += mNumLogsDropped;

            if (log4jDebugLogger.isEnabledFor(Level.WARN)) {

                log4jDebugLogger.warn("ELC Statistics:"
                    + "\n logs received=" + mNumLogsReceived + ", total=" + mTotalLogsReceived
                    + ", bytes received=" + mNumBytesReceived + ", total=" + mTotalBytesReceived
                    + "\n logs dropped=" + mNumLogsDropped + ", total=" + mTotalLogsDropped
                    + ", bytes dropped=" + mNumBytesDropped + ", total=" + mTotalBytesDropped);

                
                Date now = new Date(System.currentTimeMillis());
                String szTimeStamp = mDateFormatter.format(now);

                //The following messages are for spreadsheet reader.
                log4jDebugLogger.warn(HEADER_BYTE_LOST_REPORT + "\n"
                    + DATA_BYTE_LOST_REPORT + ", "
                    + szTimeStamp + ", "
                    + mNumLogsReceived + ", "
                    + mTotalLogsReceived + ","
                    + mNumBytesReceived + ", "
                    + mTotalBytesReceived + ", "
                    + mNumLogsDropped + ", "
                    + mTotalLogsDropped + ", "
                    + mNumBytesDropped + ", " + mTotalBytesDropped + "\n");
            }
            mNumBytesDropped = 0;
            mNumBytesReceived = 0;
            mNumLogsDropped = 0;
            mNumLogsReceived = 0;
        }

        CSPControlRecordHeader header = null;

        Date date = new Date();

        try {
            header = CSPControlRecordHeader.getNextHeader(SOURCE_ID_ELC, LOG_TYPE_ELC);
        }
        catch(IllegalArgumentException e){
            log4jDebugLogger.error("Failed to construct CSPControlRecordHeader."
                + "CSP control record not send at " + date , e);

            return;
        }

        CSPControlRecordData recordData = new CSPControlRecordData(header,
            "ELC statistics", mTotalLogsReceived, mTotalLogsDropped);

        byte [] oPayload = recordData.getBytes();

        int recordLength = oPayload.length + RECORD_LENGTH_SIZE;

        ByteBuffer oRecord =  ByteBuffer.allocate(recordLength); //payload + length field

        oRecord.putShort((short) recordLength);
        oRecord.put(oPayload);
        oRecord.flip();
        oRecord.limit(oRecord.position() + recordLength);
        mWriter.writeByteBuffer(oRecord);
    }

    /**
     * Closes selector and all sockets.
     */
    private synchronized void closeAll() {
        closeSelector();

        closeServerClientSocket();

    }

    /**
     * Closes all client sockets.
     */
    private void closeClientSockets() {
        Iterator<SocketChannel> iter = mClientSockets.iterator();
        int numSockets = 0;

        while(iter.hasNext()) {
            numSockets++;

            SocketChannel channel = iter.next();

            iter.remove();

            if(channel != null) {
                try {
                    channel.close();
                }
                catch(IOException e) {
                    log4jDebugLogger.error("Unable to close channel: " + channel, e);
                }
            }

            channel = null;
        }

        if (log4jDebugLogger.isInfoEnabled()) {
            log4jDebugLogger.info("Closed " + numSockets + " sockets.");
        }
    }

    /**
     * Closes server and associated client sockets.
     */
    private void closeServerClientSocket() {
        closeClientSockets();

        if (mServerSocket != null) {
            try {
                mServerSocket.close();
            }
            catch (IOException e) {
                log4jDebugLogger.error("Unable to close server socket.", e);
            }
        }

        mServerSocket = null;

        if (mServerSocketChannel != null){
            try {
                mServerSocketChannel.close();
            }
            catch(IOException e) {
                log4jDebugLogger.error("Unable to close server socket channel.", e);
            }
        }

        mServerSocketChannel = null;
    }

    /**
     * Closes selector.
     */
    private void closeSelector() {
        if(mSelector != null) {
            try {
                mSelector.close();
            }
            catch (IOException e) {
                log4jDebugLogger.error("Unable to close selector.", e);
            }
        }

        mSelector = null;

        if(mReadEnd != null) {
            try {
                mReadEnd.close();
            }
            catch (IOException e) {
                log4jDebugLogger.error("Unable to close readEnd of returnSignalingChannel.", e);
            }
        }

        mReadEnd = null;

        if (mReturnSignalingChannel != null) {
            try {
                Pipe.SinkChannel writeEnd = mReturnSignalingChannel.sink();

                if (writeEnd != null) {
                    writeEnd.close();
                }

                writeEnd = null;
            }
            catch (IOException e) {
                log4jDebugLogger.error("Unable to close writeEnd of returnSignalingChannel.", e);
            }
        }
    }

    /**
     * handle the action required by OverloadController.
     * @param iType the log type
     * @param iLevel the level of overload action
     */
    public void handleOverloadChange(int iType, int iLevel) {

        if (iLevel >= FILTER_LOW_VALUE_ATTRIBUTE) {
            if (!mbHandleOverloading) {
                mbHandleOverloading = true;
                Date now = new Date(System.currentTimeMillis());
                CSLUtil.createJournalLog(CallSummaryLogMessageCategory.OVERLOADING_FILTER_LOWVALUE_ATTRIBUTE,
                    new String [] {now.toString()});
            }
        }
        else {
            if(mbHandleOverloading) {
                Date now = new Date(System.currentTimeMillis());
                CSLUtil.createJournalLog(CallSummaryLogMessageCategory.ABATED_OVERLOADING_ALLOW_LOWVALUE_ATTRIBUTE,
                    new String [] {now.toString()});
            }
            mbHandleOverloading = false;
        }

        OverloadController.getInstance().notifyWhenDone(this );
    }

    /**
     * Return the class name.
     */
    public String getIdentifier() {
        return (this.getClass().getName());
    }


    /**
     * If there are some changes in CEMS DB regarding UploadProfileInfo attribute
     * group, then retrieves the updated destination port info and restart the
     * socket connection.
     * @param portId the destination port Id
     */
    public void handleUploadProfileInfoUpdate(short portId)  {

        if (portId !=  mInPort) {

            //update the cached values only if it is changed.
            mInPort = portId;

            if (log4jDebugLogger.isDebugEnabled()) {
                log4jDebugLogger.debug("Got updated  port = " + mInPort);
            }

            //re-open server socket using the new port Id.
            selectiveRestart();
        }
    }

    /**
     * Checks if a log type should be allowed.
     *
     * @param readBuf  The buffer to be read.
     *
     * @return true if the log type should be allowed; false if it should be
     * filtered out.
     *
     * @throws IllegalArgumentException if the log type is invalid
     */
    private boolean isLogTypeAllowed(ByteBuffer readBuf) {

        //Under overloading state, need to check the filter array based on
        //CSLPRofile.OverloadAttributeFilterGroup as well.  If the attribute corresponding
        //boolean value in one of the arrays is false, then the related the log will be
        //dropped.

        int iRecordPayloadStartIndex = readBuf.position();

        // payload[1] -> message class
        // payload[2] -> log type
        int iLogType = readBuf.get(iRecordPayloadStartIndex + 2);

        int index = Collections.binarySearch(mOverLoadingLogTypeFilters, iLogType);
        if (index < 0) {
            return false;
        }
        return true;
    }

    /**
     * Attempts to read data into the byte buffer. If no bytes are read after
     * a number of attempts, 0 is returned.
     *
     * @param channel The channel to read from
     * @param buf The byte buffer to read into
     *
     * @return The number of bytes read
     *
     * @throws IOException in the event of an error
     */
    private int readFromByteBuffer(SocketChannel channel, ByteBuffer buf)
        throws IOException {
        int bytesRead = channel.read(buf);

        if (bytesRead != 0) {
            return bytesRead;
        }

        int retryAttempts = miNoDataRetryInternal;

        long sleepTime = miNoDataSleep;

        for (int i = 0; i < retryAttempts && bytesRead == 0; i++) {
            try {
                Thread.sleep(sleepTime);
            }
            catch(InterruptedException e) {
            }

            try {
                bytesRead = channel.read(buf);
            }
            catch (IOException e) {
                throw new EOFException();
            }

            sleepTime += miNoDataSleepIncrement;
        }

        return bytesRead;
    }

    /**
     * Reading ELC overload flag accessor.
     *
     * @return the flag
     */
    public boolean hasSetELCOverloadFlag() {
        return mbHasSetELCOverloadFlag;
    }

    /**
     * Set ELC overload flag.
     *
     * @param flag the ELC overload flag
     */
    public synchronized void setELCOverloadFlag (boolean flag) {
        mbHasSetELCOverloadFlag = flag;
    }
    
    private synchronized int evaluateRecordsLeftToProcess(int bytesRead, SocketChannelWrapper channelWrapper, 
                                                 SocketChannel channel, int iRecordsLeftToProcess) {
        
/*        if (bytesRead == 0) {
            channelWrapper =  setELCOverloadInfo(channelWrapper, false);
            int readAttempts =
                channelWrapper.incrementUnsuccessfulReadAttempts();

            if (readAttempts >= miNoDataMaxRetryBeforeClose) {
                log4jDebugLogger.info("Maximum number of unsuccessful " +
                    "reads reached for channel: " +
                    channel + ".");
                closeSocket = true;

                return false;
            }
            else if (readAttempts == 3) {
                channelWrapper.decrementFairShareRecordCount();
            }
            return true;
        }*/
        if (bytesRead == miChannelReaderBufferSize ) {
            int iConsecutiveMaxReads = channelWrapper.increaseNumberConsecutiveMaxReads();

            if (iConsecutiveMaxReads == miOverloadConsecutiveReads) {

                //call OverloadController to set the overload flag
                channelWrapper =  setELCOverloadInfo(channelWrapper, true);
            }
            else {
                if ( (1.0 * iConsecutiveMaxReads) / miOverloadConsecutiveReads > 0.40) {
                    channelWrapper.incrementFairShareRecordCount();
                    iRecordsLeftToProcess += channelWrapper.getFairShareIncrement();
                }
            }
        }
        else {
            channelWrapper =  setELCOverloadInfo(channelWrapper, false);
        }
     //   channelWrapper.resetUnsuccessfulReadAttempts();
        return iRecordsLeftToProcess;
    }

    /**
     * Socket channel state class.
     */
    private static class SocketChannelWrapper {
        /**
         * The socket channel.
         */
        private SocketChannel moSocketChannel;

        /**
         * The byte buffer used to read from the socket channel.
         */
        private ByteBuffer moReadByteBuffer;

        /**
         * The byte buffer used to write to the socket channel. It shares the
         * same byte-array storage with the read byte buffer.
         */
        private ByteBuffer moWriteByteBuffer;

        /**
         * Flag indicating if reading has started.
         */
        private boolean mbHasReadingStarted;

        /**
         * The total number of bytes read from this channel.
         */
        private int miTotalBytesRead;

        /**
         * The current number of unsuccessful read attempts.
         */
        private int miCrtUnsuccessfulReadAttempts;

        /**
         *  The number of consecutive max readers.
         */
        private int miNumberConsecutiveMaxReads;

        /**
         *  The number indicating fair share record count.
         */
        private int miFairshareRecordCount;

        /**
         *  The number indicating fair share  increment.
         */
        private final int miFairshareIncrement = 150;

        /**
         *  The number indicating fair share decrement.
         */
        private int miFairshareDecrement = 20;

        /**
         * The remote IP address.
         */
        private String mszRemoteIpAddress = null;

        /**
         * The remote port Id.
         */
        private int miRemotePort = 0;
        /**
         * Constructor.
         *
         * @param socketChannel The socket channel
         * @param bufSize The read buffer size
         * @param iFairshareRecordCount The number of fairshare record
         */
        public SocketChannelWrapper(SocketChannel socketChannel, int bufSize, int iFairshareRecordCount) {
            moSocketChannel = socketChannel;

            Socket oSocket = moSocketChannel.socket();

            if (oSocket != null) {
                InetAddress oIPAdd = oSocket.getInetAddress();

                if (oIPAdd != null) {
                    mszRemoteIpAddress = oSocket.getInetAddress().getHostAddress();
                }

                miRemotePort = oSocket.getPort();
            }

            moReadByteBuffer = ByteBuffer.allocate(bufSize);
            moWriteByteBuffer = moReadByteBuffer.duplicate();
            mbHasReadingStarted = false;
            miTotalBytesRead = 0;
            miCrtUnsuccessfulReadAttempts = 0;
            miNumberConsecutiveMaxReads = 0;
            miFairshareRecordCount = iFairshareRecordCount;
        }

        /**
         * Returns the address to which the socket is connected.
         *
         * @return  the remote IP address to which this socket is connected,
         *		or <code>null</code> if the socket is not connected.
         */
        public String getRemoteIpAddress() {
            return ( mszRemoteIpAddress );
        }


        /**
         * Returns the remote port to which this socket is connected.
         *
         * @return  the remote port number to which this socket is connected, or
         *	        0 if the socket is not connected yet.
         */
        public int getRemotePort() {
            return ( miRemotePort );
        }
        /**
         * Socket channel accessor.
         *
         * @return The socket channel.
         */
        public SocketChannel getSocketChannel() {
            return moSocketChannel;
        }

        /**
         * Read byte buffer accessor.
         *
         * @return The byte buffer used to read data from the channel
         */
        public ByteBuffer getReadByteBuffer() {
            return moReadByteBuffer;
        }

        /**
         * Gets the fair share record count used to read data from the channel.
         * @return The fair share record count used to read data from the channel
         */
        public int getFairShareIncrement() {
            return miFairshareIncrement;
        }

        /**
         * Sets the fair share record count used to read data from the channel.
         * @param iFairshareRecordCount the fair share record count
         */
        public void setFairShareRecordCount(int iFairshareRecordCount) {
            miFairshareRecordCount = iFairshareRecordCount;
        }

        /**
         * Increments the fair share record count used to read data from the channel.
         */
        public  void incrementFairShareRecordCount() {
            if (miFairshareRecordCount < 500) {
                miFairshareRecordCount += miFairshareIncrement;
            }
        }

        /**
         * Decrements the fair share record count used to read data from the channel.
         */
        public  void decrementFairShareRecordCount() {
            if (miFairshareRecordCount > 60) {
                miFairshareRecordCount -= miFairshareDecrement;
            }
        }

        /**
         * Write byte buffer accessor.
         *
         * @return The byte buffer used to write data to the channel
         */
        public ByteBuffer getWriteByteBuffer() {
            return moWriteByteBuffer;
        }

        /**
         * Reading start flag accessor.
         *
         * @return the flag
         */
        public boolean hasReadingStarted() {
            return mbHasReadingStarted;
        }

        /**
         * Reading start flag setter.
         *
         * @param flag the reading start flag
         */
        public void setHasReadingStarted(boolean flag) {
            mbHasReadingStarted = flag;
        }

        /**
         * Add one more consecutive max read.
         @return  The total number of consecutive max reads which has been incremented
         */
        public int increaseNumberConsecutiveMaxReads() {
            miNumberConsecutiveMaxReads ++;
            return miNumberConsecutiveMaxReads;
        }

        /**
         * Reset consecutive max read counter.
         *
         */
        public void resetNumberConsecutiveMaxReads() {
            miNumberConsecutiveMaxReads = 0;
        }

        /**
         * Total bytes read accessor.
         *
         * @return The total number of bytes read from this channel
         */
        public int getTotalBytesRead() {
            return miTotalBytesRead;
        }

        /**
         * Record more bytes read from this channel.
         *
         * @param bytesRead The number of read bytes
         */
        public void addBytesRead(int bytesRead) {
            miTotalBytesRead += bytesRead;
        }

        /**
         * Current unsuccesful read attempts accessor.
         *
         * @return The current number of unsuccessful read attempts
         */
        public int getUnsuccessfulReadAttempts() {
            return miCrtUnsuccessfulReadAttempts;
        }

        /**
         * Resets the current number of unsuccessful read attempts.
         */
        public void resetUnsuccessfulReadAttempts() {
            miCrtUnsuccessfulReadAttempts = 0;
        }

        /**
         * Increments the current number of unsuccessful read attempts.
         *
         * @return The current number of unsuccessful read attempts
         */
        public int incrementUnsuccessfulReadAttempts() {
            miCrtUnsuccessfulReadAttempts++;

            return miCrtUnsuccessfulReadAttempts;
        }

        /**
         * Debug representation.
         *
         * @return A debug representation of this object.
         */
        public String toString() {
            return moSocketChannel.toString();
        }
    }
}
