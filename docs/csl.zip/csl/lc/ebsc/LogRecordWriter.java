/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.lc.ebsc;

import java.nio.ByteBuffer;

/**
 *   The class presents an interface to stream log writer.
 */
public interface LogRecordWriter {

  /**
   * Writes log data to stream log server.
   * @param buf the buffer contains the data to write
   */
  public void writeByteBuffer(ByteBuffer buf);
}
