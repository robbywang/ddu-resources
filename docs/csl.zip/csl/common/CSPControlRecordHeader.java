/*
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.common;

// Java
import java.nio.ByteBuffer;
import java.nio.BufferUnderflowException;

import org.apache.log4j.Logger;

import com.nortel.cdma.service.csl.common.CSLUtil;

/**
 * This class represents the CSP control record header.
 */
public class CSPControlRecordHeader {
  /**
   * Instance of Log4j Logger.
   */
  private static final Logger log4jDebugLogger =
                       Logger.getLogger(CSPControlRecordHeader.class);

  /**
   * Constant represents the CSP Node Type as defined in SLog schema.
   */
  private static final byte NODE_TYPE_CSP = 2;

  /**
   * Constant represents the CSP control record message class as
   * defined in SLog schema.
   */
  private static final byte MESSAGE_CLASS_CONTROL_LOG = 2;

  /**
   * The CSP control record log type as defined in SLog schema.
   */
  private static  byte mbCSP_logType;

  /**
   * Constant represents the log version.
   */
  private static final byte LOG_VERSION = 1;

  /**
   * The common header.
   */
  private SLogCommonHeader mCommonHeader;     // 16 bytes

  /**
   * The csp IP in string format.
   */
  private String mCspIP;

  /**
   * The csp IP in bytes.
   */
  private byte[] mIPInBytes;                  // 4 bytes

  /**
   * The source Id.
   */
  private byte mSourceId;                     // 1 byte

  /**
   * CSP control record sequence number.
   */
  private static int mControlRecordSequenceNumber = 0;



  /**
   * Constructor.
   *
   * @param commonHeader  The streaming log common header
   * @param cspIP         The IP address of the CSP
   * @param sourceId      The CSL application ID
   * @param logType       The Log type
   * @throws              IllegalArgumentException
   */
  private CSPControlRecordHeader(SLogCommonHeader commonHeader,
                                String cspIP, byte sourceId, byte logType)
    throws IllegalArgumentException {
    mbCSP_logType = logType;
    init(commonHeader, cspIP, sourceId);
  }

  /**
   * Constructor.
   *
   * @param sourceId       The CSL application ID
   * @param logType        The log type
   * @throws               IllegalArgumentException
   */
  private CSPControlRecordHeader(byte sourceId, byte logType)
         throws IllegalArgumentException {
    mbCSP_logType = logType;
    init(sourceId);
  }

  /**
   * Return the CSPControlRecordHeader initialized with the next available sequence number.
   * @param sourceId       The CSL application ID
   * @param logType        The log type
   * @return    an instance of this class initialized with the next available sequence number
   * @throws               IllegalArgumentException
   */
  public static synchronized CSPControlRecordHeader getNextHeader(byte sourceId, byte logType)
    throws IllegalArgumentException {

    mControlRecordSequenceNumber++;
    return new CSPControlRecordHeader(sourceId, logType);
  }

  /**
   * Returns the header length.
   *
   * @return the header length
   */
  public int length() {
    return mCommonHeader.length() + 4  // 4 bytes for IP address
                                  + 1; // 1 byte for source id
  }

  /**
   * CSP IP accessor.
   *
   * @return  The CSP IP
   */
  public String getCspIP() {
    return mCspIP;
  }

  /**
   * Source ID accessor.
   *
   * @return  The CSL application ID
   */
  public byte getSourceId() {
    return mSourceId;
  }

  /**
   * Returns this object in byte array.
   *
   * @return this object in byte array
   */
  public byte[] getBytes() {
    ByteBuffer buffer = writeToBuffer();

    return buffer.array();
  }

  /**
   * Constructs a CSPControlRecordHeader object from a log record.
   *
   * @param record  The log record to construct the CSPControlRecordHeader
   *
   * @return a CSPControlRecordHeader object, null if argument is null or
   *         an error occurred
   */
  public static CSPControlRecordHeader read(LogRecord record) {
    if (record == null) {
      return null;
    }

    return read(record.getBytes());
  }

  /**
   * Constructs a CSPControlRecordHeader object from a byte array.
   *
   * @param bytes  The byte array to construct the CSPControlRecordHeader
   *
   * @return a CSPControlRecordHeader object, null if argument is null,
   *         empty, or an error occurred
   */
  public static CSPControlRecordHeader read(byte[] bytes) {
    if (bytes == null || bytes.length == 0) {
      return null;
    }

    ByteBuffer buffer = ByteBuffer.wrap(bytes);

    return read(buffer);
  }

  /**
   * Reads a CSPControlRecordHeader object from a byte buffer.
   *
   * @param buffer  The byte buffer to read from
   *
   * @return a CSPControlRecordHeader object, null if argument is null or
   *         an error occurred
   */
  public static CSPControlRecordHeader read(ByteBuffer buffer) {
    CSPControlRecordHeader header = null;

    if (buffer == null) {
      return header;
    }

    try {
      SLogCommonHeader commonHeader = SLogCommonHeader.read(buffer);

      if (commonHeader == null) {
        log4jDebugLogger.error("got null SLogCommonHeader");
        return header;
      }

      byte logType = commonHeader.getLogType();
      byte[] ipBytes = new byte[4];
      buffer.get(ipBytes);

      String ipString = LogDataConversionUtil.convertIpBytesToString(ipBytes);

      byte sourceId = buffer.get();

      header = new CSPControlRecordHeader(commonHeader, ipString, sourceId, logType);
    }
    catch (BufferUnderflowException e) {
      log4jDebugLogger.error("Cannot read CSPControlRecordHeader from the"
                             + " ByteBuffer", e);
    }

    return header;
  }

  /**
   * Writes this object to a byte buffer.
   *
   * @return  The byte buffer containing this object
   */
  private ByteBuffer writeToBuffer() {
    ByteBuffer buffer = ByteBuffer.allocate(length());

    buffer.put(mCommonHeader.getBytes());

    buffer.put(mIPInBytes);

    buffer.put(mSourceId);

    return buffer;
  }

  /**
   * Returns a string representation of this object.
   *
   * @return  The string representation of this object
   */
  public String toString() {
    StringBuffer strBuffer = new StringBuffer();
    strBuffer.append(mCommonHeader.toString());
    strBuffer.append(", cspIp = ").append(mCspIP);
    strBuffer.append(", sourceId = ").append(mSourceId);
    return strBuffer.toString();
  }

  /**
   * Initializes the data members.
   *
   * @param sourceId      The CSL application ID
   *
   * @throws              IllegalArgumentException
   */
  private void init(byte sourceId) throws IllegalArgumentException {
     SLogCommonHeader commonHeader = new SLogCommonHeader(
                                         NODE_TYPE_CSP,
                                         MESSAGE_CLASS_CONTROL_LOG,
                                         mbCSP_logType, LOG_VERSION,
                                         CSLUtil.getCurrentCDMATime(),
                                         mControlRecordSequenceNumber);


     // Get the CSPIdentifier.
     String szCSPId = CSLUtil.getCSPID();
     init(commonHeader, szCSPId, sourceId);
  }


  /**
   * Initializes the data members.
   *
   * @param commonHeader  The streaming log common header
   * @param cspIP         The IP address of the CSP
   * @param sourceId      The CSL application ID
   *
   * @throws              IllegalArgumentException
   */
  private void init(SLogCommonHeader commonHeader, String cspIP,
                    byte sourceId) throws IllegalArgumentException {

    if (commonHeader == null) {
      throw new IllegalArgumentException("CSPControlRecordHeader: "
                                         + "Null SLogCommonHeader");
    }

    mCommonHeader = commonHeader;

    if (cspIP == null || cspIP.length() == 0) {
      throw new IllegalArgumentException("CSPControlRecordHeader: "
                                         + "Null or empty cspIP");
    }

    mCspIP = cspIP;

    mIPInBytes = LogDataConversionUtil.convertIpStringToBytes(cspIP);

    mSourceId = sourceId;
  }
}
