/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

package com.nortel.cdma.service.csl.common;
import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.elements.AttributeGroup;
import com.nortel.cdma.common.data.elements.Attribute;
import com.nortel.cdma.common.data.elements.AttributeData;
import com.nortel.cdma.common.data.elements.DataIPAddressV4;
import com.nortel.cdma.common.data.elements.DataUShort;
import com.nortel.cdma.common.data.autogen.LocalName;

import java.util.Map;
import java.util.Set;
import java.util.Iterator;

import org.apache.log4j.Logger;

/**
 * This class provides methods to retrieve UploadProfileInfo regarding CSL from eBSC ME.
 */

public class UploadProfileCSLInfo  {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(UploadProfileCSLInfo.class);

  /**
   *  The StreamLogServerIPAddress.
   */
  private String mszStreamLogServerIPAddress;

  /**
   *  The destination (SLS) Port Id .
   */

  private short msDstinationPortId = -1;

  /**
   *  The source (ELC) Port Id .
   */

  private short msSourcePortId = -1;

  /**
   * Flag indicates if the object is valid.
   */

  private boolean isValid = false;

  /**
   * Attribute group name for UploadProfileInfo.
   */
  public final static String UPLOADPROFILE_INFO_GRP =
    LocalName.ELM_eBSC.ATTGRP_UploadProfileInfo_GRP.TYPE_NAME;

  /**
   * Attribute name for  ATT_StreamLogServerIPAddress.
   */
  public final static String SLS_HOSTNAME =
    LocalName.ELM_eBSC.ATTGRP_UploadProfileInfo_GRP.ATT_StreamLogServerIPAddress;

  /**
   * Attribute name for  ATT_DestinationPortStreamLog.
   */
  public final static String DESTINATION_PORT =
    LocalName.ELM_eBSC.ATTGRP_UploadProfileInfo_GRP.ATT_DestinationPortStreamLog;

  /**
   * Attribute name for  ATT_SourcePortStreamLog.
   */
  public final static String SOURCE_PORT =
    LocalName.ELM_eBSC.ATTGRP_UploadProfileInfo_GRP.ATT_SourcePortStreamLog;


  /**
   * constructor.
   * @param me the ManagedElement object
   */

  public  UploadProfileCSLInfo (ManagedElement me) {
    getUploadProfileInfo(me);

  }

  /**
   * The method scans the notification record and build the data objects
   * for the further processing.
   * @param me The ManagedElemen object
   */
  private void  getUploadProfileInfo (ManagedElement me) {

    AttributeGroup oAttGrp = null;

    if (me == null) {
      log4jDebugLogger.error("null ManagedElement passed in");
      return;
    }

    oAttGrp = me.getAttributeGroup(UPLOADPROFILE_INFO_GRP);
    String meFDN = me.getName().toString();

    if (oAttGrp == null) {
      log4jDebugLogger.warn("Got null AttributeGrp, AttGrpName is: " + UPLOADPROFILE_INFO_GRP + 
          " me FDN is : " + meFDN);
      return;
    }

    Map oMap = oAttGrp.getAllAttributes();

    if (oMap == null) {
      log4jDebugLogger.warn("Got null Map for all attributes, AttGrpName is: " + UPLOADPROFILE_INFO_GRP + 
          " me FDN is : " + meFDN);
      return;
    }

    Set oKeys = oMap.keySet();
    if ((oKeys == null) || (oKeys.size() ==0)) {
      log4jDebugLogger.warn("Got empty keys from the attribute group, AttGrpName is: " + UPLOADPROFILE_INFO_GRP +
          " me FDN is : " + meFDN);
      return;
    }

    for (Iterator it = oKeys.iterator(); it.hasNext();) {
      Attribute oAtt = (Attribute)oMap.get(it.next());
      if (oAtt == null) {
        log4jDebugLogger.warn("Got null Attribute object from the attribute group, AttGrpName is: " + UPLOADPROFILE_INFO_GRP + 
            " me FDN is : " + meFDN);
        continue;
      }
      String localName = oAtt.getLocalName();
      AttributeData oAttData = oAtt.getValue();
      if (oAttData == null) {
        log4jDebugLogger.warn("Got null AttributeData object from the attribute group, AttGrpName is: " + UPLOADPROFILE_INFO_GRP + 
            " me FDN is : " + meFDN);
        continue;
      }

      if (localName.equals(SLS_HOSTNAME)) {
        String szServer = ((DataIPAddressV4) oAttData).toString();
        if (szServer != null) {
          //update the cached values only if it is changed.
          mszStreamLogServerIPAddress = szServer;
          if (log4jDebugLogger.isDebugEnabled()) {
            log4jDebugLogger.debug("Got StreamLogServerIPAddress = " + mszStreamLogServerIPAddress);
          }
        }
      }
      else if (localName.equals(DESTINATION_PORT))  {
        Integer slsPortId = ((DataUShort) oAttData).toInteger();
        if (slsPortId != null) {
          msDstinationPortId =  slsPortId.shortValue();
          if (log4jDebugLogger.isDebugEnabled()) {
            log4jDebugLogger.debug("Got DestinationPortId = " + msDstinationPortId);
          }
        }
      }
      else if (localName.equals(SOURCE_PORT))  {
        Integer elcPortId = ((DataUShort) oAttData).toInteger();
        if (elcPortId != null) {
          msSourcePortId =  elcPortId.shortValue();
          if (log4jDebugLogger.isDebugEnabled()) {
            log4jDebugLogger.debug("Got SourcePortId = " + msSourcePortId);
          }
        }
      }
    }

    //if there is no issue to retrieve the attribute values from the ME, set the validity
    //flag to true.

    if (((mszStreamLogServerIPAddress != null) || (msDstinationPortId != -1) || (msSourcePortId != -1))) {
      isValid = true;
    }
  }

  /**
   * Return the destination port Id.
   * @return  the  destination port Id
   */
  public short getDestinationPortId () {
    return msDstinationPortId;
  }

  /**
   * Return the source port Id.
   * @return  the source port Id
   */
  public short getSourcePortId () {
    return msSourcePortId;
  }

  /**
   * Return the streamLogServer IPAddress.
   * @return the streamLogServer IPAddress
   */
  public String getStreamLogServerIPAddress () {
    return mszStreamLogServerIPAddress;
  }

  /**
   *  Returns the object validity.
   * @return true if the object contains valid UploadProfile info; false otherwise
   */
  public boolean isValid () {
    return isValid;
  }
}

/**
 * Inner class to get ExternalServerConfig attribute group value from CSLProfile ME.
 */
