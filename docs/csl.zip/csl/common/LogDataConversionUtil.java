/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.common;

// Java
import java.io.IOException;

import java.nio.ByteBuffer;
import java.nio.BufferUnderflowException;
import java.nio.CharBuffer;

import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;

import org.apache.log4j.Logger;

/**
 * This is a utility class for converting log data from byte array to
 * object or vice versa.
 */
public class LogDataConversionUtil {
  /**
   * Instance of Log4j Logger. 
   */
  private static final Logger log4jDebugLogger = 
                       Logger.getLogger(LogDataConversionUtil.class);

  /**
   * Constants represents the number of bytes of IP address.
   */
  private static final int IP_BYTE_LEN = 4;

  /**
   * Private constructor so nobody can instantiate this class.
   */
  private LogDataConversionUtil() {
  }

  /**
   * Converts IP address from String format to byte array.
   *
   * @param ip The IP address in String format
   *
   * @return The IP address in byte array
   *
   * @throws IllegalArgumentException if the given ip is invalid
   */
  public static byte[] convertIpStringToBytes(String ip) 
                               throws IllegalArgumentException {
    if(ip == null || ip.length() == 0) {
      throw new IllegalArgumentException("Null or empty IP address");
    }

    String[] ipParts = ip.split("\\.");

    if (ipParts.length != IP_BYTE_LEN) {
      throw new IllegalArgumentException("Invalid IP format: " + ip);
    }

    byte[] ipBytes = new byte[IP_BYTE_LEN];

    for (int i = 0; i < IP_BYTE_LEN; i++) {
      try {
        int ipInt = Integer.parseInt(ipParts[i]);

        ipBytes[i] = (byte)(ipInt & 0xFF);
        
      }
      catch(NumberFormatException e) {
        throw new IllegalArgumentException("IP " + ip + 
                  " contains invalid component:" + ipParts[i]);
      }
    }

    return ipBytes;
  }

  /**
   * Converts IP address from byte array to String.
   *
   * @param ipBytes  The IP address in byte array
   *
   * @return The IP address in String format
   *
   * @throws IllegalArgumentException if the ip byte array is invalid
   */
  public static String convertIpBytesToString(byte[] ipBytes) 
                          throws IllegalArgumentException {
    if(ipBytes == null || ipBytes.length != IP_BYTE_LEN) {
      throw new IllegalArgumentException("IP byte array: invalid data");
    }

    String ipString = "" + (ipBytes[0] & 0xFF) + "." + (ipBytes[1] & 0xFF)
                      + "." + (ipBytes[2] & 0xFF) + "." + (ipBytes[3] & 0xFF);

    return ipString;
  }

  /**
   * Convert text message from byte array to String format.
   *
   * @param bytes  The byte array to convert
   *
   * @return The string format of the byte array, null if argument is
   *         null, empty, or error occurs
   */
  public static String convertBytesToString(byte[] bytes) {
    String msgString = "";

    if (bytes == null || bytes.length == 0) {
      return msgString;
    }

    ByteBuffer buffer = ByteBuffer.wrap(bytes);

    try {
      Charset charset = Charset.forName("ISO-8859-1");

      CharsetDecoder decoder = charset.newDecoder();

      CharBuffer charBuffer = decoder.decode(buffer);

      msgString = charBuffer.toString();     
    }
    catch(IllegalArgumentException e) {
      log4jDebugLogger.error("Cannot convert the byte array to String", e);
    }
    catch(IOException e) {
      log4jDebugLogger.error("Cannot convert the byte array to String", e);
    }

    return msgString;
  }
}
