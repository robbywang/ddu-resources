/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.common;

// Java
import java.nio.ByteBuffer;
import java.nio.BufferUnderflowException;

import org.apache.log4j.Logger;

/**
 * This class represents the streaming log common header.
 */
public final class SLogCommonHeader {
  /**
   * Instance of Log4j Logger. 
   */
  private static final Logger log4jDebugLogger = 
                              Logger.getLogger(SLogCommonHeader.class);

  /**
   * Constant represents the header length.
   */
  private static final int HEADER_LENGTH = 16;

  /**
   * The node type.
   */
  private byte mNodeType;        // 1 byte

  /**
   * The message class.
   */
  private byte mMessageClass;    // 1 byte

  /**
   * The log type.
   */
  private byte mLogType;         // 1 byte

  /**
   * The log version.
   */
  private byte mLogVersion;      // 1 byte

  /**
   * The timestamp.
   */
  private long mTimestamp;       // 8 bytes

  /**
   * The sequence number.
   */
  private int mSequenceNumber;   // 4 bytes

  /**
   * Constructor.
   *
   * @param nodeType        The node type
   * @param messageClass    The message class
   * @param logType         The log type
   * @param logVersion      The log version
   * @param timestamp       The timestamp
   * @param sequenceNumber  The sequence number
   *
   */
  public SLogCommonHeader(byte nodeType, byte messageClass, byte logType,
                   byte logVersion, long timestamp, int sequenceNumber) {
    mNodeType        = nodeType;
    mMessageClass    = messageClass;
    mLogType         = logType;
    mLogVersion      = logVersion;
    mTimestamp       = timestamp;
    mSequenceNumber  = sequenceNumber;
  }

  /**
   * Returns the header length.
   *
   * @return  The header length
   */
  public int length() {
    return HEADER_LENGTH;
  }

  /**
   * Node type accessor.
   *
   * @return  The node type
   */
  public byte getNodeType() {
    return mNodeType;
  }

  /**
   * Message class accessor.
   *
   * @return  The Message class
   */
  public byte getMessageClass() {
    return mMessageClass;
  }

  /**
   * Log type accessor.
   *
   * @return  The log type
   */
  public byte getLogType() {
    return mLogType;
  }

  /**
   * Log version accessor.
   *
   * @return  The log version
   */
  public byte getLogVersion() {
    return mLogVersion;
  }

  /**
   * Timestamp accessor.
   *
   * @return  The Timestamp
   */
  public long getTimestamp() {
    return mTimestamp;
  }

  /**
   * Sequence number accessor.
   *
   * @return  The sequence number
   */
  public int getSequenceNumber() {
    return mSequenceNumber;
  }

  /**
   * Returns this object in byte array.
   *
   * @return this object in byte array
   */
  public byte[] getBytes(){
    ByteBuffer buffer = writeToBuffer();
    
    return buffer.array();
  }

  /**
   * Constructs a SLogCommonHeader object from a log record.
   *
   * @param record  The log record to construct the SLogCommonHeader
   *
   * @return a SLogCommonHeader object, null if argument is null or
   *         an error occurred
   */
  public static SLogCommonHeader read(LogRecord record) {
    if (record == null) {
      return null;
    }

    return read(record.getBytes());
  }

  /**
   * Constructs a SLogCommonHeader object from a byte array.
   *
   * @param bytes  The byte array to construct the SLogCommonHeader with
   *
   * @return a SLogCommonHeader object, null if argument is null or
   *         an error occurred
   */
  public static SLogCommonHeader read(byte[] bytes) {
    if (bytes == null || bytes.length == 0) {
      return null;
    }

    ByteBuffer buffer = ByteBuffer.wrap(bytes);

    return read(buffer);
  }

  /**
   * Reads a SLogCommonHeader object from a byte buffer.
   *
   * @param buffer  The byte buffer to read from
   *
   * @return a SLogCommonHeader object, null if argument is null or
   *         an error occurred
   */
  public static SLogCommonHeader read(ByteBuffer buffer) {
    SLogCommonHeader header = null;

    if (buffer == null) {
      return header;
    }

    try {
      byte nodeType = buffer.get();

      byte messageClass = buffer.get();

      byte logType = buffer.get();

      byte logVersion = buffer.get();

      long timestamp = buffer.getLong();

      int  seqNo = buffer.getInt();

      header = new SLogCommonHeader(nodeType, messageClass, logType,
                                logVersion, timestamp, seqNo); 
    }
    catch(BufferUnderflowException e) {
      log4jDebugLogger.error("Cannot read SLogCommonHeader from the"
                             + " ByteBuffer", e);
    }

    return header;    
  }

  /**
   * Writes this object to a byte buffer.
   *
   * @return The byte buffer that contains this object
   */
  private ByteBuffer writeToBuffer(){
    ByteBuffer buffer = ByteBuffer.allocate(HEADER_LENGTH);

    buffer.put(mNodeType);

    buffer.put(mMessageClass);

    buffer.put(mLogType);

    buffer.put(mLogVersion);

    buffer.putLong(mTimestamp);

    buffer.putInt(mSequenceNumber);

    return buffer;
  }

  /**
   * Returns a string representation of this object.
   *
   * @return  The string representation of this object
   */
  public String toString() {
    StringBuffer buf = new StringBuffer();

    buf.append(", NodeType = 0x").append(Integer.toHexString(mNodeType));

    buf.append(", MessageClass = 0x").append(Integer.toHexString(mMessageClass));

    buf.append(", LogType = 0x").append(Integer.toHexString(mLogType));

    buf.append(", LogVersion = 0x").append(Integer.toHexString(mLogVersion));

    buf.append(", Timestamp = ").append(mTimestamp);

    buf.append(", SequenceNumber = ").append(mSequenceNumber);

    return buf.toString();
  }
}
