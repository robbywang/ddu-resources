/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.common;

// Java
import java.nio.ByteBuffer;
import java.nio.BufferUnderflowException;

import org.apache.log4j.Logger;

/**
 * This class represents the csp control record data.
 */
public class CSPControlRecordData extends BaseCSPControlRecordData {
  /**
   * Instance of Log4j Logger. 
   */
  private static final Logger log4jDebugLogger = 
                       Logger.getLogger(CSPControlRecordData.class);
  /**
   * Number of log records received.
   */
  private long mNumLogsReceived = 0L;

  /**
   * Number of log records dropped.
   */
  private long mNumLogsDropped = 0L;

  /**
   * Constructor.
   *
   * @param header           The csp control record header
   * @param numLogsReceived  The number of log records received
   * @param numLogsDropped   The number of log records dropped  
   * @param controlMessage   The control record text message
   *
   * @throws                IllegalArgumentException
   */
  public CSPControlRecordData(CSPControlRecordHeader header,
                              String controlMessage,
                              long numLogsReceived, 
                              long numLogsDropped) 
                      throws IllegalArgumentException {
    super(header, controlMessage);

    mNumLogsReceived = numLogsReceived;

    mNumLogsDropped = numLogsDropped;
  }
 
  /**
   * Returns the csp control record data length.
   *
   * @return the csp control record data length
   */
  public int length() {
    // 16 = 8 bytes of numLogsReceived + 8 bytes of numLogsDropped
    return super.length() + 16;
  }

  /**
   * Returns the number of log records received.
   *
   * @return  The number of log records received
   */
  public long numLogsReceived() {
    return mNumLogsReceived;
  }

  /**
   * Returns the number of log records dropped.
   *
   * @return  The number of log records dropped
   */
  public long numLogsDropped() {
    return mNumLogsDropped;
  }

  /**
   * Constructs a CSPControlRecordData object from a log record.
   *
   * @param record  The log record to construct the CSPControlRecordData
   *
   * @return a CSPControlRecordData object, null if argument is null or
   *         an error occurred
   */
  public static CSPControlRecordData read(LogRecord record) {
    if (record == null) {
      return null;
    }

    return read(record.getBytes());
  }

  /**
   * Constructs a CSPControlRecordData object from a byte array.
   *
   * @param bytes  The byte array to construct the CSPControlRecordData
   *
   * @return a CSPControlRecordData object, null if argument is null or
   *         an error occurred
   */
  public static CSPControlRecordData read(byte[] bytes) {
    if (bytes == null || bytes.length == 0) {
      return null;
    }

    ByteBuffer buffer = ByteBuffer.wrap(bytes);

    return read(buffer);
  }

  /**
   * Reads a CSPControlRecordData object from a byte buffer.
   *
   * @param buffer  The byte buffer to read from
   *
   * @return a CSPControlRecordData object, null if argument is null or
   *         an error occurred
   */
  public static CSPControlRecordData read(ByteBuffer buffer) {
    CSPControlRecordData data = null;

    if (buffer == null) {
      return data;
    }

    try {
      CSPControlRecordHeader header = CSPControlRecordHeader.read(buffer);

      long numLogsReceived = buffer.getLong();

      long numLogsDropped = buffer.getLong();

      int textMsgLen = (int)buffer.get() & 0xFF;

      byte[] msgBytes = new byte[textMsgLen];

      buffer.get(msgBytes);

      String msgString = LogDataConversionUtil.convertBytesToString(msgBytes);

      data = new CSPControlRecordData(header, msgString, numLogsReceived,
                                      numLogsDropped);    
    }
    catch(BufferUnderflowException e) {
      log4jDebugLogger.error("Cannot read CSPControlRecordData from the"
                             + " ByteBuffer", e);
    }

    return data;
  }

  /**
   * Writes this object to a byte buffer.
   *
   * @return  The byte buffer containing this object
   */
  protected ByteBuffer writeToBuffer() {
    ByteBuffer buffer = ByteBuffer.allocate(length());

    buffer.put(header().getBytes());

    buffer.putLong(mNumLogsReceived);

    buffer.putLong(mNumLogsDropped);

    byte[] ctrlMsgBytes = controlMessage().getBytes();

    buffer.put((byte)(ctrlMsgBytes.length));

    buffer.put(ctrlMsgBytes);

    buffer.putShort(mFooter);

    return buffer;
  }

  /**
   * Returns a string representation of this object.
   *
   * @return  The string representation of this object
   */
  public String toString() {
    StringBuffer buf = new StringBuffer();

    buf.append(super.toString());

    buf.append(", Number of received logs = ").append(numLogsReceived());

    buf.append(", Number of dropped logs = ").append(numLogsDropped());

    String controlMessage = controlMessage();

    if (controlMessage.length() != 0) {
      buf.append(", ").append(controlMessage);
    }  

    return buf.toString();
  }
}
