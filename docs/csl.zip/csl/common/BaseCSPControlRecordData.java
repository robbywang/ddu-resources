/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.common;

// Java
import java.nio.ByteBuffer;

import org.apache.log4j.Logger;

/**
 * This is the base class for csp control record data.
 */
public abstract class BaseCSPControlRecordData {
  /**
   * Instance of Log4j Logger. 
   */
  private static final Logger log4jDebugLogger = 
                 Logger.getLogger(BaseCSPControlRecordData.class);

  /**
   * Constant represents the maximum control message length.
   */
  private static final int CONTROL_MESSAGE_MAX_LEN = 80;

  /**
   * The CSP control record header.
   */
  private CSPControlRecordHeader mHeader;

  /**
   * Control record text message.
   */
  private String mControlMessage = "";

  /**
   * The CSP control record footer.
   * The End-of-marker is hard-coded with value : 0xFAAE
   */
  protected short mFooter = (short)0xFAAE;


  /**
   * Constructor.
   *
   * @param header           The csp control record header
   * @param controlMessage   The control record text message
   *
   * @throws                 IllegalArgumentException
   */
  public BaseCSPControlRecordData(CSPControlRecordHeader header,
                                  String controlMessage)
                              throws IllegalArgumentException {
    if (header == null) {
      throw new IllegalArgumentException(
                "CSPControlRecordData: Null CSPControlRecordHeader");
    }

    mHeader = header;

    if (controlMessage != null) {
      if (controlMessage.length() > CONTROL_MESSAGE_MAX_LEN) {
        // truncate the message
        mControlMessage = controlMessage.substring(0, 77) + "...";

        log4jDebugLogger.warn("Control Message \"" + controlMessage
          + "\" exceeds " +  CONTROL_MESSAGE_MAX_LEN + " characters."
          + " Truncated it to: " + mControlMessage) ;      
      }
      else {
        mControlMessage = controlMessage;
      }
    }
  }
 
  /**
   * Returns the base csp control record data length.
   *
   * @return the base csp control record data length
   */
  public int length() {
    return mHeader.length() + 1 // size of message length
                            + mControlMessage.getBytes().length
                            + 2; // size of footer
  }

  /**
   * Returns the csp control record header.
   *
   * @return the csp control record header
   */
  public CSPControlRecordHeader header() {
    return mHeader;
  }

  /**
   * Returns the control record text message.
   *
   * @return  The control record text message
   */
  public String controlMessage() {
    return mControlMessage;
  }

  /**
   * Returns this object in byte array.
   *
   * @return this object in byte array
   */
  public byte[] getBytes() {
    ByteBuffer buffer = writeToBuffer();

    return buffer.array();
  }

  /**
   * Writes this object to a byte buffer.
   *
   * @return  The byte buffer containing this object
   */
  protected abstract ByteBuffer writeToBuffer();

  /**
   * Returns a string representation of this object.
   *
   * @return  The string representation of this object
   */
  public String toString() {
    return mHeader.toString();
  }
}
