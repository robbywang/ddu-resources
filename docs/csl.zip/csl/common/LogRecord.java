/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.common;

// comm
import com.nortel.cdma.comm.tcp.Utils;

// java
import java.io.EOFException;
import java.io.IOException;

import java.nio.ByteBuffer;

import java.nio.channels.SocketChannel;

import org.apache.log4j.Logger;

/**
 * This class represents a raw stream log record transmitted over TCP.
 *
 */
public class LogRecord {
  /**
   * Instance of Log4j Logger. 
   */
  private static final Logger log4jDebugLogger =
    Logger.getLogger(LogRecord.class);
  /**
   * Constant represents the number of bytes used for record length.
   */
  private static final int RECORD_LENGTH_SIZE = 2;

  /**
   * Log record payload.
   */
  private byte[] mPayload;


  /**
   * Log data type.
   */
  private int miLogType = -1;

  /**
   * Message class type.
   */
  private int miMessageClass = -1;

  /**
   * Constructor.
   *
   * @param data  Log record payload in raw bytes
   */    
  private LogRecord(byte[] data) {
    if (data == null) {
      data = new byte[0];
    }

    if (data.length <3) {
      data = new byte[0];
    }
    else {
      // Node Type(index 0x0),  Message Class (index 0x1) & Log Type (index 0x2)
      miMessageClass = (int)data[1];
      miLogType = (int) data[2];
    }
    mPayload = data;
  }

  /**
   * Returns the log record payload length.
   *
   * @return the log record payload length
   */
  public int length() {
    return mPayload.length;
  }

  /**
   * Returns the log record payload.
   *
   * @return the log record payload
   */
  public byte[] getBytes() {
    byte[] payloadCopy = new byte[mPayload.length];
    System.arraycopy(mPayload, 0, payloadCopy, 0, mPayload.length);

    return payloadCopy;
  }


  /**
   * Returns the log type from the record payload.
   *
   * @return the log type
   */
  public int getLogType() {
    return miLogType;
  }

  /**
   * Returns the log message class from the record payload.
   *
   * @return the log type
   */
  public int getMessageClass() {
    return miMessageClass;
  }

  /**
   * Builds a log record from the given log data.
   *
   * @param data  Log data
   * @return  The log record
   */
  public static LogRecord getLogRecord(byte[] data) {
    if (data == null) {
      data = new byte[0];
    }

    byte[] dataCopy = new byte[data.length];
    System.arraycopy(data, 0, dataCopy, 0, data.length);

    return new LogRecord(dataCopy);

  }

  /**
   * Writes this log record to the socket channel.
   *
   * @param channel  The socket channel to write to
   *
   * @throws IOException if I/O error is encountered during the write
   */
  public void writeRecord(SocketChannel channel) throws IOException {

    Utils.write(channel, getOutputRecord ());
  }

  /**
   * Get the output ByteBuffer which contains the total length field and payload.
   * @return ByteBuffer of the output data
   */
  public ByteBuffer getOutputRecord () {

    int recordLen = RECORD_LENGTH_SIZE + length();

    ByteBuffer record = ByteBuffer.allocate(recordLen);

    // Write the record length
    record.putShort((short)recordLen);

    // Write the record payload
    record.put(mPayload, 0, length());

    record.flip();

    return record;
  }

  /**
   * Read a log record from a socket channel.
   *
   * @param channel  The socket channel to read from
   *
   * @return LogRecord  The log record read from the socket, null if
   *                    nothing to read
   *
   * @throws EOFException if socket is closed by subsystem
   * @throws IOException if I/O error is encountered during the read
   */
  public static LogRecord readRecord(SocketChannel channel)
    throws IOException {
    // Read the record length
    ByteBuffer lenBuffer = ByteBuffer.allocate(RECORD_LENGTH_SIZE);

    int numBytes = channel.read(lenBuffer);

    if (numBytes == -1) {
      throw new EOFException();
    }

    if (numBytes == 0) {
      // Nothing to read
      return null;
    }

    Utils.read(channel, lenBuffer);

    lenBuffer.flip();

    int recordLen = lenBuffer.getShort() & 0xFFFF;

    int dataLen = recordLen - RECORD_LENGTH_SIZE;

    if (dataLen < 0) {
      throw new IOException("Invalid record length: " + recordLen
        + ". Cannot be < 2");
    }

    // Read the payload
    ByteBuffer data = ByteBuffer.allocate(dataLen);

    Utils.read(channel, data);

    return new LogRecord(data.array());
  }

  /**
   * Returns a string representation of the log record.
   *
   * @return a string representation of the log record
   */
  public String toString() {
    StringBuffer buf = new StringBuffer();

    buf.append("Log Record: length = ").append(length() + RECORD_LENGTH_SIZE );

    SLogCommonHeader commonHeader = SLogCommonHeader.read(mPayload);

    if (commonHeader != null) {
      buf.append(commonHeader.toString());
    }

    return buf.toString();
  }
}
