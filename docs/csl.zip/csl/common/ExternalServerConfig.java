/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

package com.nortel.cdma.service.csl.common;

import com.nortel.cdma.common.data.elements.AttributeData;
import com.nortel.cdma.common.data.elements.AttributeGroup;
import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.elements.Attribute;
import com.nortel.cdma.common.data.elements.DataIPAddressV4;
import com.nortel.cdma.common.data.elements.DataUShort;
import com.nortel.cdma.common.data.autogen.LocalName;
import org.apache.log4j.Logger;

import java.util.Map;
import java.util.Set;
import java.util.Iterator;

/**
 * This class provides methods to retrieve  ExternalServerConfig attribute group value from CSLProfile ME.
 */

public class ExternalServerConfig  {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(ExternalServerConfig.class);

  /**
   *  The ExternalServerIPAddress.
   */
  private String mszExternalServerIPAddress;

  /**
   *  The destination (SLS) Port Id .
   */

  private short msExternalServerPortId = -1;

  /**
   * Flag indicates the object's validity.
   */

  private boolean isValid = false;

  /**
   * Attribute name for  ATT_DestinationPort.
   */
  public final static String CAS_PORT = LocalName.ELM_CSLProfile.ATTGRP_ExternalServerConfig.ATT_DestinationPort;

  /**
   * Attribute name for  ATT_ServerHostName.
   */
  public final static String CAS_HOSTNAME = LocalName.ELM_CSLProfile.ATTGRP_ExternalServerConfig.ATT_ServerHostName;


  /**
   * constructor.
   * @param me the ManagedElement object
   */

  public  ExternalServerConfig (ManagedElement me) {
    getExternalServerConfig(me);
  }

  /**
   * The method scans the notification record and build the data objects
   * for the further processing.
   * @parm me the ManagedElement object
   */
  private void  getExternalServerConfig (ManagedElement me) {


    AttributeGroup oAttGrp = null;

    if (me == null) {
      log4jDebugLogger.error("null ManagedElement passed in");
      return;
    }
    String szAttGrpName = LocalName.ELM_CSLProfile.ATTGRP_ExternalServerConfig.TYPE_NAME;
    oAttGrp = me.getAttributeGroup(szAttGrpName);
    String meFDN = me.getName().toString();

    if (oAttGrp == null) {
      log4jDebugLogger.warn("Got null AttributeGrp, AttGrpName is: " + szAttGrpName + 
          " me FDN is : " + meFDN);
      return;
    }

    Map oMap = oAttGrp.getAllAttributes();
    Set oKeys = oMap.keySet();
    if (oKeys == null) {
      log4jDebugLogger.warn("Got null keys from the attribute group, AttGrpName is: " + szAttGrpName + 
          " me FDN is : " + meFDN);
      return;
    }

    for (Iterator it = oKeys.iterator(); it.hasNext();) {
      Attribute oAtt = (Attribute)oMap.get(it.next());
      if (oAtt == null) {
        log4jDebugLogger.warn("Got null Attribute object from the attribute group, AttGrpName is: " + szAttGrpName + 
            " me FDN is : " + meFDN);
        continue;
      }

      String localName = oAtt.getLocalName();
      AttributeData oAttData = oAtt.getValue();
      if (oAttData == null) {
        log4jDebugLogger.warn("Got null AttributeData object from the attribute group, AttGrpName is: " + szAttGrpName + 
            " me FDN is : " + meFDN);
        continue;
      }

      if (localName.equals(CAS_HOSTNAME)) {
        String szServerIP = ((DataIPAddressV4) oAttData).toString();
        if (szServerIP != null) {
          mszExternalServerIPAddress = szServerIP;
        }
      }
      else if (localName.equals(CAS_PORT))  {
        Integer oPortId = ((DataUShort) oAttData).toInteger();
        if (oPortId != null){
          msExternalServerPortId = oPortId.shortValue();
          log4jDebugLogger.debug("Got ExternalServerPortId = " + msExternalServerPortId);
        }
      }
    }
    //if there is no issue to retrieve the attribute values from the ME, set the validity
    //flag to true.

    if ((mszExternalServerIPAddress != null) || (msExternalServerPortId != -1)) {
      isValid = true;
    }
  }

  /**
   * Return the ExternalServerPortId.
   * @return  the ExternalServerPortId
   */
  public short getExternalServerPortId () {
    return msExternalServerPortId;
  }

  /**
   * Return the ExternalServerIPAddress.
   * @return the ExternalServerIPAddress
   */
  public String getExternalServerIPAddress () {
    return mszExternalServerIPAddress;
  }

  /**
   *  Returns the object validity.
   * @return true if the object contains valid external server info; false otherwise
   */
  public boolean isValid () {
    return isValid;
  }
}
