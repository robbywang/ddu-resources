/*
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.common;


// Java
import java.nio.ByteBuffer;
import java.nio.BufferUnderflowException;

import org.apache.log4j.Logger;

/**
 * This class represents the control record sent from SLS to ELC.
 */
public class ELCControlRecordData extends BaseCSPControlRecordData {
  /**
   * Instance of Log4j Logger. 
   */
  private static final Logger log4jDebugLogger = 
                       Logger.getLogger(ELCControlRecordData.class);

  /**
   * The control code.
   */
  private byte mControlCode = 0;

  /**
   * Constructor.
   *
   * @param header           The csp control record header
   * @param controlCode      The control code
   * @param controlMessage   The control record text message
   *
   * @throws                IllegalArgumentException
   */
  public ELCControlRecordData(CSPControlRecordHeader header,
                              String controlMessage,
                              byte controlCode) {
    super(header, controlMessage);

    mControlCode = controlCode;
  }
 
  /**
   * Returns the ELC control record data length.
   *
   * @return the ELC control record data length
   */
  public int length() {
    return super.length() + 1;  // control code is 1 byte.
  }

  /**
   * Returns the control code.
   *
   * @return  The control code
   */
  public byte controlCode() {
    return mControlCode;
  }

  /**
   * Constructs an ELCControlRecordData object from a byte array.
   *
   * @param bytes  The byte array to construct the ELCControlRecordData 
   *
   * @return an ELCControlRecordData object, null if argument is null or
   *         an error occurred
   */
  public static ELCControlRecordData read(byte[] bytes) {
    if (bytes == null || bytes.length == 0) {
      return null;
    }

    ByteBuffer buffer = ByteBuffer.wrap(bytes);

    return read(buffer);
  }

  /**
   * Constructs an ELCControlRecordData object from a log record.
   *
   * @param record  The log record to construct the ELCControlRecordData
   *
   * @return an ELCControlRecordData object, null if argument is null or
   *         an error occurred
   */
  public static ELCControlRecordData read(LogRecord record) {
    if (record == null) {
      return null;
    }

    return read(record.getBytes());
  }

  /**
   * Reads an ELCControlRecordData object from a byte buffer.
   *
   * @param buffer  The byte buffer to read from
   *
   * @return an ELCControlRecordData object, null if argument is null or
   *         an error occurred
   */
  public static ELCControlRecordData read(ByteBuffer buffer) {
    ELCControlRecordData data = null;

    if (buffer == null) {
      return data;
    }

    try {
      CSPControlRecordHeader header = CSPControlRecordHeader.read(buffer);

      byte controlCode = buffer.get();

      int textMsgLen = (int)buffer.get() & 0xFF;

      byte[] msgBytes = new byte[textMsgLen];
      buffer.get(msgBytes);

      String msgString = LogDataConversionUtil.convertBytesToString(msgBytes);

      data = new ELCControlRecordData(header, msgString, controlCode);    
    }
    catch(BufferUnderflowException e) {
      log4jDebugLogger.error("Cannot read ELCControlRecordData from the"
                             + " ByteBuffer", e);
    }

    return data;
  }

  /**
   * Writes this object to a byte buffer.
   *
   * @return  The byte buffer containing this object
   */
  protected ByteBuffer writeToBuffer() {
    ByteBuffer buffer = ByteBuffer.allocate(length());

    buffer.put(header().getBytes());

    buffer.put(mControlCode);

    byte[] ctrlMsgBytes = controlMessage().getBytes();

    buffer.put((byte)(ctrlMsgBytes.length));

    buffer.put(ctrlMsgBytes);

    return buffer;
  }

  /**
   * Returns a string representation of this object.
   *
   * @return  The string representation of this object
   */
  public String toString() {
    StringBuffer buf = new StringBuffer();

    buf.append("ELC Control Record: ");

    buf.append("control code = ").append(mControlCode);

    String controlMessage = controlMessage();

    if (controlMessage.length() != 0) {
      buf.append(", ").append(controlMessage);
    } 

    return buf.toString();
  }
}
