/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */
package com.nortel.cdma.service.csl.common;

import com.nortel.cdma.service.notification.NotificationEventListenerInterface;
import com.nortel.cdma.service.notification.Event;
import com.nortel.cdma.service.notification.NotificationServiceInterface;
import com.nortel.cdma.service.notification.NotificationException;
import com.nortel.cdma.service.notification.NotificationService;
import com.nortel.cdma.gsf.ResourceUnavailableException;
import com.nortel.cdma.common.InvalidArgumentException;

import org.apache.log4j.Logger;

/**
 * This class describes a CSL event manager as how to  interact with Notification Service. That is,
 * subscribing the CSL related events, handling the incoming events and publishing the CSL events
 * if any.
 */

public abstract class CSLEventManager implements NotificationEventListenerInterface  {

  /**
   * A static field to hold the instance of this class.
   */
  protected static CSLEventManager moInstance = null;

  /**
   * NotificationServiceInterface reference.
   */
  protected NotificationServiceInterface  moNotificationServiceRef = null;

  /**
   * Instance of Log4j.Logger.
   */
  private final static Logger log4jDebugLogger = Logger.getLogger(CSLEventManager.class);

  /**
   * Creates an instance of this class.
   */
  public CSLEventManager() {
  }

  /**
   * Instantiate contained objects included. Start the background
   * threads to monitor the queues, call checkMissedOM on separate
   * thread, and check for the available upload summary file.
   * @throws ResourceUnavailableException if NotificationService if not available.
   */
  public void start() throws  ResourceUnavailableException {
    getNotificationServiceRef();
    subscribeEvents();
  }

  /**
   * Stops Event Manager and unsubscribes all events.
   */
  public void stop() {

    if (moNotificationServiceRef == null) {
      log4jDebugLogger.info("NotificationService is not reachable");
    }
    else {

      Exception moException = null;

      try {
        moNotificationServiceRef.unsubscribeAll(this);
      }
      catch (ResourceUnavailableException e) {
        moException = e;
      }
      catch (InvalidArgumentException e) {
        moException = e;
      }
      catch (NotificationException e) {
        moException = e;
      }
      if (moException != null) {
        log4jDebugLogger.error("Unable to unsubscribe CSL related events", moException);
      }
    }
  }

  /**
   * Receives incoming events from Notification service.
   * Implementation of NotificationEventListener interface.
   * @param moEvent the received notification
   */
  public abstract  void handleNotificationEvent(Event moEvent);

  /**
   * Help method to subscribe CSL related events.
   * @throws ResourceUnavailableException
   */
  protected abstract void subscribeEvents() throws ResourceUnavailableException;

  /**
   * Gets NotificationServiceInterface.
   * @return NotificationServiceInterface
   */
  private NotificationServiceInterface  getNotificationServiceRef () {

    while (moNotificationServiceRef == null) {
      moNotificationServiceRef = NotificationService.getInstance();
      try {
        Thread.sleep(1000);
      }
      catch (InterruptedException e) {
        // Nothing to do
      }
    }
    return moNotificationServiceRef;
  }
}

