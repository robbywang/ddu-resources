/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

package com.nortel.cdma.service.csl.common;

import com.nortel.cdma.common.data.filter.Filter;
import com.nortel.cdma.common.data.filter.FilterRecord;
import com.nortel.cdma.common.data.filter.FilterAttributesOperationNames;
import com.nortel.cdma.common.data.filter.FilterStatement;
import com.nortel.cdma.common.data.elements.QualifiedNames;
import com.nortel.cdma.common.data.elements.AttributeData;
import com.nortel.cdma.common.data.elements.AttributeGroup;
import com.nortel.cdma.common.data.elements.NonIndexedAttributeGroup;
import com.nortel.cdma.common.data.elements.FullyQualifiedTypeName;
import com.nortel.cdma.common.data.elements.FullyDistinguishedName;
import com.nortel.cdma.common.data.elements.ManagedElementResult;
import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.elements.AbstractManagedElementId;
import com.nortel.cdma.common.data.elements.ManagedElementId;
import com.nortel.cdma.common.data.elements.Attribute;
import com.nortel.cdma.common.data.elements.DataBoolean;
import com.nortel.cdma.common.data.autogen.typename.AttributeGroupTypeName;
import com.nortel.cdma.common.data.autogen.enumerated.CSLSettingEnum;
import com.nortel.cdma.common.data.autogen.enumerated.CardStateEnum;
import com.nortel.cdma.common.data.autogen.LocalName;
import com.nortel.cdma.common.data.autogen.FQTN;
import com.nortel.cdma.common.session.SessionId;
import com.nortel.cdma.common.data.errors.DataServiceInternalError;
import com.nortel.cdma.common.InvalidArgumentException;
import com.nortel.cdma.common.cms.CMServicePublishedInterface;
import com.nortel.cdma.common.internationalization.InternationalizedMessage;
import com.nortel.cdma.common.internationalization.InternationalizedMessageCategory;
import com.nortel.cdma.common.internationalization.CallSummaryLogMessageCategory;
import com.nortel.cdma.common.security.SecurityViolationException;

import com.nortel.cdma.service.dataservice.DatabaseUnavailable;
import com.nortel.cdma.service.dataservice.InvalidManagedElementId;
import com.nortel.cdma.service.dataservice.InvalidSchemaName;
import com.nortel.cdma.service.dataservice.InvalidSchemaType;
import com.nortel.cdma.service.dataservice.InvalidSearchFilter;
import com.nortel.cdma.service.dataservice.interfaces.ManagedElementDataAccessInterface;
import com.nortel.cdma.service.common.util.DBUtil;
import com.nortel.cdma.gsf.service.ServerServiceManager;
import com.nortel.cdma.gsf.service.ServiceSelectionCriteria;
import com.nortel.cdma.gsf.InvalidStateException;
import com.nortel.cdma.gsf.ResourceUnavailableException;
import com.nortel.cdma.gsf.logging.ServerJournalLogger;
import com.nortel.cdma.gsf.logging.JournalLogLevel;
import org.apache.log4j.Logger;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;
import java.util.Arrays;
import java.util.Set;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * A collection of utility methods for the streaming log handling.
 *
 * @since NBSS 15.0
 */
public class CSLUtil {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(CSLUtil.class);

  /**
   * Constant for attribute name: CSLSetting.
   */

  public static final String ATT_CSLSetting = "CSLSetting";

  /**
   * Attribute group name for the AG_OverloadFilter.
   */
  public static final String ATTGRP_OVERLOADFILTER = LocalName.ELM_CSLProfile.ATTGRP_OverloadFilter.TYPE_NAME;

  /**
   * Attribute group name for the ATTGRP_AttributeFilter.
   */
  public static final String ATTGRP_AttributeFilter = LocalName.ELM_CSLProfile.ATTGRP_AttributeFilter.TYPE_NAME;

  /**
   * Attribute group name for the ATTGRP_CSPIdentifierInfo.
   */
  public static final String ATTGRP_CSPIdentifierInfo = LocalName.ELM_CSLProfile.ATTGRP_CSPIdentifierInfo.TYPE_NAME;

  /**
   * Attribute name for ATT_CSPIdentifier.
   */
  public final static String CSP_IDENTIFIER = LocalName.ELM_CSLProfile.ATTGRP_CSPIdentifierInfo.ATT_CSPIdentifier;

  /**
   * Attribute name for the ATT_DataSessionUsage.
   */
  public static final String ATT_DataSessionUsage = "LogDataSessionUsageSummary";

  /**
   * Attribute name for the ATT_LogCallDropData.
   */
  public static final String ATT_LogCallDropData = "LogCallDropData";

  /**
   * Attribute name for the ATT_LogCallSummary.
   */
  public static final String ATT_LogCallSummary = "LogCallSummary";

  /**
   * Attribute name for the ATT_LogLinkFERData.
   */
  public static final String ATT_LogLinkFERData = "LogLinkFERData";

  /**
   * Attribute name for the ATT_LogRoundTripDelay.
   */
  public static final String ATT_LogRoundTripDelay =  "LogRoundTripDelay";

  /**
   * Attribute name for the ATT_LogSBSActiveSetChange.
   */
  public static final String ATT_LogSBSActiveSetChange = "LogActiveSetNeighborListUpdate";

  /**
   * Attribute name for the ATT_LogSBSNeighborListTuningArray.
   */
  public static final String ATT_LogSBSNeighborListTuningArray =  "LogNeighborListTuningArray";

  /**
   * Attribute name for the ATT_LogSBSSCHActiveSetChange.
   */
  public static final String ATT_LogSBSSCHActiveSetChange = "LogSCHActiveSetChange";


  /**
   * Attribute name for the AG_HwInfo_Grp: CardState.
   */
  public static final String CARD_STATE = "CardState";

  /**
   * Constant for eBSC ME.
   */
  public static final String EBSC_ME = LocalName.ELM_eBSC.TYPE_NAME;

  /**
   * Constant representing the number of chip bits.
   */
  private static int    CHIP_BITS = 16;

  /**
   * Constant representing the number of milliseconds per tick.
   */
  private static double MILLIS_PER_TICK = 1.25;

  /**
   * Constant time representing the difference betweeen 00:00 January 6, 1980
   * and 00:00 January 1, 1970.
   */
  private static long   CDMA_TIME_OFFSET = 315964800000L;

  /**
   * CPDS port hostname.
   */
  private static final String CPDS_HOST_NAME = "cpdshost";


  /**
   * The CSP IP address.
   */

  private static String mszCSPIP = "";

  /**
   * Gets ExternalServerConfig attribute group under CSLProfile ME.
   * @return the ExternalServerConfig object
   */
  public static ExternalServerConfig getExternalServerConfig () {

    AbstractManagedElementId oMEId = getCSLProfileMEId();

    if (oMEId == null) {
      log4jDebugLogger.error("Got null ME Id");
      return null;
    }

    ManagedElement me = getMEForAttributeGroup(oMEId,
      LocalName.ELM_CSLProfile.ATTGRP_ExternalServerConfig.TYPE_NAME);

    if (me == null) {
      return null;
    }

    return new ExternalServerConfig(me);
  }

  /**
   * Gets UploadProfileInfo attribute group under eBSC ME.
   * @return the AttributeGroup object
   */
  public static UploadProfileCSLInfo getUploadProfileInfoAttGrp () {

    ManagedElementDataAccessInterface meDac = getMeDAC();
    if (meDac == null) {
      log4jDebugLogger.error("Got null ManagedElementDataAccessInterface meDac");
      return null;
    }

    AbstractManagedElementId [] meIds =
      DBUtil.getMEIds(FullyQualifiedTypeName.MIBDomain.CEMS,
        FullyQualifiedTypeName.MIBType.ELM, LocalName.ELM_eBSC.TYPE_NAME);

    if ((meIds == null) || (meIds.length == 0)){
      log4jDebugLogger.error("Got empty AbstractManagedElementId array");
      return null;
    }

    //assume one eBSC ME
    AbstractManagedElementId oMEId = meIds[0];


    if (oMEId == null) {
      log4jDebugLogger.error("Got null ME Id");
      return null;
    }

    ManagedElement me = getMEForAttributeGroup(oMEId,
      LocalName.ELM_eBSC.ATTGRP_UploadProfileInfo_GRP.TYPE_NAME);

    if (me == null) {
      return null;
    }

    return new UploadProfileCSLInfo(me);
  }


  /**
   * Gets getAttributeFilterGroup under CSLProfile ME.
   * @param oMe  the ManagedElement object
   * @return the AttributeGroup object
   */
  public static AttributeGroup getAttributeFilterGrpFrom (ManagedElement oMe) {
    AttributeGroup moAttGrp = null;
    if (oMe == null) {
      log4jDebugLogger.error("null ManagedElement passed in");
    }
    else {
      moAttGrp = oMe.getAttributeGroup(ATTGRP_AttributeFilter);
    }
    return moAttGrp;
  }


  /**
   * Gets getAttributeFilterGroup under CSLProfile ME.
   * @param oMe  the ManagedElement object
   * @return the AttributeGroup object
   */
  public static AttributeGroup getOverloadFilterGrpFrom (ManagedElement oMe) {
    AttributeGroup moAttGrp = null;
    if (oMe == null) {
      log4jDebugLogger.error("null ManagedElement passed in");
    }
    else {
      moAttGrp = oMe.getAttributeGroup(ATTGRP_OVERLOADFILTER);
    }
    return moAttGrp;
  }

  /**
   * Gets attribute filter in term of boolean array representation.
   * false if the log attribute will be dropped. true otherwise.
   * @return a list of data log indices,  which will be filtered out
   */
  public static LinkedList<Integer> getCSLAttributeFilter () {
    return getAttributeFilter (ATTGRP_AttributeFilter);
  }

  /**
   * Helper method which returns attribute filter in term of boolean array representation.
   * @param szAttGrp the attribute group name
   *  @return a list of data log indices,  which will be filtered out
   */
  private static LinkedList<Integer> getAttributeFilter(String szAttGrp) {

    AbstractManagedElementId oMEId = getCSLProfileMEId();

    if (oMEId == null) {
      log4jDebugLogger.error("Got null ME Id");
      return null;
    }

    ManagedElement me = getMEForAttributeGroup(oMEId, szAttGrp);

    if (me == null) {
      return null;
    }

    return geDataLogFilter(me, szAttGrp);
  }

  /**
   * Returns the ManagedElement object which contains the required attribute group information for
   * the specified ManagedElementId.
   * @param oMEId the ManagedElement Id
   * @param szAttrGrp the attribute group name
   * @return the ManagedElement instance
   */
  private static ManagedElement getMEForAttributeGroup (AbstractManagedElementId oMEId,
                                                        String szAttrGrp) {

    ManagedElementDataAccessInterface meDac = getMeDAC();
    if (meDac == null) {
      log4jDebugLogger.error("Got null ManagedElementDataAccessInterface meDac");
      return null;
    }

    ManagedElement me = null;

    Exception e = null;

    try {

      me = meDac.getAttributeGroups(oMEId, new String [] {szAttrGrp});

    }
    catch (RemoteException re) {
      e = re;
    }
    catch (DatabaseUnavailable databaseUnavailable) {
      e = databaseUnavailable;
    }
    catch (DataServiceInternalError dataServiceInternalError) {
      e = dataServiceInternalError;
    }
    catch (InvalidSchemaName invalidSchemaName) {
      e = invalidSchemaName;
    }
    catch (InvalidManagedElementId ie) {
      e = ie;
    }

    if (e != null) {
      log4jDebugLogger.error( e.getMessage());
    }

    return me;
  }

  /**
   * Helper method which returns attribute filter in term of boolean array representation.
   * @param me the ManagedElement object which contains the attribute filter info
   * @param AttributeGrpName the attribute group name
   * @return a list of data log indices,  which will be filtered out
   */
  private static LinkedList<Integer> geDataLogFilter (ManagedElement me, String AttributeGrpName) {


    AttributeGroup aGroup = me.getAttributeGroup(AttributeGrpName);

    if (aGroup == null) {
      log4jDebugLogger.error("got null attribute group");
      return null;
    }

    Map<String, Attribute> moMap = aGroup.getAllAttributes();

    if (moMap == null) {
      log4jDebugLogger.error("got null Map object from attribute group");
      return null;
    }

    // List of all log types which are allowed.

    LinkedList<Integer> filteredLogList = new LinkedList<Integer>();

    //todo: define constants associated with log type names.
    filteredLogList.addAll(Arrays.asList(
      new Integer[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22}));

    /* The data log defined in xdrlite schema file.

    <value name="SLOG_LOG_CALL_SUMMARY" displayname="LogCallSummary">0x02</value>
    <value name="SLOG_LOG_CALL_DROP_DATA" displayname="LogCallDropData">0x03</value>
    <value name="SLOG_DATA_SESSION_USAGE" displayname="LogDataSessionUsageSummary">0x04</value>
    <value name="SLOG_LOG_NEIGHBOR_LIST_TUNING_ARRAY" displayname="LogNeighborListTuningArray">0x05</value>
    <value name="SLOG_LOG_ACTIVE_SET_NL_UPDATE" displayname="LogActiveSetNeighborListUpdate">0x06</value>
    <value name="SLOG_LOG_SCH_ACTIVE_SET_CHANGE" displayname="LogSCHActiveSetChange">0x07</value>
    <value name="SLOG_LOG_ROUND_TRIP_DELAY" displayname="LogRoundTripDelay">0x08</value>
    <value name="SLOG_LOG_LINK_FER_DATA" displayname="LogLinkFERData">0x09</value>
    </values>
    */

    //Each entry in the following table reprents a data log which can be set by user
    // as whether to be filtered or not.
    HashMap<String, Integer> oMapDataLogTypes = new HashMap<String, Integer> ();
    oMapDataLogTypes.put(ATT_LogCallSummary, new Integer (2));
    oMapDataLogTypes.put(ATT_LogCallDropData, new Integer (3));
    oMapDataLogTypes.put(ATT_DataSessionUsage, new Integer (4));
    oMapDataLogTypes.put(ATT_LogSBSNeighborListTuningArray, new Integer (5));
    oMapDataLogTypes.put(ATT_LogSBSActiveSetChange, new Integer (6));
    oMapDataLogTypes.put(ATT_LogSBSSCHActiveSetChange, new Integer (7));
    oMapDataLogTypes.put(ATT_LogRoundTripDelay, new Integer (8));
    oMapDataLogTypes.put(ATT_LogLinkFERData, new Integer (9));

    for ( Map.Entry<String, Attribute> oEntry : moMap.entrySet() )  {

      Attribute oAttribute =  oEntry.getValue();

      if (oAttribute != null) {
        String szLocalName = oAttribute.getLocalName();
        boolean bValue = ((DataBoolean)oAttribute.getValue()).getValue();

        if (bValue ==  false) {
          if (oMapDataLogTypes.containsKey(szLocalName)) {
            Integer iValue = oMapDataLogTypes.get(szLocalName);
            if (iValue != null) {
              filteredLogList.remove(iValue);
            }
          }
        }
      }
    }

    return filteredLogList;
  }

  /**
   * Gets a list of Card ME Ids which are CSL enabled.
   * @return array of the card ME IDs
   */
  public static AbstractManagedElementId [] getCSLUnlockedCards () {

    QualifiedNames oQualifiedNames = getCSLQualifiedNames(
      AttributeGroupTypeName.AG_CSLSetting_Grp,
      ATT_CSLSetting);

    //Get the searching filter
    Filter theFilter = getCSLSettingUnlockedFilter();

    FullyQualifiedTypeName [] meTypes = new FullyQualifiedTypeName [] {
      FQTN.ELM_DSInterface.TYPE_NAME,FQTN.ELM_PCUInterface.TYPE_NAME
    };

    return getMEIdFromDB(oQualifiedNames, theFilter, meTypes);
  }

  /**
   * Determines if CSL is enabled.
   * @return  true if it is enabled; false otherwise
   */
  public boolean isCSLEnabled () {
    boolean isEnabled = false;
    AbstractManagedElementId [] meIds = getCSLUnlockedCards();
    if ((meIds != null) && (meIds.length != 0)) {
      isEnabled = true;
    }
    return isEnabled;
  }

  /**
   * Gets a list of Card ME Ids which are CSL related and at least provisioned.
   * @return array of the card ME IDs
   */
  public static AbstractManagedElementId [] getProvisionedCSLCards () {

    //Query CardStateEnum value under AG_HwInfo_Grp
    QualifiedNames oQualifiedNames =
      new QualifiedNames(AttributeGroupTypeName.AG_HwInfo_Grp, false);
    oQualifiedNames.addQualified(CARD_STATE);

    Filter theFilter = null;

    try {
      // Creates the filter record to retrieve all the card
      // if its state is PROVISIONED or post PROVISIONED, i.e. ACTIVATED,
      // DEACTIVATED, INITIALIZING, ET_INITIALIZED;

      FilterRecord filterRecordCardState = new FilterRecord();

      filterRecordCardState.setExpression(
        oQualifiedNames,
        FilterAttributesOperationNames.GREATER_OR_EQUAL,
        CardStateEnum.ET_PROVISIONED);

      FilterStatement filterStatement = new FilterStatement();
      filterStatement.add(filterRecordCardState, null, null);
      theFilter = new Filter();
      theFilter.addStatement(filterStatement);
    }
    catch (InvalidArgumentException e) {
      log4jDebugLogger.error("Building Filter failed on card state",  e);
      return null;
    }

    FullyQualifiedTypeName [] meTypes = new FullyQualifiedTypeName [] {
      FQTN.ELM_DSFPDCard.TYPE_NAME,
      FQTN.ELM_PCUFPCard.TYPE_NAME,
      FQTN.ELM_DSFPVCard.TYPE_NAME
    };

    return getMEIdFromDB(oQualifiedNames, theFilter, meTypes);
  }



  /**
   * Gets a list of Card ME Ids which are CSL related.
   * @param oQFN the QualifiedNames object
   * @param oFilter  the Filter object
   * @param oMETypes the F0ullyQualifiedTypeName array
   *
   * @return array of the card ME IDs
   */
  private static AbstractManagedElementId [] getMEIdFromDB (QualifiedNames oQFN,
                                                            Filter oFilter,
                                                            FullyQualifiedTypeName [] oMETypes) {

    ManagedElementDataAccessInterface meDac = getMeDAC();
    if (meDac == null) {
      return null;
    }

    if (oFilter == null) {
      return null;
    }

    //Starting from eBSC ME, search if any card is CSL enable
    //todo: how can we know if SBS side is CSL enabled?
    AbstractManagedElementId [] rootMEIds =
      DBUtil.getMEIds(FullyQualifiedTypeName.MIBDomain.CEMS,
        FullyQualifiedTypeName.MIBType.ELM, EBSC_ME);
    if (rootMEIds == null) {
      return null;
    }


    ArrayList<AbstractManagedElementId> maMEs = new ArrayList<AbstractManagedElementId>();

    for (AbstractManagedElementId rootMEId: rootMEIds) {
      int meTypeCount = oMETypes.length;
      FullyQualifiedTypeName[]  oneMEType = new FullyQualifiedTypeName[1];

      for (int meTypeIndex = 0; meTypeIndex < meTypeCount; meTypeIndex++) {
        FullyQualifiedTypeName  typeName = oMETypes[meTypeIndex];

        oneMEType[0] = typeName;

        final int FETCH_COUNT = 500;

        ManagedElementResult  searchResult = null;
        Exception                         ex = null;

        try {
          searchResult = meDac.searchManagedElements (
            rootMEId,
            oneMEType,
            oFilter,
            new QualifiedNames [] {oQFN},
            false,
            false,
            FETCH_COUNT);

          int totalMatches = searchResult.getTotalMatches();
          if(totalMatches > 0) {
            ManagedElement[] meArray = searchResult.getResults();

            if (meArray == null) {
              log4jDebugLogger.error("Got null ManagedElement array as searching result");
              continue;
            }
            for (ManagedElement me: meArray) {
              if (me != null) {
                ManagedElementId meId = me.getId();

                //if the results are Interface ME ID, we need to return
                //its parent, i.e. card ME ID
                if (typeName.equals(FQTN.ELM_DSInterface.TYPE_NAME) ||
                  (typeName.equals(FQTN.ELM_PCUInterface.TYPE_NAME))) {
                  meId = me.getParentId();
                }

                FullyDistinguishedName cardFDN = meId.toFullyDistinguishedName();
                if (cardFDN == null) {
                  log4jDebugLogger.error("got null FDN for card ME ID " + meId);
                  continue;
                }
                if (log4jDebugLogger.isDebugEnabled()) {
                  log4jDebugLogger.debug("Found matched card: " + cardFDN);
                }
                maMEs.add(meId);
              }
            }
          }
          else {
            log4jDebugLogger.debug("No matched card returned");
            continue;
          }
        }
        catch (RemoteException e) {
          ex = e;
        }
        catch (DatabaseUnavailable databaseUnavailable) {
          ex = databaseUnavailable;
        }
        catch (DataServiceInternalError dataServiceInternalError) {
          ex = dataServiceInternalError;
        }
        catch (InvalidManagedElementId invalidManagedElementId) {
          ex = invalidManagedElementId;
        }
        catch (InvalidSchemaName invalidSchemaName) {
          ex = invalidSchemaName;
        }
        catch (InvalidSchemaType invalidSchemaType) {
          ex = invalidSchemaType;
        }
        catch (InvalidSearchFilter invalidSearchFilter) {
          ex =  invalidSearchFilter;
        }

        if (ex != null) {
          log4jDebugLogger.error("Unable to search related MEs",  ex);
        }
      }
    }
    return maMEs.toArray(new AbstractManagedElementId [] {});
  }

  /**
   * Gets a specific filter where  CSLSetting attribute is UNLOCKED.
   * @return  the filter attributer
   */
  public static Filter getCSLSettingUnlockedFilter () {

    Filter mCSLUnlockedFilter = getCSLFilter (AttributeGroupTypeName.AG_CSLSetting_Grp,
      ATT_CSLSetting, CSLSettingEnum.ET_UNLOCKED);
    return mCSLUnlockedFilter;
  }

  /**
   *  Gets a CSL filter with specified attribute group name, attribute name and value.
   * @param szAttGrpName the attribute group name
   * @param szAttName the attribute name
   * @param attValue  the attribute data
   * @return the Filter object
   */
  private static Filter getCSLFilter (String szAttGrpName,
                                      String szAttName,
                                      AttributeData attValue) {

    Filter theFilter = null;

    try {
      // Creates the filter record

      FilterRecord filterRecordCardState = new FilterRecord();
      QualifiedNames mQualifiedNames = getCSLQualifiedNames(szAttGrpName, szAttName);

      filterRecordCardState.setExpression(
        mQualifiedNames,
        FilterAttributesOperationNames.EXACT_MATCH,
        attValue);

      FilterStatement filterStatement = new FilterStatement();
      filterStatement.add(filterRecordCardState, null, null);
      theFilter = new Filter();
      theFilter.addStatement(filterStatement);
    }
    catch (InvalidArgumentException e) {
      log4jDebugLogger.error("Building Filter failed on " + szAttGrpName + ":" + szAttName,  e);
    }
    return theFilter;
  }

  /**
   * Help method to retrieve CSL QualifiedNames.
   * @param szAttGrpName the attribute group name
   * @param szAttName the attribute name
   * @return QualifiedNames
   */
  private static QualifiedNames getCSLQualifiedNames (String szAttGrpName,
                                                      String szAttName) {

    QualifiedNames mQualifiedNames =
      new QualifiedNames(szAttGrpName, false);

    if (mQualifiedNames != null) {
      mQualifiedNames.addQualified(szAttName);
    }
    return mQualifiedNames;
  }

  /**
   * Gets ManagedElementDataAccessInterface.
   * @return ManagedElementDataAccessInterface
   */
  public static ManagedElementDataAccessInterface getMeDAC () {
    ManagedElementDataAccessInterface dac = null;

    Exception                         ex = null;

    try {
      ServerServiceManager     serviceMgr = ServerServiceManager.getInstance();
      if (serviceMgr == null) {
        log4jDebugLogger.error("Unable to get the service manager");
        return null;
      }

      ServiceSelectionCriteria criterion =
        ServiceSelectionCriteria.TYPE_LOAD_BALANCE;

      Object                   serviceIfc =
        serviceMgr.getServiceInterface(ManagedElementDataAccessInterface.class,
          criterion,
          serviceMgr.getReservedSessionId());
      dac = (ManagedElementDataAccessInterface) serviceIfc;
    }
    catch (InvalidStateException e) {
      ex = e;
    }
    catch (InvalidArgumentException e) {
      ex = e;
    }
    catch (ResourceUnavailableException e) {
      ex = e;
    }
    catch (SecurityViolationException e) {
      ex = e;
    }

    if (ex != null) {
      log4jDebugLogger.error("Unable to get the ME DAC",  ex);
      return null;
    }

    if (dac == null) {
      log4jDebugLogger.error("Got null ManagedElementDataAccessInterface");
      return null;
    }
    return dac;
  }

  /**
   * Get card state from the target me, if the CardState attribute
   * doesn't exist or if any error/exception occurs, return null.
   * @param me The target ME.
   * @return CardStateEnum object the card state value.
   */

  public static CardStateEnum getCardState(ManagedElement me) {

    if (me == null) {
      log4jDebugLogger.error("got null ME.");
      return null;
    }

    FullyQualifiedTypeName cardFQTN = me.getTypeName();

    if(!(cardFQTN.equals(FQTN.ELM_DSFPDCard.TYPE_NAME) ||
      cardFQTN.equals(FQTN.ELM_DSFPVCard.TYPE_NAME) ||
      cardFQTN.equals(FQTN.ELM_PCUFPCard.TYPE_NAME))) {
      // only care about the card state for CSL related card
      return null;
    }

    QualifiedNames qualName = new QualifiedNames(AttributeGroupTypeName.AG_HwInfo_Grp, false);
    qualName.addQualified(CARD_STATE);
    Attribute attr = me.getAttribute(qualName);

    if (attr == null) {
      return null;
    }

    CardStateEnum cardState = (CardStateEnum) attr.getValue();
    if (cardState == null) {
      return null;
    }

    return cardState;
  }

  /**
   * Converts time from CDMA format to Unix format (seconds since
   * January 1st, 1970).
   *
   * @param cdmaTime  The time in CDMA format
   *
   * @return          The time in Unix format
   *
   * #see convertUnixToCDMATime
   */
  public static long convertCDMAToUnixTime(long cdmaTime) {
    cdmaTime >>= CHIP_BITS;
    cdmaTime *= MILLIS_PER_TICK;

    long  unixTime = cdmaTime + CDMA_TIME_OFFSET;

    return unixTime;
  }

  /**
   * Converts time from Unix format to CDMA format.
   *
   * @param unixTime  The time in Unix format
   *
   * @return          The time in CDMA format
   *
   * #see convertUnixToCDMATime
   */
  public static long convertUnixToCDMATime(long unixTime) {
    long  cdmaTime = unixTime - CDMA_TIME_OFFSET;
    cdmaTime /= MILLIS_PER_TICK;

    cdmaTime <<= CHIP_BITS;  // The coarse time occupies the first 48 bits

    return cdmaTime;
  }

  /**
   * Convert the current system time to CDMATime.
   * @return long value of timestamp
   */
  public static long getCurrentCDMATime() {
    Date date = new Date(System.currentTimeMillis());
    return convertUnixToCDMATime(date.getTime());
  }

  /**
   * Returns the CSP IP address.
   *
   * @return The CSP IP address
   */
  public static String getCspIP() {

    if (mszCSPIP.length() == 0) {
      try {
        mszCSPIP = InetAddress.getLocalHost().getHostAddress();
      }
      catch(UnknownHostException e) {
        log4jDebugLogger.error("Cannot get CSP IP address.", e);
      }
    }
    return mszCSPIP;
  }

  /**
   * This method queries the IP address of the CPDS port on the current C-EMS server.
   *
   * @return IP address of the CPDS port
   */
  public static String getCPDSHost() {

    InetAddress inet = null;
    String      ip   = null;

    //By default, the alias cpdshost must be configed in /etc/hosts
    try {
      inet = InetAddress.getByName(CPDS_HOST_NAME);
      ip = inet.getHostAddress();
    }
    catch (UnknownHostException e) {
      log4jDebugLogger.error("Unable to get cpdshost ", e);
    }

    return ip;
  }

  /**
   * Retrieve the CSPID from the database.
   *
   * @return the CSPID as a string
   */
  public static String getCSPID() {

    AbstractManagedElementId oMEId = getCSLProfileMEId();

    if (oMEId == null) {
      log4jDebugLogger.error("Unable to retrieve the CSL Profile ME Id");
      return null;
    }

    ManagedElement me = getMEForAttributeGroup(oMEId, ATTGRP_CSPIdentifierInfo);

    if (me == null) {
      log4jDebugLogger.error("Unable to retrieve the CSP Identifier Info Attribute Group ME");
      return null;
    }

    NonIndexedAttributeGroup aGroup = (NonIndexedAttributeGroup) me.getAttributeGroup(ATTGRP_CSPIdentifierInfo);

    if (aGroup == null) {
      log4jDebugLogger.error("Unable to retrieve the CSP Identifier Info Attribute Group");
      return null;
    }

    AttributeData oAttData = aGroup.getAttributeValue(CSP_IDENTIFIER);
    if (oAttData == null) {
      log4jDebugLogger.error("Unable to retrieve the CSPID Value from CSP Identifier Info Attribute Group");
      return null;
    }

    String szCSPID = oAttData.toString();
    return szCSPID;
  }

  /**
   * Creates a Journal log.
   * @param msgKey the internationalized message key
   * @param parms the parameters
   */
  public static void createJournalLog(Integer msgKey, String [] parms) {

    InternationalizedMessage msg = new InternationalizedMessage(
      InternationalizedMessageCategory.getCategoryKey(
        CallSummaryLogMessageCategory.class), msgKey, parms);

    SessionId  sessionId = ServerServiceManager.getInstance().getReservedSessionId();

    ServerJournalLogger.getInstance().log(JournalLogLevel.GENERAL,
      sessionId, msg);
  }



  /**
   * Returns the CSLProfile ME Id.
   * @return  the CSLProfile ME Id
   */
  private static AbstractManagedElementId  getCSLProfileMEId() {

    ManagedElementDataAccessInterface meDac = getMeDAC();

    if (meDac == null) {
      log4jDebugLogger.error("Got null ManagedElementDataAccessInterface meDac");
      return null;
    }

    AbstractManagedElementId [] oCSLProfileMEIds =
      DBUtil.getMEIds(FullyQualifiedTypeName.MIBDomain.CEMS,
        FullyQualifiedTypeName.MIBType.ELM, LocalName.ELM_CSLProfile.TYPE_NAME);

    if ((oCSLProfileMEIds == null) || (oCSLProfileMEIds.length == 0)){
      log4jDebugLogger.error("Got empty AbstractManagedElementId array");
      return null;
    }

    //assume one CSLProfile ME
    AbstractManagedElementId oMEId = oCSLProfileMEIds[0];

    return oMEId;
  }


  /**
   * Get Configuration management service interface reference.
   * @return the cms interface
   */
  public static CMServicePublishedInterface getCMServiceInterface() {

    ServerServiceManager serviceManager;
    CMServicePublishedInterface  cmServiceInterfaceRef = null;

    Exception e = null;
    try {
      serviceManager = ServerServiceManager.getInstance();
      cmServiceInterfaceRef = (CMServicePublishedInterface)
        (serviceManager.getServiceInterface
        (CMServicePublishedInterface.class,
          ServiceSelectionCriteria.TYPE_LOAD_BALANCE,
          serviceManager.getReservedSessionId()));
    }
    catch (InvalidArgumentException iae) {
      e = iae;
    }
    catch (InvalidStateException ise) {
      e = ise;
    }
    catch (ResourceUnavailableException rue) {
      e = rue;
    }
    catch (SecurityViolationException se) {
      e = se;
    }

    if (e != null) {
      log4jDebugLogger.error("Unable to get CMS interface reference", e);
    }
    return cmServiceInterfaceRef;
  }
}
