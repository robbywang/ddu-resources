/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls;

import com.nortel.cdma.service.csl.sls.common.SLSEventManager;
import com.nortel.cdma.service.csl.sls.common.CardIdFDNMapping;
import com.nortel.cdma.service.csl.common.UploadProfileCSLInfo;
import com.nortel.cdma.service.csl.sls.reader.Reader;
import com.nortel.cdma.service.csl.sls.reader.xdrlt.XDRLiteReader;
import com.nortel.cdma.service.csl.sls.writer.Writer;
import com.nortel.cdma.service.csl.sls.writer.GenericStreamWriter;
import com.nortel.cdma.gsf.service.Service;
import com.nortel.cdma.gsf.service.JRMPServiceInterface;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.ResourceUnavailableException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import com.nortel.cdma.gsf.ShutdownFailureException;
import com.nortel.cdma.gsf.util.ParameterInfo;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Date;
import com.nortel.cdma.service.common.rollinglogfilemanager.SectionRouter;
import com.nortel.cdma.service.common.util.DBUtil;
import com.nortel.cdma.service.csl.sls.xml.DigesterStreamingLogServer;
import com.nortel.cdma.service.csl.sls.xml.SchemaStreamingLogServer;
import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.common.internationalization.CallSummaryLogMessageCategory;
import com.nortel.cdma.common.data.elements.NonIndexedAttributeGroup;
import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.elements.DataIPAddressV4;
import com.nortel.cdma.common.data.autogen.typename.ManagedElementTypeName;

import java.io.File;
import java.util.Collection;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;

/**
 * This class describes a StreamingLogServer which details how the Streaming Log Server operates.
 */

public class StreamingLogServer extends Service implements JRMPServiceInterface {
  /**
   *  Tag for the SLS Configuration File.
   */
  private final String TAG_SLS_CONFIGURATION_FILE = "SLSXML";

  /**
   *  Tag for the SLS Configuration File.
   */
  private final String TAG_RLFM_CONFIGURATION_FILE = "RLFMXML";

  /**
   *  Singleton instance of this class.
   */
  private static StreamingLogServer moInstance = null;

  /**
   *  Default SLS XML configuration file.
   */
  private String mszSlsXml = "/opt/cems/cfg/csl/sls.xml";

  /**
   *  Default Rolling Log File Manager XML configuration file.
   */
  private String mszRlfmXml = "/opt/cems/cfg/csl/rlfm.xml";

  /**
   * Stores the properties passed in to SLS.
   */
  private Properties moProperties;

  /**
   * Flag to indicate if the service is started or not.
   */
  private  boolean isStarted = false;

  /**
   * Boolean to indicate if Call Summary Log Service is shutting down; if true,
   * requests will not be processed.  Flag will only be set to true during
   * service shutdown.
   */
  private  boolean isShuttingDown = false;

  /**
   *  SLSEventManager reference.
   */
  private SLSEventManager moEventManager = null;

  /**
   * CardIdFDNMapping reference.
   */
  private CardIdFDNMapping moCardIdFDNMapping  = null;

  /**
   * SectionRouter reference.
   */
  private SectionRouter moSectionRouter;

  /**
   * SchemaStreamingLogServer reference.
   */
  private SchemaStreamingLogServer moSchema;

  /**
   * Instance of Log4j.Logger.
   *
   */
  final private static Logger log4jDebugLogger = Logger.getLogger(StreamingLogServer.class);

  /**
   * Constructor - called by getInstance the first time
   * someone tries to get a reference to this class.
   * @throws RemoteException if failed to initialize
   */
  public StreamingLogServer() throws RemoteException {
    moEventManager = SLSEventManager.getInstance();
    moCardIdFDNMapping = CardIdFDNMapping.getInstance();
  }

  /**
   * Singleton getter for the lone StreamingLogServer instance.
   * @return a reference to the lone StreamingLogServer instance
   * @throws RemoteException if failed to initialize
   */
  public synchronized static StreamingLogServer getInstance()
    throws RemoteException {

    if (moInstance == null) {
      moInstance = new StreamingLogServer();
    }
    return moInstance;
  }

  /**
   * Configures the StreamingLogServer object.
   * @param oProperties the set of properties listed in the StreamingLogServer xml file
   */
  public void configure(Properties oProperties) {
    moProperties = oProperties;

    String szSlsXml =  oProperties.getProperty(TAG_SLS_CONFIGURATION_FILE);

    if ( szSlsXml != null ) {
      mszSlsXml = szSlsXml;
    }

    String szRlfmXml =  oProperties.getProperty(TAG_RLFM_CONFIGURATION_FILE);

    if ( szRlfmXml != null ) {
      mszRlfmXml = szRlfmXml;
    }
  }

  /**
   * Start the the StreamingLogServer.
   * @throws InitializationFailureException if failed to startup
   * @throws ResourceUnavailableException if failed to startup
   * @throws InvalidDeploymentException if failed to startup
   */
  public void startup() throws InitializationFailureException,
    ResourceUnavailableException,
    InvalidDeploymentException {

    if ( isStarted ) {
      log4jDebugLogger.debug("StreamingLogServer is already started," +
        "cancelling startup request.");
      return;
    }

    updateStreamLogServerIPAddressinDB();

    moSectionRouter = SectionRouter.getInstance();
    moSectionRouter.config(mszRlfmXml);

    File oFileSlsXmlFile = new File( mszSlsXml );
    DigesterStreamingLogServer oDigesterSLS = new DigesterStreamingLogServer( oFileSlsXmlFile );
    moSchema = oDigesterSLS.getSchema();
    Collection<Reader> oReaders = moSchema.getReaders();
    Collection<Writer> oWriters = moSchema.getWriters();

    //start event listener
    moEventManager.start();

    publishReaders(oReaders);
    publishWriters(oWriters);

     //Start to populate Card ID/FDN mapping info in local cache for all CSL related card
    moCardIdFDNMapping.start();

    isStarted = true;
    printStartMessage();
  }

  /**
   * Publishes intialized Reader to SLSEventManager.
   * @param oReaders the collection of initialized Reader instances
   */
  private void publishReaders(Collection<Reader> oReaders) {

    //Publishes XDRLiteReader to SLSEventManager.
    ArrayList<XDRLiteReader> aoXDRLReaders = new ArrayList<XDRLiteReader> ();

    for (Reader oReader: oReaders) {
      if (oReader instanceof XDRLiteReader) {
        XDRLiteReader oXDRLReader = (XDRLiteReader) oReader;
        aoXDRLReaders.add(oXDRLReader);
      }
    }

    if (oReaders.size() >0) {
      moEventManager.registerReaders(aoXDRLReaders);
    }
  }

  /**
   * Publishes intialized ArchiveServerWriter to SLSEventManager.
   * @param oWriters the collection of initialized Writer instance
   */
  private void publishWriters(Collection<Writer> oWriters) {

    //publish initialized Writer to CardIdFDNMapping class in order to
    //send CSP control records to registered agents.
    if (oWriters.size() > 0) {
      moCardIdFDNMapping.registerWriters(oWriters);
    }

    //Publishes ArchiveServerWriter to SLSEventManager.
    ArrayList<GenericStreamWriter> aoStreamWriter = new ArrayList<GenericStreamWriter> ();

    for (Writer oWriter: oWriters) {
      if (oWriter instanceof GenericStreamWriter) {
        GenericStreamWriter oStreamWriter = (GenericStreamWriter) oWriter;
        aoStreamWriter.add(oStreamWriter);
      }
    }

    if (aoStreamWriter.size() >0) {
      moEventManager.registerStreamWriter(aoStreamWriter);
    }
  }

  /**
   * Shutdown the the StreamingLogServer.
   * @throws com.nortel.cdma.gsf.ShutdownFailureException if failed to shutdown
   */
  public void shutdown() throws ShutdownFailureException {

    if (!isStarted) {
      log4jDebugLogger.debug("StreamingLogServer has already shutdown. ");
      return;
    }

    if (isShuttingDown) {
      log4jDebugLogger.debug("StreamingLogServer is in progress of shutting down." +
        "Reject another shutdown request.");
      return;
    }

    //stop child process
    moEventManager.stop();
    moCardIdFDNMapping.stop();
    //------------------------------------------------------
    // Set boolean to block changes as we are shutting down
    //-----------------------------------------------------
    isShuttingDown = true;
    isStarted = false;
    isShuttingDown = false;

    //shutdown the Reader and Writer instances
    if (moSchema != null) {
      Collection<Reader> oReaders = moSchema.getReaders();
      Collection<Writer> oWriters = moSchema.getWriters();
      
      for (Reader oReader: oReaders) {
        oReader.shutdown();
      }

      for (Writer oWriter: oWriters) {
        oWriter.shutdown();
      }
    }

    /*
     * Shutdown the SectionRouter to make sure that open Sections
     * get closed.
     */
    moSectionRouter.shutdown();

    //--------------------------------------------------------
    // Journal log the shutdown date and time
    //--------------------------------------------------------
    Date endDate = new Date(System.currentTimeMillis());

    CSLUtil.createJournalLog(CallSummaryLogMessageCategory.SLS_STOP,
      new String [] {endDate.toString()});

    if (log4jDebugLogger.isEnabledFor(Level.DEBUG)) { // #AUTO
      log4jDebugLogger.debug("StreamingLogServer Shutdown Completed at " + endDate);
    }
  }

  /**
   * Get the properties for the the Call Summary Log Service.
   * @return the service parameter array.
   */
  public ParameterInfo[] getRequiredProperties() {
    return ( new ParameterInfo[]{
      new ParameterInfo("cslName",
        "cslValue",
        "cslDesc")
    } );
  }

  /**
   * Help method to print out the service startup message.
   */
  private void printStartMessage() {

    //--------------------------------------------------------
    // Journal log the startup date and time
    // Need to define message code and the final args (Params)
    //--------------------------------------------------------
    Date startDate = new Date(System.currentTimeMillis());


    CSLUtil.createJournalLog(CallSummaryLogMessageCategory.SLS_START,
      new String [] {startDate.toString()});


    if (log4jDebugLogger.isEnabledFor(Level.DEBUG)) { // #AUTO
      log4jDebugLogger.debug("StreamingLogServer Startup Completed at " + startDate);
    }

    String szSlsXml = moProperties.getProperty(TAG_SLS_CONFIGURATION_FILE);
    log4jDebugLogger.info( "StreamingLogServer::slsxml = " + szSlsXml );

    String szRlfmXml = moProperties.getProperty(TAG_RLFM_CONFIGURATION_FILE);
    log4jDebugLogger.info( "StreamingLogServer::rlfmxml = " + szRlfmXml );
  }

  /**
   * Retrive CPDSHOST value from /etc/host and set this value in UploadProfile
   * attribute group under eBSC ME.
   */
  private void updateStreamLogServerIPAddressinDB() {

    String szCPDSHost = CSLUtil.getCPDSHost();

    if (szCPDSHost == null) {
      log4jDebugLogger.error("get null cpdshost");
      return;
    }

    ManagedElement[]  eBSCMEs =
      DBUtil.getAllMEsOfType(ManagedElementTypeName.ME_eBSC);

    if (eBSCMEs == null) {
      log4jDebugLogger.error("Unable to retrieve the EBSCs");
      return;
    }

    int eBSCCount = eBSCMEs.length;

    if (eBSCCount == 0) {
      log4jDebugLogger.info("No EBSCs could be found");

      return;
    }

    String  attrGrpName = UploadProfileCSLInfo.UPLOADPROFILE_INFO_GRP;

    String attrName = UploadProfileCSLInfo.SLS_HOSTNAME;

    NonIndexedAttributeGroup uploadProfileGrp =
      new NonIndexedAttributeGroup(attrGrpName);
    uploadProfileGrp.setAttribute(attrName, new DataIPAddressV4(szCPDSHost));

    for (int i = 0; i < eBSCCount; i++) {
      ManagedElement  eBSCME = eBSCMEs[i];

      eBSCME.removeAllAttributeGroups(); //only update UploadProfileInfo group

      eBSCME.setAttributeGroup(uploadProfileGrp);
    }

    if (! DBUtil.updateMEs(eBSCMEs)) {
      log4jDebugLogger.error("Unable to update UploadProfileInfo_Grp in the EBSCs");
      return;
    }
  }

}
