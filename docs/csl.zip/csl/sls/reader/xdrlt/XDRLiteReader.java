/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.reader.xdrlt;

import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.service.csl.common.CSPControlRecordHeader;
import com.nortel.cdma.service.csl.sls.common.SLSControlRecordData;
import com.nortel.cdma.service.csl.sls.reader.Reader;
import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;

/**
 * This class describes a XDRLiteReader which describes how to convert XDR Lite to XDR.
 */
public class XDRLiteReader extends Reader {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(XDRLiteReader.class);

  /**
   *
   * Identifies the attributes to be filtered from the log stream.
   */
  private LinkedList<Integer> mLogTypeFilters;

  /**
   * Number of bytes received in the last time period.
   */
  private long mNumBytesReceived = 0L;

  /**
   * Total number of bytes received since startup.
   */
  private long mTotalBytesReceived = 0L;

  /**
   * Number of bytes dropped due to attribute filtering.
   */
  private long mNumBytesFiltered = 0L;

  /**
   * Total number of bytes dropped due to attribute filtering since startup.
   */
  private long mTotalBytesFiltered = 0L;

  /**
   * Number of subsystem log records dropped due to attribute filtering.
   */
  private long mNumLogsFiltered = 0L;

  /**
   * Total umber of subsystem log records dropped due to attribute filtering since startup.
   */
  private long mTotalLogsFiltered = 0L;

  /**
   * Indicates whether any attribute filters have been specified.
   */
  private boolean mbIsFilteringEnabled = false;

  /**
   * Timer to periodically generate statistics logs.
   */
  private Timer mShowStatsTimer;

  /**
   * The number of log types defined in the schema.
   */
  private static final int NUM_LOG_TYPES_DEFINED = 23;

  /**
   * Constant represents the CSP control record source Id.
   * 1=ELC, 2=SLS
   */
  private final static byte SOURCE_ID_SLS = 0x2;

  /**
   * Constant represents the SLS control record log type.
   */
  private final static byte LOG_TYPE_SLS = 0x16;



  /**
   * The default constructor for the XDRLiteReader object.
   */
  public XDRLiteReader() {
    super();
    mLogTypeFilters = new LinkedList<Integer>();
  }

  /**
   * Required by all PlugIn's.
   */
  protected void localStartup() throws InitializationFailureException,
    InvalidDeploymentException {

    Thread oThread = new Thread("Update Attribute Filter ") {
      public void run() {
        updateCSLAttributeFilter();
      }
    };
    oThread.start();

    // Starts the timer to output a stats log every 30 minutes,
    // on the hour and half hour.
    mShowStatsTimer = new Timer();

    long  period = 30*60*1000L;  // 30 minutes in milliseconds

    long  currentTime = System.currentTimeMillis();

    long  delay = period - currentTime%period;  // milliseconds till next half hour

    mShowStatsTimer.scheduleAtFixedRate(new TimerTask() {
      public void run() {
        sendControlRecord();
      }
    }, delay, period);
  }

  /**
   * Shuts down the reader.
   */
  public synchronized void shutdown() {

    mShowStatsTimer.cancel();
    super.shutdown();
  }

  /**
   * The IStreamReceiver interface implementation that handles the stream.
   * @param abInputBuffer the byte array to be handled
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the byte array to be handled
   */
  public synchronized void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {

    if ( iLength < 1 ) {
      return;
    }
    mNumBytesReceived += iLength;


    if ( !mbIsFilteringEnabled ) {

      for ( IStreamReceiver oStreamReceiver : moHashSetStreamReceivers ) {
        oStreamReceiver.handleStream(abInputBuffer, iOffset, iLength);
      }
    }
    else {
      // Filter records
      try {

        ByteBuffer moDataBuffer = ByteBuffer.wrap(abInputBuffer, iOffset, iLength);

        moDataBuffer.mark();  // Mark the starting position.

        int iNextRecordPosition = 0;
        int iBytesToBeSent = 0;

        boolean bDone = false;

        while ( !bDone ) {

          if (moDataBuffer.remaining() < 4) {
            bDone = true;
          }
          else {
            // Determine the size of the record.
            int iCurrentRecordPosition = moDataBuffer.position();
            int iRecordSize = moDataBuffer.getShort()  & 0xFFFF;

            if (iRecordSize < 18) {
              log4jDebugLogger.error("Data corruption, log size=" + iRecordSize);
              continue;
            }
            iNextRecordPosition = iCurrentRecordPosition + iRecordSize;

            if ( iNextRecordPosition <= moDataBuffer.limit() ) {
              // Determine whether to filter this record.

              // buffer[0-1] -> record size
              // buffer[2] -> node type
              // buffer[3] -> message class
              // buffer[4] -> log type

              moDataBuffer.position(moDataBuffer.position() + 2);
              int iLogType = moDataBuffer.get()  & 0xFF;
              boolean bAllowLogType = isLogTypeAllowed(iLogType);

              if ( !bAllowLogType ) {

                synchronized(this) {
                  mNumLogsFiltered++;
                  mNumBytesFiltered += iRecordSize;
                }

                // Send the allowed logs that preceeded the filtered log.
                sendData(moDataBuffer, iBytesToBeSent);

                moDataBuffer.position(iNextRecordPosition);
                moDataBuffer.mark();  // Mark the starting position.
                iBytesToBeSent = 0;
              }
              else {
                moDataBuffer.position(iNextRecordPosition);
                iBytesToBeSent += iRecordSize;
              }
            }
            else {
              log4jDebugLogger.error("Incomplete record at end of buffer."
                                     + " pos="+ moDataBuffer.position()
                                     + " n=" + iNextRecordPosition
                                     + " lim=" + moDataBuffer.limit() );
              bDone = true;
            }
          }
        }
        sendData(moDataBuffer, iBytesToBeSent);
      }
      catch (Exception e) {
        log4jDebugLogger.error(e);
      }
    }
  }

  /**
   * Send the specified number of bytes from the byte buffer
   * starting at the mark.
   *
   * @param oBuffer the buffer containing the data to be sent
   * @param iLength the number of bytes to be sent
   */
  private void sendData (ByteBuffer oBuffer, int iLength) {

    if (iLength > 0) {

      oBuffer.reset();  // Move position back to the mark.

      int iOffset = oBuffer.arrayOffset() + oBuffer.position();

      byte[] backingArray = oBuffer.array();

      for ( IStreamReceiver oStreamReceiver : moHashSetStreamReceivers ) {
        oStreamReceiver.handleStream(backingArray, iOffset, iLength);
      }
    }
  }

  /**
   * Checks if a log type should be allowed.
   *
   * @param iLogType  The log type to check
   *
   * @return true if the log type is allowed; false if it should be
   * filtered out
   */
  private boolean isLogTypeAllowed(int iLogType){

    // The attribute filter lists all the allowed logs.
    int index = Collections.binarySearch(mLogTypeFilters, iLogType);

    if (index < 0) {
      return false;
    }

    return true;
  }

  /**
   *  Update the attribute filter list.
   */
  public synchronized void updateCSLAttributeFilter() {

    mLogTypeFilters = CSLUtil.getCSLAttributeFilter();

    // The attribute filter lists all the allowed logs. If there are fewer
    // than the defined number of log types in the list, filtering is enabled.

    if ((mLogTypeFilters != null) && (mLogTypeFilters.size() < NUM_LOG_TYPES_DEFINED)) {

      if ( !mbIsFilteringEnabled ) {
        mbIsFilteringEnabled = true;
        log4jDebugLogger.debug("Streaming log filtering enabled");
      }
    }
    else {
      if ( mbIsFilteringEnabled ) {
        mbIsFilteringEnabled = false;
        log4jDebugLogger.debug("Streaming log filtering disabled");
      }
    }
  }

  /**
   * Sends a CSP control record on statistics of the received/dropped logs.
   */
  private void sendControlRecord() {

    synchronized(this) {
      mTotalBytesReceived += mNumBytesReceived;
      mTotalBytesFiltered += mNumBytesFiltered;
      mTotalLogsFiltered += mNumLogsFiltered;

      if (log4jDebugLogger.isEnabledFor(Level.WARN)) {
        log4jDebugLogger.warn("SLS Statistics:"
                              + "\n logs filtered=" + mNumLogsFiltered + ", total=" + mTotalLogsFiltered
                              + "\n bytes filtered=" + mNumBytesFiltered + ", total=" + mTotalBytesFiltered
                              + ", bytes received=" + mNumBytesReceived + ", total=" + mTotalBytesReceived );
      }
      mNumBytesReceived = 0;
      mNumBytesFiltered = 0;
      mNumLogsFiltered = 0;
    }

    CSPControlRecordHeader header = null;

    Date date = new Date();

    try {
      header = CSPControlRecordHeader.getNextHeader(SOURCE_ID_SLS, LOG_TYPE_SLS);
    }
    catch(IllegalArgumentException e){
      log4jDebugLogger.error("Failed to construct CSPControlRecordHeader."
        + "CSP control record not sent at " + date , e);
      return;
    }

    SLSControlRecordData recordData = new SLSControlRecordData(header,
      "SLS Statistics", mTotalLogsFiltered);

    byte [] oabRecord = recordData.getBytes();

    int recordLength = oabRecord.length;

    handleStream(oabRecord, 0, recordLength);
  }
}
