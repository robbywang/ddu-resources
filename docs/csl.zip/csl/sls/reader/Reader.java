/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.reader;

import com.nortel.cdma.service.common.server.SocketServer;
import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;
import com.nortel.cdma.service.csl.sls.common.PlugIn;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import org.apache.log4j.Logger;

import java.util.HashSet;
import java.util.Properties;

/**
 * This class describes a generic CSL Reader functionality.
 */
public abstract class Reader extends PlugIn {
  /**
   * The default port for this reader.
   */
  protected int miPort = 5258;

  /**
   * The default input buffer size for reader.
   */
  protected int miInputBufferSize = 4*1024*1024;

  /**
   * Instance of Log4j Logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(Reader.class);
 
  /**
   * The name of the property that specifies the input buffer size.
   */
  private static final String INPUT_BUFFER_SIZE = "inputbuffersize";

  /**
   * The ServerSocket used to receive connections on.
   */
  protected SocketServer moSocketServer;

  /**
   * Default constructor for the Reader object.
   */
  public Reader() {
    super();

    mszPluginType = "Reader";
  }

  /**
   * Gets the remote port to connect to.
   * @return the remote port to connect to
   * @see #setPort
   */
  public int getPort() {
    return miPort;
  }

  /**
   *  Sets the remote port to connect to.
   * @param iPort the remote port to connect to
   * @see #getPort
   */
  public void setPort(int iPort) {
    miPort = iPort;
  }

  /**
   * Configures a PlugIn.
   * @param oProperties the set of Properties created by an XML file
   */
  public void config(Properties oProperties) {
    super.config(oProperties);

    if ( oProperties == null ) {
      return;
    }

    String szInputBufferSize = (String) oProperties.get( INPUT_BUFFER_SIZE );

    if ( szInputBufferSize == null ) {
      log4jDebugLogger.error( "Input Buffer Size is null using default.");
    }
    else {
      setInputBufferSize( szInputBufferSize );
    }
  }

  /**
   * Starts up the PlugIn.
   */
  public void startup() throws InitializationFailureException,
    InvalidDeploymentException {
    if ( ! mbStarted ) {
      printStartMessage();

      moHashSetStreamReceivers = new HashSet<IStreamReceiver>();

      moSocketServer = new SocketServer(miPort, this, false);
      moSocketServer.setInputBufferSize(miInputBufferSize);
      moSocketServer.start();

      localStartup();

      mbStarted = true;
    }
  }

  /**
   * Gets the input buffer size.
   * @return an integer containing the input buffer size 
   * @see #setInputBufferSize
   */
  public int getInputBufferSize() {
    return miInputBufferSize;
  }

  /**
   * Sets the input buffer size. 
   * @param iInputBufferSize an integer containing the input buffer size 
   * @see #getInputBufferSize
   */
  public void setInputBufferSize(int iInputBufferSize) {
    miInputBufferSize = iInputBufferSize;
  }

  /**
   * Sets the input buffer size. 
   * @param szInputBufferSize a String representing the input buffer size
   * @see #getInputBufferSize
   */
  public void setInputBufferSize(String szInputBufferSize) {
    try {
      miInputBufferSize = Integer.parseInt(szInputBufferSize);
    }
    catch ( NumberFormatException e){
      log4jDebugLogger.error( "Input Buffer Size is null using default.");
      miInputBufferSize = 4194304; 
    } 
  }


  /**
   * The IStreamReceiver interface implementation that handles the stream.
   * @param abInputBuffer the byte array to be handled
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the byte array to be handled
   */
  public abstract void handleStream(byte[] abInputBuffer, int iOffset, int iLength);
}
