/**
 * Copyright (c) 2007 Nortel Networks, Inc. All Rights Reserved
 */

package com.nortel.cdma.service.csl.sls.common;

import com.nortel.cdma.common.data.autogen.enumerated.CardStateEnum;
import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.event.ManagedElementAttributeChangeEvent;
import com.nortel.cdma.service.notification.Event;
import com.nortel.cdma.service.notification.EventFilter;

import com.nortel.cdma.service.csl.common.CSLUtil;

/**
 * Filter class used to get ManagedElementAttributeChangeEvent which indicates
 * that the CSL related card is initialized.
 */
public class CardInitializedEventFilter extends EventFilter {


  /**
   * Constructor for MEAttributeChangeEventFilter.
   */
  public CardInitializedEventFilter() {
  }

  /**
   * Return the target ManagedElementAttributeChangeEvent class.
   * @return the event class
   */
  public Class getEventClass() {
    return ManagedElementAttributeChangeEvent.class;
  }

  /**
   * Catches all the events from the event class specified by this filter.
   * Here we can add some extra filtering rules to our filter.
   * @param notifEvent the event in the NS queue
   * @return boolean
   */
  public boolean eventMatches(Event notifEvent) {

    boolean isMatched = false;

    if (notifEvent != null) {

      if (notifEvent instanceof ManagedElementAttributeChangeEvent) {

        ManagedElementAttributeChangeEvent event = (ManagedElementAttributeChangeEvent) notifEvent;
        ManagedElement me = event.getManagedElement();

        CardStateEnum cardState = CSLUtil.getCardState(me);

        if ((cardState != null) && (cardState.equals(CardStateEnum.ET_INITIALIZED))) {
          isMatched = true;
        }
      }
    }

    return isMatched;
  }

  /**
   * Returns the name of the filter.
   * @return name (string) the name.
   */
  public String getName() {
    return this.getClass().getName();
  }
}
