/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.common;

import com.nortel.cdma.comm.modata.MOObjectId;
import com.nortel.cdma.comm.modata.MOFDN;
import com.nortel.cdma.comm.modata.MOClassType;
import com.nortel.cdma.comm.ubclient.OIDBrokerClient;
import com.nortel.cdma.comm.ubclient.FDNBrokerClient;
import com.nortel.cdma.comm.ubclient.UBInternalException;
import com.nortel.cdma.comm.ubclient.UBRequestFailureException;
import com.nortel.cdma.comm.ubclient.UBClientService;
import com.nortel.cdma.comm.ubclient.UBClientServiceProperties;
import com.nortel.cdma.common.data.elements.FullyDistinguishedName;
import com.nortel.cdma.common.data.elements.AbstractManagedElementId;
import com.nortel.cdma.common.InvalidArgumentException;
import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.service.csl.common.CSPControlRecordHeader;
import com.nortel.cdma.service.csl.sls.writer.Writer;
import com.nortel.cdma.gsf.InitializationFailureException;

import java.util.Properties;
import java.util.TreeMap;
import java.util.ArrayList;
import java.util.Date;
import java.util.Collection;
import java.nio.ByteBuffer;

import org.apache.log4j.Logger;


/**
 * This class provides utility methods to map Object Ids or ME Ids to FDNs
 * for all CSL related cards.
 */
public class CardIdFDNMapping {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(CardIdFDNMapping.class);

  /**
   * OIDBrokerClient instance.
   */
  private OIDBrokerClient moOIDBrokerClient;

  /**
   * FDNBrokerClient instance.
   */
  private FDNBrokerClient moFDNBrokerClient;

  /**
   * TreeMap contains all CSL related OID to FDN mappings.
   */
  private volatile TreeMap<String, Object> moCardIDToFDNMappings;

  /**
   *  ESELECTOR  MO Id.
   */
  private final static int MO_TYPE_ESELECTOR_CARD = 0x00AF;

  /**
   *  SCIS MO Id.
   */
  private final static int MO_TYPE_SCIS = 0x1400;

  /**
   * A static field to hold the instance of this class.
   */
  private static CardIdFDNMapping moInstance = null;

  /**
   * A boolean to indicate start has been called.
   */
  private boolean hasStarted = false;

  /**
   * Constant represents the CSP control record source Id.
   * 1=ELC, 2=SLS
   */
  private final static byte SOURCE_ID_SLS = 0x2;

  /**
   * Constant represents the CSP control record log type
   * for Card ID & FDN Mapping.
   */
  private final static byte LOG_TYPE_MAPPING = 0x17;

  /**
   * List of initialized Writer instances.
   */
  private Collection <Writer> mWriters;

  /**
   * Get the singleton instance of the CardIdFDNMapping.
   * @return MappingUtil object instance
   */
  public synchronized  static CardIdFDNMapping getInstance() {
    if (moInstance == null) {
      moInstance = new CardIdFDNMapping();
    }

    return moInstance;
  }

  /**
   * Constructor.
   */
  private CardIdFDNMapping() {
    moCardIDToFDNMappings = new TreeMap<String, Object> ();
  }


  /**
   * Instantiate contained objects included. Polls all mapping info
   * from CEMS DB and saves locally.
   */
  public void start()  {
    if (hasStarted == true) {
      return;
    }

    hasStarted = true;
    try {
      reFreshUBClient();
    }
    catch (InitializationFailureException e) {
      log4jDebugLogger.error("UBClientService has not yet been initialized", e);
     }
    sendControlRecord("Sending Mapping Information during startup");
  }

  /**
   * Cleanup the local cache during stop.
   */
  public void stop() {
    if (hasStarted) {
      moCardIDToFDNMappings.clear();
    }

  }

  /**
   * Register initialized Writer instances for sending mapping control records.
   * @param oWriters  the initialized Writer instances
   */
  public void registerWriters(Collection<Writer> oWriters) {
    if (oWriters == null) {
      log4jDebugLogger.error("Unable to register Writer agent: got null Writer instance");
      return;
    }
    mWriters = oWriters;
  }

  /**
   *  Populates the Card Ids to FDN mapping info to the local cache.
   */
  private synchronized void populateMappingCache () {
    populateBSSMMappingInfo ();
    populateCEMSMMappingInfo();
  }

  /**
   * Datafills the BSSM mapping info (MO ID & FDN) in local cache.
   */
  private void populateBSSMMappingInfo () {

    MOObjectId[] aoOId = getMOObjectIds();

    if (aoOId == null) {
      log4jDebugLogger.error("Got null MOObjectId array");
      return;
    }

    MOFDN oFdn = null;
    for ( MOObjectId oMOObjectId : aoOId ) {

      if (oMOObjectId == null) {
        log4jDebugLogger.error("Got null MOObjectId");
        continue;
      }

      Exception oException = null;

      try {
        moFDNBrokerClient = UBClientService.getFDNBrokerClient();

        if (moFDNBrokerClient == null) {
          log4jDebugLogger.error("Got null FDNBrokerClient");
          return;
        }

        oFdn = moFDNBrokerClient.oidToFDN(oMOObjectId);
      }
      catch (UBInternalException e) {
        oException = e;
      }
      catch (UBRequestFailureException e) {
        oException = e;
      }
      catch ( InitializationFailureException e ) {
        oException = e;
      }

      if (oException != null) {
        log4jDebugLogger.error("Cannot retrieve OID list for type: " + oMOObjectId);
        continue;
      }

      if (oFdn != null) {
        String szFdn = oFdn.getFdn();
        addMapping(oMOObjectId, szFdn);
      }
    }
  }

  /**
   * Retrieve all the MO Ids info for the CSL related card types.
   * @return  MOObjectIds
   */
  private MOObjectId[] getMOObjectIds() {

    Integer [] aiMOIDs = new Integer [] {
      MO_TYPE_ESELECTOR_CARD,
      MO_TYPE_SCIS
    };

    ArrayList<MOObjectId> oalOIDs = new ArrayList<MOObjectId>();

    try {
      moOIDBrokerClient = UBClientService.getOIDBrokerClient();

      if (moOIDBrokerClient == null) {
        log4jDebugLogger.error("got null OIDBrokerClient");
        return null;
      }

      for (int iMOId: aiMOIDs) {
        MOClassType oMOClassType = new MOClassType(iMOId);

        MOObjectId[] aoMOObjectIdsForCard = null;

        Exception oException = null;
        try {
          aoMOObjectIdsForCard = moOIDBrokerClient.classTypeToOIDList( oMOClassType );
        }
        catch (UBInternalException e) {
          oException = e;
        }
        catch (UBRequestFailureException e) {
          oException = e;
        }

        if (oException != null) {
          log4jDebugLogger.error("Cannot retrieve OID list for type: " + iMOId);
          continue;
        }

        if (aoMOObjectIdsForCard == null) {
          log4jDebugLogger.error("Got null MOObjectIdsForCard for type: " + iMOId);
          continue;
        }

        for (MOObjectId mOId:aoMOObjectIdsForCard) {
          oalOIDs.add(mOId);
        }
      }
    }
    catch (InitializationFailureException e) {
      log4jDebugLogger.error("UBClientService has not yet been initialized", e);
    }

    return oalOIDs.toArray(new MOObjectId[0]);
  }


  /**
   * Datafills the CEMS mapping info (ME ID and FND) in local cache.
   */
  private void populateCEMSMMappingInfo () {

    AbstractManagedElementId [] meIds = CSLUtil.getProvisionedCSLCards();
    if (meIds == null) {
      log4jDebugLogger.debug("Got null ME ID array");
      return;
    }

    for (AbstractManagedElementId cardId: meIds) {
      if (cardId == null ) {
        log4jDebugLogger.error("Got null card ME ID ");
        continue;
      }

      FullyDistinguishedName oFdn = cardId.toFullyDistinguishedName();

      if (oFdn == null) {
        log4jDebugLogger.error("Unable to get FDN based on string: " +oFdn);
        return;
      }
      addMapping(cardId, oFdn.toString());
    }
  }


  /**
   * Add a pair of card MOId/ME Id and FDN to the local cache.
   * @param obj the card instance
   * @param szFdn the card FDN
   */
  public void addMapping(Object obj, String szFdn) {
    if (obj == null) {
      log4jDebugLogger.debug("got null object");
      return;
    }

    if (szFdn == null) {
      log4jDebugLogger.debug("got null FDN string");
      return;
    }

    synchronized (moCardIDToFDNMappings) {
      moCardIDToFDNMappings.put(szFdn, obj);
      log4jDebugLogger.debug("Add  " + szFdn + "mapping info to cache");
    }
  }

  /**
   * From an entry from the cache if the card is not available.
   * @param szFdn the card instance to be removed
   */
  public void removeMappingFrom(String szFdn) {

    if (szFdn == null) {
      log4jDebugLogger.debug("got null FDN string");
      return;
    }

    synchronized (moCardIDToFDNMappings) {
      moCardIDToFDNMappings.remove(szFdn);
      log4jDebugLogger.debug("remove " + szFdn + " from cache");
    }
  }

  /**
   * Get MO Id to ME FDN mapping.
   * @return TreeMap instance
   */

  public TreeMap<String, Object> getMapping () {
    TreeMap<String, Object> cloneCache = (TreeMap<String, Object>) moCardIDToFDNMappings.clone();
    return cloneCache;
  }

  /**
   * Creates and sends a CSP control record on card ID/FDN mapping.
   * @param szAdditionalText the additional text message
   */
  public synchronized void sendControlRecord(final String szAdditionalText) {

    Thread oThread = new Thread("populateMappingCache Thread ") {
      public void run() {
        //poll all update-to-data mapping info into cache
        populateMappingCache();

        String szTriggeredBy = "";
        TreeMap<String, Object> cloneCache = getMapping();
        if (cloneCache.isEmpty()) {
          log4jDebugLogger.info("No mapping entry is found. Cancel sending control record");
          return;
        }

        if (szAdditionalText == null) {
          log4jDebugLogger.info("No trigger is specified");
        }
        else {
          szTriggeredBy = szAdditionalText;
        }

        //start to build CSP control record for mapping
        CSPControlRecordHeader header = null;

        Date date = new Date();

        try {
          header = CSPControlRecordHeader.getNextHeader(SOURCE_ID_SLS, LOG_TYPE_MAPPING);
        }
        catch(IllegalArgumentException e){
          log4jDebugLogger.error("Failed to construct CSPControlRecordHeader."
            + "CSP control record not send at " + date , e);
          return;
        }

        MappingInfoControlRecordData recordData = new MappingInfoControlRecordData(
          header,  cloneCache, szTriggeredBy);

        byte [] oPayload = recordData.getBytes();

        int recordLength = oPayload.length + 2;

        ByteBuffer oRecord =  ByteBuffer.allocate(recordLength); //payload + length field

        oRecord.putShort((short) recordLength);
        oRecord.put(oPayload);

        byte [] oabRecords = oRecord.array();

        //start to send byte stream to all registered Writer instance
        if ((mWriters == null) || (mWriters.size() == 0)){
          log4jDebugLogger.info("No initialized Writer instance is registered. Stop sending mapping control record");
          return;
        }

        for (Writer oWriter: mWriters) {
          oWriter.handleStream(oabRecords, 0, oabRecords.length);
        }
      }
    };

    oThread.start();
  }

  /**
   * Refresh UB server reference.
   * @throws com.nortel.cdma.gsf.InitializationFailureException
   */
  private static void reFreshUBClient() throws InitializationFailureException {

    try {
      // Recreate UB reference to BSSM to make sure it is fine
      // Reference may become stale if the BSSM were restarted after CEMS/MDM MS were started.
      // The solution below is robust but not higly efficient. It is chosen since this method will
      // be called occasionally for CNFP card activation.

      //clear the reference
      UBClientService.getInstance().shutdown();

      //create the ub properties
      //todo :   Should we include the two properties in our properties file
      // and then pass our properties?
      UBClientServiceProperties ubProperties =
        new UBClientServiceProperties(new Properties());

      //startup UB (recreate UB reference to BSSM)
      UBClientService.getInstance().startup(ubProperties);
    }
    catch (InvalidArgumentException e) {
      throw new InitializationFailureException("UBClient",
        "Invalid argument passed to UBClientService", e);
    }
  }
}
