/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */
package com.nortel.cdma.service.csl.sls.common;

import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.service.csl.common.CSLEventManager;
import com.nortel.cdma.service.csl.common.CSLAttributeChangeEventFilter;
import com.nortel.cdma.service.csl.common.ExternalServerConfig;
import com.nortel.cdma.service.csl.sls.reader.xdrlt.XDRLiteReader;
import com.nortel.cdma.service.csl.sls.writer.GenericStreamWriter;
import com.nortel.cdma.service.notification.Event;
import com.nortel.cdma.service.notification.NotificationException;
import com.nortel.cdma.service.notification.EventFilter;
import com.nortel.cdma.service.dataservice.interfaces.ManagedElementDataAccessInterface;
import com.nortel.cdma.service.dataservice.DatabaseUnavailable;
import com.nortel.cdma.service.dataservice.InvalidManagedElementId;

import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.elements.AttributeGroup;
import com.nortel.cdma.common.data.elements.AbstractManagedElementId;
import com.nortel.cdma.common.data.elements.Parameter;
import com.nortel.cdma.common.data.elements.ParameterGroup;
import com.nortel.cdma.common.data.elements.FullyQualifiedTypeName;
import com.nortel.cdma.common.data.elements.ManagedElementId;
import com.nortel.cdma.common.data.event.ManagedElementAttributeChangeEvent;
import com.nortel.cdma.common.data.event.ManagedElementCreateEvent;
import com.nortel.cdma.common.data.event.ManagedElementRecursiveDeleteEvent;
import com.nortel.cdma.common.data.event.ManagedElementChangeEvent;
import com.nortel.cdma.common.data.event.ManagedElementDeleteEvent;
import com.nortel.cdma.common.data.event.SubsystemEntityCreatedEvent;
import com.nortel.cdma.common.data.event.SubsystemEvent;
import com.nortel.cdma.common.data.event.SubsystemEntityDeletedEvent;
import com.nortel.cdma.common.data.event.NotificationRecord;
import com.nortel.cdma.common.data.autogen.enumerated.CardStateEnum;
import com.nortel.cdma.common.data.autogen.FQTN;
import com.nortel.cdma.common.data.request.ActionRequest;
import com.nortel.cdma.common.data.errors.DataServiceInternalError;
import com.nortel.cdma.common.InvalidArgumentException;
import com.nortel.cdma.common.security.SecurityViolationException;
import com.nortel.cdma.common.session.SessionId;
import com.nortel.cdma.common.cms.CMServicePublishedInterface;
import com.nortel.cdma.common.cms.ConfigurationException;
import com.nortel.cdma.gsf.ResourceUnavailableException;
import com.nortel.cdma.gsf.service.ServerServiceManager;

import java.util.ArrayList;
import java.rmi.RemoteException;

import org.apache.log4j.Logger;

/**
 * This class describes an SLS event manager as how to  interact with Notification Service. That is,
 * subscribing the CSL related events, handling the incoming events and publishing the CSL events
 * if any.
 */

public class SLSEventManager extends CSLEventManager  {

  /**
   * A static field to hold the instance of this class.
   */
  private static SLSEventManager moInstance = null;

  /**
   * Instance of Log4j.Logger.
   */
  private final static Logger log4jDebugLogger = Logger.getLogger(SLSEventManager.class);

  /**
   * List of initialized Reader instances.
   */
  private ArrayList<XDRLiteReader> maoReaders;

  /**
   * List of initialized ArchiveServerWriter instances.
   */
  private ArrayList<GenericStreamWriter> maoStreamWriter;

  /**
   * Reference to mCardIdFDNMapping.
   */
  private CardIdFDNMapping mCardIdFDNMapping;


  /**
   * Get the singleton instance of the SLSEventManager.
   * @return CSLEventManager object instance
   */
  public static synchronized SLSEventManager getInstance() {
    if(moInstance == null) {
      moInstance = new SLSEventManager();
    }
    return moInstance;
  }

  /**
   * Creates an instance of this class.
   */
  public SLSEventManager() {
    maoStreamWriter = new ArrayList<GenericStreamWriter> ();
    mCardIdFDNMapping = CardIdFDNMapping.getInstance();
  }

  /**
   * Receives incoming events from Notification service.
   * Implementation of NotificationEventListener interface.
   * @param oEvent the received notification
   */
  public synchronized void handleNotificationEvent(Event oEvent) {

    if (oEvent == null) {
      log4jDebugLogger.error("Got null event");
      return;
    }

    if(oEvent instanceof ManagedElementAttributeChangeEvent) {

      ManagedElementAttributeChangeEvent event = (ManagedElementAttributeChangeEvent)oEvent;

      ManagedElement me = event.getManagedElement();
      if(me == null) {
        log4jDebugLogger.error("Got null ManagedElement from ManagedElementAttributeChangeEvent");
        return;
      }

      CardStateEnum cardState = CSLUtil.getCardState(me);

      if ((cardState != null) && (cardState.equals(CardStateEnum.ET_INITIALIZED))) {
        handleCardInitializedEvent(me);
      }
      else {
        handleSpecificAttributeGroupUpdate(me);
      }
    }

    //handle ME create/delete events
    else if (oEvent instanceof ManagedElementChangeEvent) {
      ManagedElementChangeEvent event = (ManagedElementChangeEvent) oEvent;
      handleManagedElementChangeEvent(event);
    }

    //handle MO create/delete events
    else if (oEvent instanceof SubsystemEvent) {
      SubsystemEvent event = (SubsystemEvent) oEvent;
      handleSubsystemEvent (event);
    }
  }

  /**
   * Help method to subscribe CSL related events.
   * @throws com.nortel.cdma.gsf.ResourceUnavailableException
   */
  protected void subscribeEvents() throws ResourceUnavailableException {
    if (moNotificationServiceRef == null) {
      throw new ResourceUnavailableException("CSLEventManager:",
        "subscribeEvents()");
    }

    Exception moException = null;

    EventFilter [] aFilters = new EventFilter [] {
      new CSLAttributeChangeEventFilter(),
      new MOChangeEventFilter(),
      new MEChangeEventFilter(),
      new CardInitializedEventFilter()
    };


    try {

      for (EventFilter oFilter: aFilters) {
        moNotificationServiceRef.subscribe(this,  oFilter);
      }
    }
    catch (ResourceUnavailableException e) {
      moException = e;
    }
    catch (InvalidArgumentException e) {
      moException = e;
    }
    catch (NotificationException e) {
      moException = e;
    }

    if (moException != null) {
      log4jDebugLogger.error("Unable to subscribe CSL related events", moException);
    }
  }

  /**
   * Handles ME Create/Delete events by updating mapping info cache and
   * sending CSP mapping control record.
   * @param event the subsystem event
   */
  private void handleManagedElementChangeEvent(ManagedElementChangeEvent event) {

    ManagedElement me = event.getManagedElement();
    if(me == null) {
      log4jDebugLogger.error("Got null ManagedElement from ManagedElementChangeEvent");
      return;
    }

    String szMsg = null;
    if (event  instanceof ManagedElementCreateEvent) {
      szMsg = "Triggered by ManagedElementCreateEvent";
    }
    else if (event instanceof ManagedElementDeleteEvent) {
      szMsg = "Triggered by ManagedElementDeleteEvent";
    }
    else if (event instanceof ManagedElementRecursiveDeleteEvent) {
      szMsg = "Triggered by ManagedElementRecursiveDeleteEvent";
    }
    if (szMsg != null) {
      mCardIdFDNMapping.sendControlRecord(szMsg);
    }
  }

  /**
   * Add initialized Readers to local cache for event processing.
   * @param aoReaders the initialized Reader objects
   */
  public void registerReaders(ArrayList<XDRLiteReader> aoReaders) {
    if (aoReaders != null) {
      maoReaders  = aoReaders;
    }
  }

  /**
   * Add initialized GenericStreamWriter to local cache for event processing.
   * @param aoStreamWriter the initialized GenericStreamWriter
   */
  public void registerStreamWriter(ArrayList<GenericStreamWriter> aoStreamWriter) {
    if (aoStreamWriter != null) {
      maoStreamWriter  = aoStreamWriter;
    }
  }

  /**
   *  Retrieves the the updated attribute group from the desired ManagedElement
   *  and handles the changes.
   * @param me the ManagedElement object which contains the updated attribute group
   */
  protected void handleSpecificAttributeGroupUpdate (ManagedElement me) {

    ExternalServerConfig oCASConfig = new ExternalServerConfig(me);

    if (oCASConfig.isValid()) {
      String szCASIPAddress = oCASConfig.getExternalServerIPAddress();
      short sPortId = oCASConfig.getExternalServerPortId();

      if (maoStreamWriter.size() == 0) {
        log4jDebugLogger.error("No GenericStreamWriter is available to handle" +
          " ExternalServerConfig attribute group update");
        return;
      }
      for (GenericStreamWriter oArchiveWriter:maoStreamWriter) {
        oArchiveWriter.handleExternalServerConfigAttGrpUpdate(szCASIPAddress, sPortId);
      }
    }

    //handle attribute change for CSLProfile.ATTGRP_AttributeFilter
    AttributeGroup oAttFilterGrp = CSLUtil.getAttributeFilterGrpFrom(me);
    if (oAttFilterGrp != null) {

      for (XDRLiteReader oXDRLReader:maoReaders) {
        oXDRLReader.updateCSLAttributeFilter();
      }
    }
  }

  /**
   * Handles MO Create/Delete events by updating mapping info cache and
   * sending CSP mapping control record.
   * @param event the subsystem event
   */
  private void handleSubsystemEvent (SubsystemEvent event) {
    NotificationRecord oRecord = event.getNotificationRecord();

    if (oRecord != null) {
      AbstractManagedElementId meId = oRecord.getMeId();

      if (meId != null) {
        String szMsg = null;
        if (event instanceof SubsystemEntityCreatedEvent) {
          szMsg = "Triggered by MO create event";
        }
        else if (event instanceof SubsystemEntityDeletedEvent) {
          szMsg = "Triggered by MO delete event";
        }
        if (szMsg != null) {
          mCardIdFDNMapping.sendControlRecord(szMsg);
        }
      }
    }
  }

  /**
   * Handle the event which indicates the card is initialized. If the initialized
   * card is CSL enabled, will perform UnlockCSL action to CMS.
   * @param me the card me.
   */
  private void  handleCardInitializedEvent (ManagedElement me) {
    AbstractManagedElementId cardMeId = me.getId();
    if (cardMeId != null) {
      AbstractManagedElementId [] cslEnabledCards = CSLUtil.getCSLUnlockedCards();
      for (AbstractManagedElementId meId: cslEnabledCards) {
        if (cardMeId.equals(meId)) {
          //perform UnlockCSL action on this card
          performUnlockCSLAction (cardMeId);
        }
      }
    }
  }

  /**
   * Build and send UnlockCSL action request to CMS.
   * @param meId the CSL card ME Id;
   */
  private void performUnlockCSLAction (AbstractManagedElementId meId) {

    AbstractManagedElementId targetMEId = getTargetMEId (meId);
    if (targetMEId == null) {
      log4jDebugLogger.error("Got null target ME Id. Stop performing UnlockCSL action");
      return;
    }

    boolean overrideValidation = true; //bypass DV for UnlockCSL action
    boolean confirmationFlag = false;

    String szFullActionName = "CEMS:ACT:" + targetMEId.getManagedElementType().getLocalName() + ":UnlockCSL";

    FullyQualifiedTypeName action = new FullyQualifiedTypeName(szFullActionName);
    ActionRequest actRequest = new ActionRequest(targetMEId,
      overrideValidation,
      action,
      confirmationFlag,
      new Parameter[0],
      new ParameterGroup[0]);

    CMServicePublishedInterface cmsIfc = CSLUtil.getCMServiceInterface();

    if (cmsIfc == null) {
      log4jDebugLogger.error("Unable to get the CMS interface");
      return;
    }

    ActionRequest[] actionArray = new ActionRequest[] {actRequest};

    ServerServiceManager  serviceMgr = ServerServiceManager.getInstance();
    SessionId             sessionId = serviceMgr.getReservedSessionId();
    long                  operationId = System.currentTimeMillis();

    try {
      cmsIfc.performActions(sessionId, actionArray, false, operationId, false);
    }
    catch (SecurityViolationException e) {
      log4jDebugLogger.error("got Security exception",  e);
    }
    catch (ConfigurationException e) {
      log4jDebugLogger.error("Got Configuration exception",  e);
    }
    catch (RemoteException e) {
      log4jDebugLogger.error("got Remote exception",  e);
    }
  }

  /**
   * If the card type is of DSFP, DSFPV or PCUFP card, need to get its interface ME id since
   * UnlockCSL action is defined there.
   * @param meId the card ME Id
   * @return the card ME Id
   */
  private AbstractManagedElementId getTargetMEId (AbstractManagedElementId meId) {
    AbstractManagedElementId targetMEId = null;

    FullyQualifiedTypeName cardType = meId.getManagedElementType();

    if ((cardType.equals(FQTN.ELM_PCUFPCard.TYPE_NAME)) ||
      (cardType.equals(FQTN.ELM_DSFPDCard.TYPE_NAME)) ||
      (cardType.equals(FQTN.ELM_DSFPVCard.TYPE_NAME))) {

      ManagedElementDataAccessInterface dac = CSLUtil.getMeDAC();

      if (dac != null) {

        Exception e = null;
        try {
          ManagedElementId[] meIds = dac.getChildrenIds(meId, null);

          if ((meIds != null) && (meIds.length != 0)) {
            targetMEId = meIds[0];
          }
          else {
            log4jDebugLogger.error("cannot get the children ME id for card ("
              + meId.toFullyDistinguishedName() + ")");
          }
        }
        catch (RemoteException re) {
          e = re;
        }
        catch (DatabaseUnavailable de) {
          e = de;
        }
        catch (DataServiceInternalError die) {
          e = die;
        }
        catch (InvalidManagedElementId ime) {
          e = ime;
        }
        if (e != null) {
          log4jDebugLogger.error("Unable to get target ME Id ", e);
        }
      }
    }
    return targetMEId;
  }
}
