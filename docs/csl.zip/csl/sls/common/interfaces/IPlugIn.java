/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.common.interfaces;

import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.ResourceUnavailableException;
import com.nortel.cdma.gsf.InvalidDeploymentException;

import java.util.Properties;

/**
 * This interface describes an IPlugIn which details the life-cycle of a PlugIn.
 */
public interface IPlugIn extends IRegistration, IStreamReceiver {
  /**
   * Configuration method allowing passed in Properties to be saved.
   * @param oProperties the Properties to be saved
   */
  void config(Properties oProperties);

  /**
   * Method allowing a PlugIn to be started.
   * @throws InitializationFailureException
   * @throws InvalidDeploymentException
   */
  void startup() throws InitializationFailureException, 
    InvalidDeploymentException;

  /**
   * Method allowing a PlugIn to be shutdown.
   */
  void shutdown();
}
