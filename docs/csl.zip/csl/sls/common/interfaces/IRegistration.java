/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.common.interfaces;

import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;

/**
 * This interface describes an IRegistration which details how PlugIn's should be connected.
 */
public interface IRegistration {
  /**
   * Adds a consumer to a producers notification list.
   * @param oStreamReceiver the IStreamReceiver receiver to register
   */
  void register(IStreamReceiver oStreamReceiver);

  /**
   * Removes a consumer from a producers notification list.
   * @param oStreamReceiver the IStreamReceiver receiver to deregister
   */
  void deregister(IStreamReceiver oStreamReceiver);
}
