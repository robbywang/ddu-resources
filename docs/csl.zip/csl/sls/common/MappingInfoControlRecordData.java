/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.sls.common;

import com.nortel.cdma.service.csl.common.BaseCSPControlRecordData;
import com.nortel.cdma.service.csl.common.CSPControlRecordHeader;
import com.nortel.cdma.comm.modata.MOObjectId;
import com.nortel.cdma.common.data.elements.ManagedElementId;


import org.apache.log4j.Logger;
import java.nio.ByteBuffer;
import java.nio.BufferOverflowException;
import java.util.TreeMap;
import java.util.Map;

/**
 * This class represents the card OID/MEID to FDN mapping info
 * control record data.
 */
public class MappingInfoControlRecordData extends BaseCSPControlRecordData {

  /**
   * Instance of Log4j Logger.
   */
  private static final Logger log4jDebugLogger =
    Logger.getLogger(MappingInfoControlRecordData.class);

  /**
   *  The mapping info cache.
   */
  private static TreeMap<String, Object>  mMappingInfo;

  /**
   *  The SBS card mapping info cache.
   */
  private static TreeMap<String, MOObjectId>  mSBSMappingInfo;


  /**
   *  The EBSC mapping info cache.
   */
  private static  TreeMap<String, ManagedElementId>   mEBSCMappingInfo;

  /**
   *  The total length of the mapping records.
   */
  private static int miMappingRecordLength = 0;


  /**
   * Constructor.
   *
   * @param header           The csp control record header
   * @param mappingInfo   The TreeMap object which contains the mapping info
   * @param additionalMessage   The control record text message
   * @throws                IllegalArgumentException
   */
  public MappingInfoControlRecordData(CSPControlRecordHeader header,
                                      TreeMap<String, Object> mappingInfo,
                                      String additionalMessage  )
    throws IllegalArgumentException {
    super(header, additionalMessage);

    if (mappingInfo  == null) {
      String szError = "got null TreeMap of mapping info";
      log4jDebugLogger.error(szError);
      throw new IllegalArgumentException(szError);
    }
    mMappingInfo = mappingInfo;
    refineMappingInfo();
  }

  /**
   *  Refines Mapping info and builds separate mapping info caches for
   *  SBS card and eBSC card.
   */
  private  void  refineMappingInfo() {

    mSBSMappingInfo = new TreeMap<String, MOObjectId> ();
    mEBSCMappingInfo = new TreeMap<String, ManagedElementId> ();

    int iMappingRecordLength = 0;

    // Number of Mapping Entries: 2 bytes (uint16) each for
    // SBS card type and eBSC card type.
    iMappingRecordLength += 4;

    if (!mMappingInfo.isEmpty()) {

      for ( Map.Entry<String, Object> oEntry : mMappingInfo.entrySet() )  {
        String szFdn  = oEntry.getKey();
        Object obj = oEntry.getValue();

        if (obj == null) {
          log4jDebugLogger.error("Got null Object (OID or ME ID value in mapping cache ");
          continue;
        }

        if (szFdn == null) {
          log4jDebugLogger.error("Got null FDN in mapping cache ");
          continue;
        }

        if (obj instanceof MOObjectId) {
          MOObjectId moId = (MOObjectId) obj;
          mSBSMappingInfo.put(szFdn, moId);

          //For SBS card, the key is MOObjectId and the field occupies 10 bytes: agentId (4 bytes),
          // MOClassId (2 bytes), MOVersion (2 bytes), MOInstance (2 bytes).
          iMappingRecordLength += 10;

        }
        else if (obj instanceof ManagedElementId) {
          ManagedElementId meId = (ManagedElementId) obj;
          mEBSCMappingInfo.put(szFdn, meId);

          //For eBSC Card, the key is ME ID which is 8 bytes (i.e. uint64)
          iMappingRecordLength += 8;

        }

        //count FDN length
        byte[] fdnBytes = szFdn.getBytes();
        // 2 bytes (uint16) FDN length field pluc the actual FDN byte array size
        iMappingRecordLength +=  2  +  fdnBytes.length;
      }
    }
    miMappingRecordLength = iMappingRecordLength;
  }

  /**
   * Returns the csp control record data length.
   *
   * @return the csp control record data length
   */
  public int length() {
    if (miMappingRecordLength ==0) {
      log4jDebugLogger.error("MappingRecordLength is not correct");
      return 0;
    }
    return super.length() + miMappingRecordLength;
  }

  /**
   * Writes this object to a byte buffer.
   *
   * @return  The byte buffer containing this object
   */
  protected ByteBuffer writeToBuffer() {

    ByteBuffer buffer = ByteBuffer.allocate(length());

    try {
      //writes common header
      buffer.put(header().getBytes());

      //write EBSC mapping info into buffer
      int iNumEBSCEntries = mEBSCMappingInfo.size();
      buffer.putShort((short)iNumEBSCEntries); //2 bytes

      if (iNumEBSCEntries != 0) {
        for ( Map.Entry<String, ManagedElementId> oEntry : mEBSCMappingInfo.entrySet() )  {
          String szFdn  = oEntry.getKey();
          ManagedElementId meId = oEntry.getValue();
          long lCardId = meId.getValue();
          buffer.putLong(lCardId); // 8 bytes (uint64)

          //write FDN String
          buffer = addFDNToByteBuffer(buffer, szFdn);
        }
      }

      int iNumSBSEntries = mSBSMappingInfo.size();
      buffer.putShort((short)iNumSBSEntries); //2 bytes

      if (iNumSBSEntries != 0) {
        for ( Map.Entry<String, MOObjectId> oEntry : mSBSMappingInfo.entrySet() )  {
          String szFdn  = oEntry.getKey();
          MOObjectId moId = oEntry.getValue();
          long lAgentId = moId.getAgentId().getValue();
          int iMOClass = moId.getClassType().getValue();
          int iVersion = moId.getVersion();
          int iInstance = moId.getInstanceId();


          /*
          For SBS card, the key is MOObjectId and the field occupies 10 bytes. See the schema definition as follows

          <field outputformat="hex">
          <name>OID: Agent Id</name>
          <datatype>uint32</datatype>
          <description>Agent Id part of OID </description>
          </field>
          <field outputformat="hex">
          <name>OID: MOClassId</name>
          <datatype>uint16</datatype>
          <description>MO Class Id part of OID </description>
          </field>
          <field outputformat="hex">
          <name>OID: MOVersion</name>
          <datatype>uint16</datatype>
          <description>MO Version part of OID </description>
          </field>
          <field outputformat="hex">
          <name>OID: MOInstance</name>
          <datatype>uint16</datatype>
          <description>MO Instance part of OID </description>
          </field>
          */
          buffer.putInt((int)lAgentId);
          buffer.putShort((short)iMOClass);
          buffer.putShort((short)iVersion);
          buffer.putShort((short)iInstance);

          //write FDN String
          buffer = addFDNToByteBuffer(buffer, szFdn);
        }
      }

      //write the additional message
      byte[] msgBytes = controlMessage().getBytes();
      buffer.put((byte)msgBytes.length);
      buffer.put(msgBytes);

      //add common footer
      buffer.putShort(mFooter);
    }
    catch (BufferOverflowException be) {
      log4jDebugLogger.error("Got insufficient ByteBuffer to write", be);
      return null;
    }

    return buffer;
  }

  /**
   * Helper method to add FND string to ByteBuffer.
   * @param buffer the ByteBuffer.
   * @param szFDN the FDN string to write
   * @return ByteBuffer which contains the required FDN string
   */
  private ByteBuffer addFDNToByteBuffer (ByteBuffer buffer, String szFDN) {
    //write FDN String
    byte[] fdnBytes = szFDN.getBytes();
    buffer.putShort((short)fdnBytes.length);
    buffer.put(fdnBytes);
    return buffer;
  }

  /**
   * Returns a string representation of this object.
   *
   * @return  The string representation of this object
   */
  public String toString() {
    StringBuffer buf = new StringBuffer();

    buf.append(super.toString());

    buf.append("\n eBSC card mapping entries: \n").append(mEBSCMappingInfo);
    buf.append("\n SBS card mapping entries: \n").append(mSBSMappingInfo);
    String controlMessage = controlMessage();

    if (controlMessage.length() != 0) {
      buf.append("\n").append(controlMessage);
    }
    return buf.toString();
  }
}
