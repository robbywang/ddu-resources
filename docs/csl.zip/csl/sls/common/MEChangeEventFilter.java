/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved
 */

package com.nortel.cdma.service.csl.sls.common;

import com.nortel.cdma.common.data.autogen.FQTN;
import com.nortel.cdma.common.data.elements.FullyQualifiedTypeName;
import com.nortel.cdma.common.data.elements.ManagedElement;
import com.nortel.cdma.common.data.event.ManagedElementCreateEvent;
import com.nortel.cdma.common.data.event.ManagedElementDeleteEvent;
import com.nortel.cdma.common.data.event.ManagedElementRecursiveDeleteEvent;
import com.nortel.cdma.common.data.event.ManagedElementChangeEvent;
import com.nortel.cdma.service.notification.Event;
import com.nortel.cdma.service.notification.EventFilter;
import org.apache.log4j.Logger;

/**
 * Filter class used to get ManagedElementCreateEvent and ManagedElementDeleteEvent.
 */
public class MEChangeEventFilter extends EventFilter {

  /**
   * Instance of Log4j.Logger.
   */
  private final static Logger log4jDebugLogger = Logger.getLogger(MEChangeEventFilter.class);

  /**
   * The event filter name.
   */
  private final static String EVENT_FILTER_NAME = "MEChangeEventFilter";

  /**
   * Constructor.
   */
  public MEChangeEventFilter() {
  }

  /**
   * Return the target ManagedElementAttributeChangeEvent class.
   * @return the event class
   */
  public Class getEventClass() {
    return ManagedElementChangeEvent.class;
  }

  /**
   * Catches all the events from the event class specified by this filter.
   * @param notifEvent the event in the notification service queue
   * @return boolean if the event matches; false otherwise
   */
  public boolean eventMatches(Event notifEvent) {

    boolean bResult = false;

    if (notifEvent == null) {
      return false;
    }

    if ((notifEvent instanceof ManagedElementCreateEvent) ||
      (notifEvent instanceof ManagedElementDeleteEvent) ||
      (notifEvent instanceof ManagedElementRecursiveDeleteEvent)) {
      ManagedElementChangeEvent event =
        (ManagedElementChangeEvent) notifEvent;

      ManagedElement me = event.getManagedElement();
      if (me != null) {
        FullyQualifiedTypeName meType = me.getTypeName();

        FullyQualifiedTypeName oDSFPDFdn = FQTN.ELM_DSFPDCard.TYPE_NAME;
        FullyQualifiedTypeName oPCUFPFdn = FQTN.ELM_PCUFPCard.TYPE_NAME;
        FullyQualifiedTypeName oDSFPVCard = FQTN.ELM_DSFPVCard.TYPE_NAME;

        if ((meType.equals(oDSFPDFdn)) ||
          (meType.equals(oPCUFPFdn)) ||
          (meType.equals(oDSFPVCard))){
          bResult = true;
          log4jDebugLogger.debug("Received event " + event);
        }
      }
    }
    return bResult;
  }

  /**
   * Returns the name of the filter.
   * @return name (string) the name.
   */
  public String getName() {
    return EVENT_FILTER_NAME;
  }
}
