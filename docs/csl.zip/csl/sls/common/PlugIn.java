/*
* Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
*/

package com.nortel.cdma.service.csl.sls.common;

import com.nortel.cdma.service.csl.sls.common.interfaces.IPlugIn;
import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;

import java.util.HashSet;
import java.util.Properties;
import java.util.Map;
import java.util.Set;
import java.io.FileInputStream;
import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;

/**
 * This class describes a PlugIn which is the base class for Reader's, Filter's, and Writer's.
 */
public abstract class PlugIn implements IPlugIn {
    /**
     *  Flag to indicate that the PlugIn has started.
     */
    protected boolean mbStarted = false;

    /**
     *  Flag to indicate that the PlugIn should stop.
     */
    protected boolean mbIsStopping = false;

    /**
     *  The PlugIn name.
     */
    protected String mszName;

    /**
     *  The list of PlugIns attached to this PlugIn.
     */
    protected HashSet<IStreamReceiver> moHashSetStreamReceivers;

    /**
     *  The set of Properties specified in the plugin properties file.
     */
    protected Properties moProperties;

    /**
     *  The set of parsed Properties specified in the plugin properties file.
     */
    protected Properties moPropertiesParsed;

    /**
     * The name of the property that specifies the configuration file name.
     */
    protected static final String CONFIG_FILE_PROPERTY = "configfile";

    /**
     * The name of the property that specifies the configuration file name.
     */
    protected static final String PLUGIN_NAME = "name";

    /**
     * The name of the property that specifies the configuration file name.
     */
    protected static final String DESCRIPTION = "description";

    /**
     * The name of the property that specifies the enabled status.
     */
    protected static final String XMLTAG_ENABLED = "enabled";

    /**
     * Stores the plug-in description that every plug-in has.
     */
    protected String mszDescription;

    /**
     *  Flag to indicate whether the PlugIn is enabled.
     */
    protected boolean mbEnabled;


    /**
     *  The Plugin type.
     */
    protected String mszPluginType = "PlugIn";

    /**
     * Stores the plug-in configuration file name that every plug-in has.
     */
    protected String mszConfigFile;

    /**
     *  Instance of debug logger.
     */
    private static final Logger log4jDebugLogger = Logger.getLogger(PlugIn.class);

    /**
     * Default constructor for the PlugIn object.
     */
    public PlugIn() {
        moHashSetStreamReceivers = new HashSet<IStreamReceiver>();
    }

    /**
     *  Gets the name of the PlugIn.
     * @return  a string representation for the name of the Action
     * @see #setName
     */
    public String getName() {
        return mszName;
    }

    /**
     *  Sets the name of the Action.
     * @param szName the name of the action
     * @see #getName
     */
    public void setName(String szName) {
        if ( szName == null ) {
            mszName = "Unnamed";
        }
        else {
            mszName = szName;
        }
    }

    /**
     *  Gets the config file for this PlugIn.
     * @return  a string representation for the the config file for this PlugIn
     * @see #setConfigfile
     */
    public String getConfigfile() {
        return mszConfigFile;
    }

    /**
     *  Sets the config file for this PlugIn.
     * @param szConfigFile the config file for this PlugIn
     * @see #getConfigfile
     */
    public void setConfigfile(String szConfigFile) {
        mszConfigFile = szConfigFile;
    }

    /**
     *  Gets the config file for this PlugIn.
     * @return  a string representation for the the config file for this PlugIn
     * @see #setDescription
     */
    public String getDescription() {
        return mszDescription;
    }

     /**
      * Returns the parsed properties object.
      * @return
      */
    public Properties getParsedProperties() {
        return moPropertiesParsed;
    }

    /**
     *  Sets the config file for this PlugIn.
     * @param szDescription the config file for this PlugIn
     * @see #getDescription
     */
    public void setDescription(String szDescription) {
        mszDescription = szDescription;
    }

    /**
     *  Gets the enabled status for this PlugIn.
     * @return  flag indicates this PlugIn enabled status
     * @see #setEnabled
     */
    public boolean isEnabled() {
        return mbEnabled;
    }

    /**
     *  Sets the enabled status for this PlugIn.
     * @param bEnabled the enabled status
     * @see #isEnabled
     */
    public void setEnabled(boolean bEnabled) {
        mbEnabled = bEnabled;
    }

    /**
     * Configures a PlugIn.
     * @param oProperties the set of Properties created by an XML file
     */
    public void config(Properties oProperties) {
        
        moPropertiesParsed = new Properties();
        if ( oProperties == null ) {
            return;
        }

        moProperties = oProperties;

        String szName = (String) oProperties.get( PLUGIN_NAME );

        if ( szName == null ) {
            log4jDebugLogger.error( "Plug-in name is not set.");
        }
        else {
            setName( szName );
        }

        String szConfigFile = (String) oProperties.get( CONFIG_FILE_PROPERTY );

        if ( szConfigFile == null ) {
            log4jDebugLogger.info( "Plug-in has no config file.");
        }
        else {
            setConfigfile( szConfigFile );
            FileInputStream oFileInputStream = null;

            try {
                File oFile = new File(szConfigFile);
                oFileInputStream = new FileInputStream(oFile);

                moPropertiesParsed.load( oFileInputStream );
            }
            catch (IOException e) {
                log4jDebugLogger.error(e);
            }
            finally {
                try {
                    if ( oFileInputStream != null ) {
                        oFileInputStream.close();
                    }
                }
                catch (IOException e) {
                    log4jDebugLogger.error("Unable to close FileInputStream", e);
                }
            }
        }
        String szDescription = (String) oProperties.get( DESCRIPTION );

        if ( szDescription == null ) {
            szDescription = "Plug-in has no description.";
        }
        setDescription( szDescription );

        String szEnabled = (String) oProperties.get(XMLTAG_ENABLED);

        if ( szEnabled == null ) {
            szEnabled = "true";
        }
        setEnabled(Boolean.parseBoolean(szEnabled));
    }

    /**
     * Starts up the PlugIn.
     * @throws InitializationFailureException
     * @throws InvalidDeploymentException
     */
    public void startup() throws InitializationFailureException,
        InvalidDeploymentException {
        if ( ! mbStarted ) {
            mbStarted = true;

            printStartMessage();
            localStartup();
        }
    }

    /**
     * Starts up the PlugIn locally.
     * @throws InitializationFailureException
     * @throws InvalidDeploymentException
     */
    protected void localStartup() throws InitializationFailureException,
        InvalidDeploymentException {
        
    };

    /**
     * Shuts down the PlugIn.
     */
    public void shutdown() {
        mbIsStopping = true;
    }

    /**
     * The IStreamReceiver interface implementation that handles the stream.
     * @param abInputBuffer the byte array to be handled
     * @param iOffset the offset in the byte array of the data to be handled
     * @param iLength the length of the byte array to be handled
     */
    abstract public void handleStream(byte[] abInputBuffer, int iOffset, int iLength);

    /**
     * Adds the given IStreamReceiver to the list of stream receivers.
     * @param oStreamReceiver the IStreamReceiver to be registered
     */
    public void register( IStreamReceiver oStreamReceiver ) {
        moHashSetStreamReceivers.add( oStreamReceiver );
    }

    /**
     * Removes the given IStreamReceiver from the list of stream receivers.
     * @param oStreamReceiver the IStreamReceiver to be deregistered
     */
    public void deregister( IStreamReceiver oStreamReceiver ) {
        moHashSetStreamReceivers.remove( oStreamReceiver );
    }

    /**
     * Prints the start-up parameters.
     */
    protected void printStartMessage() {
        log4jDebugLogger.info("Plug-in Type=" + mszPluginType + " Name=" + mszName );

        Set<Map.Entry<Object, Object>> oSetKeys = moProperties.entrySet();

        for ( Map.Entry<Object, Object> oEntry : oSetKeys ) {
            String szKey = (String) oEntry.getKey();
            String szValue = (String) oEntry.getValue();

            log4jDebugLogger.info("Property: " + szKey + "=" + szValue );
        }
    }
}
