/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved
 */

package com.nortel.cdma.service.csl.sls.common;

import com.nortel.cdma.common.data.autogen.FQTN;
import com.nortel.cdma.common.data.elements.FullyQualifiedTypeName;
import com.nortel.cdma.common.data.elements.AbstractManagedElementId;
import com.nortel.cdma.common.data.elements.FullyDistinguishedName;
import com.nortel.cdma.common.data.event.SubsystemEntityCreatedEvent;
import com.nortel.cdma.common.data.event.SubsystemEvent;
import com.nortel.cdma.common.data.event.SubsystemEntityDeletedEvent;
import com.nortel.cdma.common.data.event.NotificationRecord;
import com.nortel.cdma.service.notification.Event;
import com.nortel.cdma.service.notification.EventFilter;
import org.apache.log4j.Logger;

/**
 * Filter class used to get MOCreated event and MODeleted event for CSL relatd cards.
 */
public class MOChangeEventFilter extends EventFilter {

  /**
   * Instance of Log4j.Logger.
   */
  private final static Logger log4jDebugLogger = Logger.getLogger(MOChangeEventFilter.class);

  /**
   * The event filter name.
   */
  private final static String EVENT_FILTER_NAME = "MOChangeEventFilter";

  /**
   * Constructor.
   */
  public MOChangeEventFilter() {
  }

  /**
   * Return the target SubsystemEvent class.
   * @return the event class
   */
  public Class getEventClass() {
    return SubsystemEvent.class;
  }

  /**
   * Catches all the events from the event class specified by this filter.
   * @param notifEvent the event in the notification service queue
   * @return boolean if the event matches; false otherwise
   */
  public boolean eventMatches(Event notifEvent) {

    boolean bResult = false;

    if (notifEvent == null) {
      return false;
    }

    if ((notifEvent instanceof SubsystemEntityCreatedEvent) ||
      (notifEvent instanceof SubsystemEntityDeletedEvent)) {
      SubsystemEvent event = (SubsystemEvent) notifEvent;

      NotificationRecord oRecord = event.getNotificationRecord();

      if (oRecord != null) {
        AbstractManagedElementId meId = oRecord.getMeId();

        if (meId != null) {
          FullyDistinguishedName oFdn = meId.toFullyDistinguishedName();

          if (oFdn != null) {

            FullyQualifiedTypeName oESEL_Fdn = FQTN.ELM_ESelectorCard.TYPE_NAME;
            FullyQualifiedTypeName oSICS_Fdn = FQTN.ELM_SCIS.TYPE_NAME;

            if ((oFdn.equals(oESEL_Fdn)) || (oFdn.equals(oSICS_Fdn))){
              log4jDebugLogger.debug("received MO change event: " + oRecord.toJournalLogString() );
              bResult = true;
            }
          }
        }
      }
    }
    return bResult;
  }

  /**
   * Returns the name of the filter.
   * @return name (string) the name.
   */
  public String getName() {
    return EVENT_FILTER_NAME;
  }
}
