/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */
package com.nortel.cdma.service.csl.sls.common;

import com.nortel.cdma.service.csl.common.BaseCSPControlRecordData;
import com.nortel.cdma.service.csl.common.CSPControlRecordHeader;

// Java
import java.nio.ByteBuffer;

/**
 * This class represents the csp control record data.
 */
public class SLSControlRecordData extends BaseCSPControlRecordData {

  /**
   * Constant represents size of the record length field.
   */
  private final static byte RECORD_LENGTH_SIZE = 2;

  /**
   * Number of log records filtered.
   */
  private long mNumLogsFiltered = 0L;

  /**
   * Constructor.
   *
   * @param header           The csp control record header
   * @param numLogsFiltered  The number of log records filtered
   * @param controlMessage   The control record text message
   *
   * @throws                IllegalArgumentException
   */
  public SLSControlRecordData(CSPControlRecordHeader header,
                              String controlMessage,
                              long numLogsFiltered)
                      throws IllegalArgumentException {
    super(header, controlMessage);

    mNumLogsFiltered = numLogsFiltered;
  }

  /**
   * Returns the SLS control record data length.
   *
   * @return the SLS control record data length
   */
  @Override
  public int length() {
    // 16 + 8 bytes of numLogsFiltered
    return super.length() + 8;
  }

  /**
   * Writes this object to a byte buffer.
   *
   * @return  The byte buffer containing this object
   */
  protected ByteBuffer writeToBuffer() {

    short recLen = (short) (RECORD_LENGTH_SIZE + length());

    ByteBuffer buffer = ByteBuffer.allocate(recLen);

    buffer.putShort(recLen);

    buffer.put(header().getBytes());

    buffer.putLong(mNumLogsFiltered);

    byte[] ctrlMsgBytes = controlMessage().getBytes();

    buffer.put((byte)(ctrlMsgBytes.length));

    buffer.put(ctrlMsgBytes);

    buffer.putShort(mFooter);

    return buffer;
  }

  /**
   * Returns a string representation of this object.
   *
   * @return  The string representation of this object
   */
  @Override
  public String toString() {
    StringBuffer buf = new StringBuffer();

    buf.append(super.toString());

    buf.append(", Number of filtered logs = ").append(mNumLogsFiltered);

    String controlMessage = controlMessage();

    if (controlMessage.length() != 0) {
      buf.append(", ").append(controlMessage);
    }

    return buf.toString();
  }
}
