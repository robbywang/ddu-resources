/*
* Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
*/

package com.nortel.cdma.service.csl.sls.writer.disk;

import com.nortel.cdma.service.csl.sls.writer.Writer;
import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.common.internationalization.CallSummaryLogMessageCategory;
import com.nortel.cdma.service.common.rollinglogfilemanager.SectionRouter;
import com.nortel.cdma.service.common.rollinglogfilemanager.SectionManager;
import com.nortel.cdma.service.common.overload.OverloadController;
import com.nortel.cdma.service.common.overload.OverloadInterface;
import org.apache.log4j.Logger;

import java.util.Date;

/**
 * This class describes a DiskWriter which describes how to write data disk using the SectionRouter.
 */
public class DiskWriter extends Writer implements OverloadInterface {

  /**
   * Reference to the SectionRouter instance.
   */
  private SectionRouter moSectionRouter;

  /**
    * Flag indicates if this class needs to handle the overloading action request.
    */
   private boolean mbHandleOverloading = false;


  /**
   * The default constructor the DiskWriter.
   */
  public DiskWriter() {
  }

  /**
    *  Instance of debug logger.
    */
   private static final Logger log4jDebugLogger = Logger.getLogger(DiskWriter.class);

  /**
   * OverloadController reference.
   */
   OverloadController moOverloadControllerRef = OverloadController.getInstance();

  /**
   * Required by all PlugIns.
   */
  protected void localStartup() {
    moSectionRouter = SectionRouter.getInstance();

    SectionManager oSectionManager = moSectionRouter.getSectionManager(mszName);

    if ( oSectionManager != null ) {
      int iOutputBufferSize = getOutputBufferSize();
      oSectionManager.setOutputBufferSize(iOutputBufferSize);

      moOverloadControllerRef.register( this );
    }
  }

  /**
   * Shutdown the disk writer.
   */
  @Override
  public void shutdown() {
    moOverloadControllerRef.deregister( this );
    super.shutdown();
  }

  /**
   * The IStreamReceiver interface implementation that handles the stream.
   * @param abInputBuffer the byte array to be handled
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the byte array to be handled
   */
  public synchronized void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {

    if (mbHandleOverloading) {
      //Stop writing CSL log to the disk
      return;
    }

    if (iLength < 1) {
      log4jDebugLogger.error("Got incorrect length of the byte array: " + iLength +
        ". Input data discarded");
      return;
    }

    moSectionRouter.write( mszName, abInputBuffer, iOffset, iLength );
  }

  /**
   * handle the action required by OverloadController.
   * @param iType the log type
   * @param iLevel the level of overload action
   */
  public void handleOverloadChange(int iType, int iLevel) {

    if (iLevel >= STOP_DISK_WRITER) {
      if (!mbHandleOverloading) {
        mbHandleOverloading = true;
        Date now = new Date(System.currentTimeMillis());

        //add info to journal log
        CSLUtil.createJournalLog(CallSummaryLogMessageCategory.OVERLOADING_STOP_DISKWRITER,
          new String [] {now.toString()});

        log4jDebugLogger.warn(new String ("Stop writing CSL log to disk at " + now + " because of CPU overloading"));
      }
    }
    else {
      if(mbHandleOverloading) {
    	  Date now = new Date(System.currentTimeMillis());
          CSLUtil.createJournalLog(CallSummaryLogMessageCategory.ABATED_OVERLOADING_START_DISKWRITER,
            new String [] {now.toString()});
      }
      mbHandleOverloading = false;
    }

    OverloadController.getInstance().notifyWhenDone( this );
  }

  /**
   * Gets the name of this class.
   * @return the class name
   */
  public String getIdentifier() {
    return ( getName() );
  }
}
