/*
* Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
*/

package com.nortel.cdma.service.csl.sls.writer;

import com.nortel.cdma.service.csl.sls.common.PlugIn;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 * This class describes a Writer which describes how to write an array of bytes.
 */
public abstract class Writer extends PlugIn {

  /**
   *  The Socket connecting to the External Server.
   */
  protected String mszSocketDestination;

  /**
   *  The port to connect to on the External Server.
   */
  protected short miPort = 0;

  /**
   *  The output buffer size. Default is 4MB.
   */
  protected int miOutputBufferSize = 4194304;

  /**
   * Instance of Log4j Logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(Writer.class);

  /**
   * The name of the property that specifies the configuration file name.
   */
  private static final String OUTPUT_BUFFER_SIZE = "outputbuffersize";

  /**
   * Default constructor for a Writer.
   */
  public Writer() {
    super();

    mszPluginType = "Writer";
  }

  /**
   * Configures a PlugIn.
   * @param oProperties the set of Properties created by an XML file
   */
  public void config(Properties oProperties) {
    super.config(oProperties);

    if ( oProperties == null ) {
      return;
    }

    String szOutputBufferSize = (String) oProperties.get( OUTPUT_BUFFER_SIZE );

    if ( szOutputBufferSize == null ) {
      log4jDebugLogger.error( "Output Buffer Size is null using default.");
    }
    else {
      setOutputBufferSize( szOutputBufferSize );
    }
  }

  /**
   * Gets the destination address. This address is typically the address to send a stream to.
   * @return a destination address to forward stream data to
   * @see #setDestinationAddress
   */
  public String getDestinationAddress() {
    return mszSocketDestination;
  }

  /**
   * Sets the destination address. This address is typically the address to send a stream to.
   * @param szSocketDestination the IP address to forward stream data to
   * @see  #getDestinationAddress
   */
  public void setDestinationAddress(String szSocketDestination) {
    mszSocketDestination = szSocketDestination;
  }

  /**
   * Gets the remote port to connect to.
   * @return an integer containing the remote port to connect to
   * @see #setPort
   */
  public short getPort() {
    return miPort;
  }

  /**
   * Sets the remote port to connect to.
   * @param iPort an integer containing the remote port to connect to
   * @see #getPort
   */
  public void setPort(short iPort) {
    miPort = iPort;
  }

  /**
   * Gets the output buffer size.
   * @return an integer containing the output buffer size
   * @see #setOutputBufferSize
   */
  public int getOutputBufferSize() {
    return miOutputBufferSize;
  }

  /**
   * Sets the output buffer size.
   * @param iOutputBufferSize an integer containing the output buffer size
   * @see #getOutputBufferSize
   */
  public void setOutputBufferSize(int iOutputBufferSize) {
    miOutputBufferSize = iOutputBufferSize;
  }

  /**
   * Sets the output buffer size.
   * @param szOutputBufferSize a String representing the output buffer size
   * @see #getOutputBufferSize
   */
  public void setOutputBufferSize(String szOutputBufferSize) {
    try {
      miOutputBufferSize = Integer.parseInt(szOutputBufferSize);
    }
    catch ( NumberFormatException e){
      log4jDebugLogger.error( "Output Buffer Size is null using default.");
      miOutputBufferSize = 4194304;
    }
  }

  /**
   * The entry point for a Plug-In to handle a datastream.
   * @param abInputBuffer the byte array to be handled
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the byte array to be handled
   */
  public abstract void handleStream(byte[] abInputBuffer, int iOffset, int iLength);

  /**
   * The interface for a Writer to flush its output stream.
   */
  public void flush() {
  }
}
