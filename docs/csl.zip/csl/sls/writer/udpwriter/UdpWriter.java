package com.nortel.cdma.service.csl.sls.writer.udpwriter;
import com.nortel.cdma.service.csl.sls.writer.Writer;
import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import com.nortel.cdma.gsf.util.ParameterInfo;

import java.util.Properties;
import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;

public class UdpWriter extends Writer {

    private long mlPacketSizeMax = Long.MIN_VALUE;
    private long mPacketSizeMin = Long.MAX_VALUE;
    private int miPacketNumber;
    private InetAddress moIPAdress;

    private final String szColumnNames = "Packet #,Packet Length,Total Bytes,Min Packet Size, Max Packet Size";

    /**
     * Instance of Log4j Logger.
     */
    private static final Logger log4jDebugLogger =
        Logger.getLogger("UdpWriter.class");

    /**
     * Initialization status.
     */
    private boolean mIsStarted = false;

    /**
     * The UDP server port.
     */
    private int  miPort = 2500;

    /**
     * The number of bytes sent in total.
     */
    private long mlTotalBytesSent = 0;

    /**
     * Constructor.
     */
    public UdpWriter() {
    }

    /**
     * Configures the EBSC Log Collector.
     *
     * @param  oPropertiesParm  The properties containing the StreamWriter
     *                     configuration information
     */
    public void config(Properties oPropertiesParm) {
        super.config( oPropertiesParm );

        Properties oProperties = getParsedProperties();

        String szPort = oProperties.getProperty("port");

        try {
            miPort = Integer.valueOf(szPort);
        }
        catch (NumberFormatException e) {
            log4jDebugLogger.error(e);
        }

        String szIpaddress = oProperties.getProperty("ipaddress");

        try {
            moIPAdress = InetAddress.getByName(szIpaddress);
        }
        catch (UnknownHostException e) {
            log4jDebugLogger.error(e);
        }

        log4jDebugLogger.debug(oProperties);
    }

    /**
     * Starts up the EBSC Log Collector.
     *
     * @throws InitializationFailureException upon initialization failure
     * @throws InvalidDeploymentException upon invalid deployment
     */
    public void startup() throws InitializationFailureException, InvalidDeploymentException {
        if (mIsStarted) {
            log4jDebugLogger.debug("Already started.");
            throw new InitializationFailureException("StreamWriter ",
                "StreamWriter is already started.");
        }


        String szApplication = getName();
        String szWidths = "";

        UdpUtil.sendDefinition(moIPAdress,
            miPort,
            szApplication,
            szColumnNames,
            szWidths);

        mIsStarted = true;
    }

    /**
     * Shuts down the EBSC Log Collector.
     */
    public void shutdown() {
    }

    /**
     * Gets the properties for the StreamWriter Service.
     * @return the service parameter array.
     */
    public ParameterInfo[] getRequiredProperties() {
        return ( new ParameterInfo[]{
            new ParameterInfo("cptName",
                "cptValue",
                "cptDesc")
        } );
    }

    /**
     * The IStreamReceiver interface implementation that handles the stream.
     * @param abInputBuffer the byte array to be handled
     * @param iOffset the offset in the byte array of the data to be handled
     * @param iLength the length of the byte array to be handled
     */
    public void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {

        mlTotalBytesSent += iLength;

        if ( iLength > mlPacketSizeMax ) {
            mlPacketSizeMax = iLength;
        }

        if ( iLength < mPacketSizeMin ) {
            mPacketSizeMin = iLength;
        }

        String szMessage = miPacketNumber++ + ","
            + iLength +  ","
            + mlTotalBytesSent +  ","
            + mPacketSizeMin +  ","
            + mlPacketSizeMax +  ",";

//         127.0.0.1 2500 "app=colours&id=Disk Writer&action=update&msg=70,60,380&"
        UdpUtil.sendData(moIPAdress,
            miPort,
            getName(),
            "udpWriter",
            "update",
            szMessage );

        for ( IStreamReceiver oIStreamReceiver : moHashSetStreamReceivers ) {
            oIStreamReceiver.handleStream( abInputBuffer, iOffset, iLength );
        }
    }

    public static void main(String[] aszArgs) {
        UdpWriter oUpdWriter = new UdpWriter();

        Properties oProperties = new Properties();

        oProperties.setProperty( PLUGIN_NAME, "StdUdpWriter" );
        oProperties.setProperty( CONFIG_FILE_PROPERTY, "/tmp/updwriter.cfg" );
        oProperties.setProperty(XMLTAG_ENABLED, "true");

        oUpdWriter.config(oProperties);

        try {
            oUpdWriter.startup();
            String szTest = "Hello World";
            byte[] abTest = szTest.getBytes();
            int iLength = szTest.length();

            for (int i=0; i< 10; i++) {
                oUpdWriter.handleStream(abTest, 0, iLength);

                try {
                    Thread.sleep( 1000 );
                }
                catch (InterruptedException e) {
                    log4jDebugLogger.error(e);
                }

            }
        }
        catch (InitializationFailureException e) {
            log4jDebugLogger.error(e);
        }
        catch (InvalidDeploymentException e) {
            log4jDebugLogger.error(e);
        }

    }
}
