package com.nortel.cdma.service.csl.sls.writer.udpwriter;

import org.apache.log4j.Logger;

import java.net.InetAddress;
import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.UnknownHostException;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: jasonwu1
 * Date: Nov 6, 2008
 * Time: 2:32:49 PM
 * To change this template use File | Settings | File Templates.
 */
public class UdpUtil {

    /**
     * The reference to the debug logger for this class.
     */
    private final static Logger log4jLogger = Logger.getLogger(UdpUtil.class);

    /**
     *  Send the UDP message definition.
     * @param oInetAddressHost the UDP server IP
     * @param iPort the UDP server port number
     * @param szApplication the application name
     * @param szColumnNames the column names
     * @param szWidths the column width
     */
    public static void sendDefinition(final InetAddress oInetAddressHost,
                                      final int iPort,
                                      final String szApplication,
                                      final String szColumnNames,
                                      final String szWidths) {
        Thread oThread = new Thread(new Runnable() {

            public void run() {
                DatagramSocket oDatagramSocket = null;
                try {
                    String szMessage = (new StringBuilder()).
                        append("app=").append(szApplication).append("&").
                        append("action=").append("define").append("&").
                        append("headings=").append(szColumnNames).append("&").
                        append("widths=").append(szWidths).append("&").toString();
                    byte abMessage[] = szMessage.getBytes();
                    int iLength = szMessage.length();
                    DatagramPacket oDatagramPacket = new DatagramPacket(abMessage, iLength, oInetAddressHost, iPort);
                    oDatagramSocket = new DatagramSocket();
                    oDatagramSocket.send(oDatagramPacket);
                }
                catch (IOException e) {
                    log4jLogger.error("Unable to send UDP message definition", e);
                    if (oDatagramSocket != null) {
                        oDatagramSocket.close();
                    }
                }
            }
        });
        oThread.start();
    }

    /**
     * Send UDP message.
     *
     * @param oInetAddressHost the UDP server IP
     * @param iPort            the UDP server port
     * @param szId             the UDP message Id
     * @param szAction         the action type
     * @param szMsg            the notes for message.
     */
    public static void sendData(final InetAddress oInetAddressHost,
                                final int iPort,
                                final String szApplication,
                                final String szId,
                                final String szAction,
                                final String szMsg) {
        Thread oThread = new Thread(new Runnable() {

            public void run() {
                DatagramSocket oDatagramSocket = null;
                try {
                    String szMessage = (new StringBuilder()).append("app=").append(szApplication).append("&").
                        append("id=").append(szId).append("&").
                        append("action=").append(szAction).append("&").
                        append("msg=").append(szMsg).append("&").toString();

                    byte abMessage[] = szMessage.getBytes();
                    int iLength = szMessage.length();
                    DatagramPacket oDatagramPacket = new DatagramPacket(abMessage, iLength, oInetAddressHost, iPort);
                    oDatagramSocket = new DatagramSocket();
                    oDatagramSocket.send(oDatagramPacket);
                }
                catch (IOException e) {
                    if (oDatagramSocket != null)
                        oDatagramSocket.close();
                }
                if (oDatagramSocket != null)
                    oDatagramSocket.close();
                if (oDatagramSocket != null)
                    oDatagramSocket.close();
            }
        });
        oThread.start();
    }

    /**
     * Get the server IP address.
     *
     * @param szIPAddress the String value of IP address
     * @return the server IP address
     */
    public static InetAddress getIPAddress(String szIPAddress) {

        InetAddress oIPAddress = null;
        if (szIPAddress != null) {
            try {
                oIPAddress = InetAddress.getByName(szIPAddress);
            }
            catch (UnknownHostException e) {
                log4jLogger.error("Unable to get host name for IP: " + szIPAddress);
            }
        }
        return oIPAddress;
    }
}
