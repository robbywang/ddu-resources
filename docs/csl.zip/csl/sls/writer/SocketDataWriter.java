package com.nortel.cdma.service.csl.sls.writer;

// GSF
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.common.alarm.interfaces.AlarmDefinition;
import com.nortel.cdma.common.internationalization.CemsAlarmTextMessageCategory;
import com.nortel.cdma.common.internationalization.ProbableCauseMessageCategory;
import com.nortel.cdma.common.internationalization.CallSummaryLogMessageCategory;
import com.nortel.cdma.service.common.util.AlarmUtil;
import com.nortel.cdma.service.csl.common.CSLUtil;

// java
import java.io.IOException;

import java.nio.channels.SocketChannel;
import java.nio.channels.WritableByteChannel;

import java.net.InetSocketAddress;
import java.net.Socket;

import java.nio.ByteBuffer;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Properties;
import java.util.Date;

import org.apache.log4j.Logger;

/**
 * This class writes stream log records to the socket channel.
 */
public class SocketDataWriter {

    /**
     * Instance of Log4j Logger.
     */
    private static final Logger log4jDebugLogger =
        Logger.getLogger(com.nortel.cdma.service.csl.sls.writer.SocketDataWriter.class);

    /**
     * Destination host IP address.
     */
    private String mDestinationAddress;

    /**
     * Remote port to write to.
     */
    private int mOutPort;

    /**
     * Flag indicating if an alarm has been raised. A null indicates that
     * the information is not available.
     */
    private volatile boolean mAlarmHasBeenRaised = false;

    /**
     * Socket channel connecting to the remote server.
     */
    private SocketChannel mSocketChannel = null;

    /**
     * The underlying socket connecting to the remote server.
     */
    private Socket mSocket = null;

    /**
     * Retry interval for connecting to the remote server.
     */
    private int mConnectRetryInterval;

    /**
     * Timeout in milliseconds for connecting to the follow-up PlugIn.
     */
    private int mConnectTimeout;

    /**
     * Number of retries connecting to the follow-up PlugIn before raising an alarm.
     */
    private int mConnectRetryAlarmThreshold;

    /**
     * set to true when Socket Data Writer is started.
     */
    private boolean mIsStarted = false;

    /**
     * Set to true when Socket Data Writer is requested to shut down.
     */
    private volatile boolean mIsShuttingDown = false;

    /**
     * Set to true when connection to the follow-up PlugIn is down, used to monitor
     * the connection.
     */
    private volatile boolean mIsConnectionDown = true;

    /**
     *  Timer used to check the connection.
     */
    private Timer moCheckConnectionTimer;

    /**
     * Fake CAS IP address which indicates that custom archived server is not deployed..
     */
    private final String DUMMY_CAS_IP = "0.0.0.1";

    /**
     * Delay (in ms) between successive log messages indicating IO error on write.
     */
    private static final int IOERROR_DEBOUNCE_DELAY = 60000;

    /**
     *  Timestamp for IO error message debounce.
     */
    private long mlIOErrorTimestamp = 0L;


    /**
     * The Instance of GenericStreamWriter.
     */
    private GenericStreamWriter moGenericStreamWriter;

    /**
     * Constructor.
     *
     * @param oWriter  The GenericStreamWriter instance which will be used for callback.
     */
    public SocketDataWriter(GenericStreamWriter oWriter) {

        if (oWriter == null) {
            log4jDebugLogger.error("Cannot construct SocketDataWriter");
            return;
        }

        moGenericStreamWriter = oWriter;

        Properties oConfigParms = moGenericStreamWriter.getParsedProperties();

        mDestinationAddress = oConfigParms.getProperty("ipaddress");

        mOutPort = Integer.parseInt( oConfigParms.getProperty("outport") );

        mConnectRetryInterval = Integer.parseInt( oConfigParms.getProperty("connectretryinterval") );

        mConnectTimeout = Integer.parseInt( oConfigParms.getProperty("connecttimeout") );

        mConnectRetryAlarmThreshold = Integer.parseInt( oConfigParms.getProperty("connectretryalarmthreshold") );

        moCheckConnectionTimer = new Timer();
    }

    /**
     * Starts up socket data writer.
     *
     * @throws com.nortel.cdma.gsf.InitializationFailureException if there is problem starting up
     */
    public synchronized void startup() throws InitializationFailureException {
        if (mIsStarted) {
            log4jDebugLogger.info("Already started, canceling startup request.");

            return;
        }

        connect();

        monitorConnection();

        mIsStarted = true;

        log4jDebugLogger.info("startup completed!");
    }

    /**
     * Shuts down the socket data writer.
     */
    public synchronized void shutdown() {
        if (!mIsStarted) {
            log4jDebugLogger.info("Already down, canceling the shutdown request");

            return;
        }

        mIsShuttingDown = true;

        moCheckConnectionTimer.cancel();

        closeSocket();

        mIsConnectionDown = true;

        mIsStarted = false;

        mIsShuttingDown = false;

        log4jDebugLogger.info("shutdown completed!\n");
    }

    /**
     * Restart the socket data writer.
     */
    public void restart() {
        reconnect();
    }

    /**
     * Connects to the remote socket server and raises an alarm after failing a predefined
     * number of tries.
     *
     */
    public void connect() {
        int     numRetries = 0;

        while(! mIsShuttingDown) {
            boolean operationSucceeded = false;

            try {
                if ((mDestinationAddress.equalsIgnoreCase(DUMMY_CAS_IP))) {
                    //CSL is not enabled. Clear outstanding alarm if any
                    moGenericStreamWriter.setConnectionStatus(GenericStreamWriter.NO_CAS_DEPLOYED);
                    raiseOrClearAlarm(false);
                    return;
                }
                mSocketChannel = SocketChannel.open();
                mSocket = mSocketChannel.socket();

                InetSocketAddress remoteAddress =
                    new InetSocketAddress(mDestinationAddress, mOutPort);

                mSocket.connect(remoteAddress, mConnectTimeout);

                // Disables Nagle's algorithm which buffers small packets
                // to improve performance
                mSocket.setTcpNoDelay(true);

                mSocketChannel.configureBlocking(false);

                operationSucceeded = true;
            }
            catch(IOException e) {
                log4jDebugLogger.error("Met I/O error trying to connect to " + mDestinationAddress + "/" + mOutPort
                    + ". Retry after some delay.", e);
            }
            finally {
                if(! operationSucceeded) {
                    closeSocket();
                }
            }

            if (operationSucceeded) {
                mIsConnectionDown = false;
                moGenericStreamWriter.setConnectionStatus(GenericStreamWriter.CAS_CONNECTTED);
                break;
            }

            numRetries++;

            if (numRetries > mConnectRetryAlarmThreshold) {
                if (log4jDebugLogger.isInfoEnabled()) {
                    log4jDebugLogger.info("Failed number of tries = "
                        + numRetries + "(>" + mConnectRetryAlarmThreshold + "), "
                        + "Raise alarm.");
                }

                raiseOrClearAlarm(true);
                moGenericStreamWriter.setConnectionStatus(GenericStreamWriter.CAS_CONNECTION_LOST);
                break;
            }

            // Perform predefine delay and try again.
            performDelay(mConnectRetryInterval);
        }

        if(mIsConnectionDown) {
            // No connection made, must be shutdown time.
            // Do nothing.
        }
        else {

            Date now = new Date(System.currentTimeMillis());

            //create journal log
            CSLUtil.createJournalLog(CallSummaryLogMessageCategory.CAS_CONNECTION_ESTABLISHED,
                new String [] {mDestinationAddress, String.valueOf(mOutPort), now.toString()});

            now = new Date(System.currentTimeMillis());

            if (log4jDebugLogger.isDebugEnabled()) {
                log4jDebugLogger.debug("Connection to Archive Server (" + mDestinationAddress +
                    ", " + mOutPort + ") established at " + now);
            }
            raiseOrClearAlarm(false);
        }
    }

    /**
     * Thread function that monitors the connection to remote socket server.
     */
    private void monitorConnection() {

        moCheckConnectionTimer = new Timer();
        try {
            moCheckConnectionTimer.scheduleAtFixedRate(new TimerTask() {
                public void run() {

                    if (!mIsShuttingDown) {
                        if (mIsConnectionDown) {
                            log4jDebugLogger.error("connection to " +  mDestinationAddress + "/" + mOutPort + " is down, try to "
                                + "reconnect in " + mConnectRetryInterval + " milliseconds.");

                            closeSocket();

                            performDelay(mConnectRetryInterval);

                            connect();
                        }
                        else {
                            detectCASConnection();
                        }
                    }

                }
            },0, 30000);
        }
        catch (IllegalStateException  ex) {
            log4jDebugLogger.error("Cannot schedule a timer task", ex);
        }
    }

    /**
     * Thread function that monitors the connection to remote socket server.
     */
    private void detectCASConnection () {

        SocketChannel oSocketChannel = null;

        Socket oSocket = null;

        if (!mIsShuttingDown) {
            if ((mDestinationAddress == null) || (mOutPort == 0)) {
                return;
            }

            if ((mDestinationAddress.equalsIgnoreCase(DUMMY_CAS_IP))) {
                //CSL is not enabled. Clear outstanding alarm if any
                raiseOrClearAlarm(false);
                return;
            }

            Exception exc = null;
            boolean bConnected = false;
            try {
                oSocketChannel = SocketChannel.open();
                oSocket = oSocketChannel.socket();

                InetSocketAddress remoteAddress =
                    new InetSocketAddress(mDestinationAddress, mOutPort);

                oSocket.connect(remoteAddress, 10000);
                bConnected = true;
            }
            catch (IOException ioe) {
                exc = ioe;
            }
            catch (IllegalArgumentException ile) {
                exc = ile;
            }
            finally {

                if (!bConnected) {
                    mIsConnectionDown = true;
                    raiseOrClearAlarm(true);
                }

                if (exc != null) {
                    log4jDebugLogger.error("Exception happened when monitor the connection to cas", exc);
                }

                // Close the current socket since we only detect if the connection can be setup
                // successfully, rather than transferring data.
                if ( oSocketChannel != null){
                    try {
                        oSocketChannel.close();
                    }
                    catch (IOException e) {
                        log4jDebugLogger.error("unable to close socket channel on " + mDestinationAddress);
                    }
                }
                try {
                    if (oSocket != null) {
                        oSocket.close();
                    }
                }
                catch (IOException e) {
                    log4jDebugLogger.error("unable to close socket connection to " + mDestinationAddress);
                }
            }
        }
    }


    /**
     * Raises or clears an alarm when connection to CAS is closed or reopened.
     *
     * @param isRaise If true indicates a raise, otherwise a clear
     */
    protected void raiseOrClearAlarm(boolean isRaise) {

        // If the alarm flag is null, raise or clear the alarm
        if (isRaise == mAlarmHasBeenRaised) {
            // Nothing to do - the alarm has already been raised/cleared
            return;
        }

        String debugMsg = isRaise ? "Raise_Alarm" : "Clear_Alarm";
        log4jDebugLogger.warn(debugMsg);

        int  alarmType  = AlarmDefinition.EVENT_TYPE_COMMUNICATIONS;

        int  severity   = AlarmDefinition.SEVERITY_MINOR;

        int  messageKey =
            CemsAlarmTextMessageCategory.CEMS_CSLProfile_1_0;

        int  probableCause =
            ProbableCauseMessageCategory.COMM_SUBSYSTEM_FAIL;

        Object[]  args       = null;

        AlarmUtil alarmUtil = AlarmUtil.getInstance();
        if (alarmUtil.raiseOrClearAlarmOnCSLProfileME(isRaise, alarmType, severity,
            messageKey, probableCause, args)) {
            mAlarmHasBeenRaised = isRaise;
        }
        else {
            log4jDebugLogger.error("Unable to " + debugMsg + " for connection to CAS");
        }
    }

    /**
     * Re-established the connection.
     */
    private void reconnect() {
        mIsConnectionDown = true;
    }

    /**
     * Performs the specified delay.
     *
     * @param delay  The delay in milliseconds
     */
    private void performDelay(int delay) {
        try {
            Thread.sleep(delay);
        }
        catch(InterruptedException e) {
            // Ignore
        }
    }

    /**
     * Closes the socket connection.
     */
    private synchronized void closeSocket() {
        if (mSocket != null) {
            try {
                mSocket.close();
            }
            catch(IOException e) {
                log4jDebugLogger.error("Failed to close socket.", e);
            }
        }

        mSocket = null;

        if (mSocketChannel != null) {
            try {
                mSocketChannel.close();
            }
            catch(IOException e) {
                log4jDebugLogger.error("Failed to close socket channel.", e);
            }
        }

        mSocketChannel = null;
    }

    /**
     * Writes log data to the stream log server.
     * @param buf the buffer to write to the stream log server
     * @return true is write is a success; false otherwise
     */
    public synchronized boolean writeByteBuffer(ByteBuffer buf) {
        boolean bResult = false;
        try {
            if ( mSocketChannel == null ) {
                log4jDebugLogger.error("Got null SocketChannel");
            }
            else {
                write(mSocketChannel, buf);
                bResult = true;
            }
        }
        catch(Throwable e) {
            moGenericStreamWriter.setConnectionStatus(GenericStreamWriter.CAS_CONNECTION_LOST);
            mIsConnectionDown = true;
            long lCurrentTime = System.currentTimeMillis();

            if ((lCurrentTime - mlIOErrorTimestamp) > IOERROR_DEBOUNCE_DELAY) {
                log4jDebugLogger.error("Error writing log record to the Archive Server, connection may be closed."
                    + "Attempting to reconnect.", e);
                mlIOErrorTimestamp = lCurrentTime;
            }

            closeSocket();
            connect();
        }
        return bResult;
    }

    /**
     * Relatively writes a buffer.remaining() number of bytes from buffer into the channel.
     *
     * @return message contents
     *
     * @throws IOException if there is an I/O error reading from the channel
     *
     */
    public static final ByteBuffer write( WritableByteChannel channel,
                                          ByteBuffer buffer ) throws IOException {
        boolean yieldFlag = false;
        while( buffer.remaining() > 0 ) {
            if( yieldFlag ) {
                Thread.yield();
            } else {
                yieldFlag = true;
            }
            channel.write( buffer );
        }
        return buffer;
    }

    /**
     * Remote socket server IP address setter.
     * @param szIpAdd the remote socket server IP address
     */
    public void setDestinationAddress(String szIpAdd) {
        mDestinationAddress = szIpAdd;
    }

    /**
     * Remote socket server port setter.
     * @param iPort the remote socket server port id.
     */
    public void setPortId (int iPort) {
        mOutPort = iPort;
    }
}
