package com.nortel.cdma.service.csl.sls.writer.lbhpasw;

import com.nortel.cdma.service.csl.sls.writer.bhpasw.BufferedHighPerformanceStreamWriter;

/**
 * This class describes a stream writer that collects stream
 * log records from previous plugin instance and write to socket channel.
 */
public class LeafBufferedHighPerformanceStreamWriter extends BufferedHighPerformanceStreamWriter {


    /**
     * The IStreamReceiver interface implementation that handles the stream.
     * @param abInputBuffer the byte array to be handled
     * @param iOffset the offset in the byte array of the data to be handled
     * @param iLength the length of the byte array to be handled
     */
    public void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {

        switch (miCAS_Connect_Status) {
            case CAS_CONNECTTED:
                fillBuffer(abInputBuffer, iOffset, iLength);
                break;

            case CAS_CONNECTION_LOST:
                synchronized (lock) {
                    mNumLogsLost += iLength;
                }
                break;
            default:
                break;
        }
    }
}
