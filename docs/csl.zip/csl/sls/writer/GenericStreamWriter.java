/*
* Copyright (c) 2008 Nortel Networks, Inc. All Rights Reserved.
*/

package com.nortel.cdma.service.csl.sls.writer;

import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.service.csl.common.ExternalServerConfig;

import org.apache.log4j.Logger;

/**
 * This class describes a generic stream writer which describes how to write data to the Customer Archive Server.
 */
public class GenericStreamWriter extends Writer {

    /**
     *  Instance of debug logger.
     */
    private static final Logger log4jDebugLogger = Logger.getLogger(GenericStreamWriter.class);

    /**
     * Connection status to Customer Archive Server.
     */
    protected int miCAS_Connect_Status;

    /**
     * Connection status: No Customer Archive Server. deployed.
     */
    public final static int NO_CAS_DEPLOYED = 0;

    /**
     * Connection to Customer Archive Server established.
     *
     */
    public final static int CAS_CONNECTTED = 1;

      /**
     * Lost connection to Customer Archive Server.
     *
     */
    public final  static int CAS_CONNECTION_LOST = 2;

    /**
     *  Default constructor for the GenericStreamWriter.
     */
    public GenericStreamWriter() {
    }

    /**
     * Retrieve the external server configuration (IPAddress and port Id). By default, those info
     * will be fetched from the database but it can be overwritten by reading those info from config file.
     */
    protected void getArchiveServerConfig () {

        ExternalServerConfig oCASConfig = CSLUtil.getExternalServerConfig();

        if (oCASConfig != null) {
            if (oCASConfig.isValid()) {
                String tmpCasIP = oCASConfig.getExternalServerIPAddress();
                if (tmpCasIP != null) {
                    mszSocketDestination = tmpCasIP;
                }

                short tmpPortId =  oCASConfig.getExternalServerPortId();

                if (tmpPortId != -1) {
                    miPort = tmpPortId;
                }
            }
        }
    }

    /**
     * The IStreamReceiver interface implementation that handles the stream and write to buffer.
     * @param abInputBuffer the byte array to be handled
     * @param iOffset the offset in the byte array of the data to be handled
     * @param iLength the length of the byte array to be handled
     */
    public void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {
    }

    /**
     * If there are some changes in CEMS DB regarding ExternalServerConfig attribute
     * group, then retrieves the updated CAS host name and port info and restart the
     * socket connection.
     * @param szIPAddress the IP address from  ExternalServerConfig attribute group
     * @param portId the port Id from  ExternalServerConfig attribute group
     */
    public synchronized void handleExternalServerConfigAttGrpUpdate(String szIPAddress, short portId)  {

        boolean bIsUpdated = false;
        if ((szIPAddress != null) && (!szIPAddress.equalsIgnoreCase(mszSocketDestination))){
            //update the cached values only if it is changed.
            mszSocketDestination = szIPAddress;
            log4jDebugLogger.debug("Got updated ServerHostName = " + mszSocketDestination);
            bIsUpdated = true;
        }

        if ((portId != -1) && (portId != miPort)){
            //update the cached values only if it is changed.
            miPort = portId;
            log4jDebugLogger.debug("Got updated  DestinationPort = " + miPort);
            bIsUpdated = true;
        }

        //restart the connection if there is update
        if (bIsUpdated) {
            restartSocketConnection();
        }
    }

    /**
     *  Close the current open socket if any and restart socket connection.
     */
    protected synchronized void restartSocketConnection () {

    }

    /**
     *  Close the current open socket if any and restart socket connection.
     */
    protected synchronized void setConnectionStatus (int iStatus) {
       miCAS_Connect_Status = iStatus;
    }
}