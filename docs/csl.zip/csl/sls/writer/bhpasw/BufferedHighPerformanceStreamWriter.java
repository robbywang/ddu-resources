package com.nortel.cdma.service.csl.sls.writer.bhpasw;

import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Date;
import java.nio.ByteBuffer;
import java.net.InetAddress;
import java.text.SimpleDateFormat;

import org.apache.log4j.Logger;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;

import com.nortel.cdma.service.csl.sls.writer.GenericStreamWriter;
import com.nortel.cdma.service.csl.sls.writer.SocketDataWriter;
import com.nortel.cdma.service.csl.sls.writer.udpwriter.UdpWriter;
import com.nortel.cdma.service.csl.sls.writer.udpwriter.UdpUtil;
import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;
import com.nortel.cdma.service.common.util.ScheduleSafeTimer;

/**
 * This class describes a stream writer that collects stream
 * log records from socket channel and sends them
 * to the follow-up PlugIn.
 */
public class BufferedHighPerformanceStreamWriter extends GenericStreamWriter {

    /**
     *  The minimum value of the buffer position.
     */
    private int miPositionMin = Integer.MAX_VALUE;

    /**
     *  The maximum value of the buffer position.
     */
    private int miPositionMax = Integer.MIN_VALUE;

    /**
     * Instance of Log4j Logger.
     */
    private static final Logger log4jDebugLogger =
        Logger.getLogger(BufferedHighPerformanceStreamWriter.class);

    /**
     * The writer used to write log records to the socket.
     */
    private SocketDataWriter mSocketDataWriter = null;

    /**
     * Initialization status.
     */
    private boolean mIsStarted = false;

    /**
     * Flag to indicate whether shutting down is in progress.
     */
    private boolean mIsShuttingDown = false;

    /**
     * The instance of server properties.
     */
    private Properties moProperties;

    /**
     * The ByteBuffer for read and write.
     */
    protected ByteBuffer moByteBuffer;

    /**
     * The state for filling ByteBuffer.
     */
    protected final int mkiFill = 0;

    /**
     * The state of draining ByteBuffer.
     */
    protected final int mkiDrain = 1;

    /**
     * The state for  ByteBuffer activities. Initailly it is "drain" state.
     */
    protected int miState = mkiDrain;

    /**
     * The ByteBuffer size in MB, which is defined in user specified properties.
     */
    private int miBuffersize = 10;

    /**
     * The miDrainSleepTime in millisecond, which is defined in user specified properties.
     */
    private int miDrainSleepTime = 10;


    /**
     * The IP address for UDP message server.
     */
    private InetAddress moIpAddUdp;

    /**
     * Flag whether to send UDP message or not.
     */
    private boolean mbSendUdp = false;

    /**
     * The Timer to check buffer size.
     */
    private Timer moCheckBufferTimer;

    /**
     * The packet number in the UDP message.
     */
    private int miPacketNumber;

    /**
     * Timer to periodically generate statistics lost logs.
     */
    private Timer mShowStatsTimer;

    /**
     * Total number of lost log records
     */
    protected volatile long mTotalLogsLost = 0L;

    /**
     * Number of lost log records
     */
    protected static volatile long mNumLogsLost = 0L;

    /**
     * The tag for buffer size in properties.
     */
    private static final String TAG_BUFFER_SIZE = "buffersize";

    /**
     * The tag for drainbuffersleeptime (in millisecond) in properties.
     */
    private static final String TAG_DRAIN_BUFFER_SLEEP_TIME = "drainbuffersleeptime";

    /**
     * The tag for UDP enable flag.
     */
    private static final String TAG_UDP_ENABLED = "udpenabled";

    /**
     * The tag for UDP server IP in properties.
     */
    private static final String TAG_UDP_SERVER_IP = "udpipaddress";

    /**
     * The tag for UDP server port in properties.
     */
    private static final String TAG_UDP_SERVER_PORT = "udpport";

    /**
     * The tag for remote socket server ip.
     */

    private static final String TAG_SOCKET_SERVER_IP = "ipaddress";

    /**
     * The tag for socket server port in properties.
     */
    private static final String TAG_SOCKET_SERVER_PORT = "outport";

    /**
     * The UDP Server IP Address.
     */
    private String mszUDPIPAddress = "127.0.0.1";

    /**
     * Formatting string to configure date formatter.
     */
    private static String mszDateFormatterString = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * Date formatter object.
     */
    private static SimpleDateFormat mDateFormatter = new SimpleDateFormat(mszDateFormatterString);

    /**
     * Header info for  byte lost report.
     */
    private static final String HEADER_BYTE_LOST_REPORT = "CSLINFO.HEAD.HPASW, Report Time, Byte Dropped; Total Byte Dropped";

    /**
     * Data info for  byte lost report.
     */
    private static final String DATA_BYTE_LOST_REPORT = "CSLINFO.DATA.HPASW";


    /**
     * The UDP Server Port.
     */
    private int miUDPPort = 2500;

    /**
     * The flag indicates if UDP messaging is turned on.
     */
    private boolean mbUdpEnable = false;

    /**
     * lock object to synchronize lost logs calculation.
     */
    protected static Object lock = new Object();

    /**
     * Boolean flag indicates if Buffer full error message has been reported.
     */
    protected boolean mbErrMsgRaised = false;

    /**
     * Constructor.
     */
    public BufferedHighPerformanceStreamWriter() {
    }

    /**
     * Configures the BufferedHighPerformanceStreamWriter.
     *
     * @param  oPropertiesParm  The properties containing the StreamWriter
     *                     configuration information
     */
    public void config(Properties oPropertiesParm) {
        super.config( oPropertiesParm );

        moProperties = getParsedProperties();

        String szBufferSize = moProperties.getProperty(TAG_BUFFER_SIZE);

        try {
            miBuffersize = Integer.valueOf(szBufferSize);
        }
        catch (NumberFormatException e) {
            log4jDebugLogger.debug("Invalid buffer size : " + szBufferSize);
        }

        byte[] abBuffer = new byte[miBuffersize * 1024 * 1024 ];
        moByteBuffer = ByteBuffer.wrap( abBuffer );

        getArchiveServerConfig();

        //update remote socket server ip and port based on database values.
        if (mszSocketDestination != null) {
            moPropertiesParsed.setProperty(TAG_SOCKET_SERVER_IP, mszSocketDestination);
            moPropertiesParsed.setProperty(TAG_SOCKET_SERVER_PORT, String.valueOf(miPort));
        }
        

        String szSleeptime = moProperties.getProperty(TAG_DRAIN_BUFFER_SLEEP_TIME);

        try {
            miDrainSleepTime = Integer.valueOf(szSleeptime);
        }
        catch (NumberFormatException e) {
            log4jDebugLogger.debug("Invalid buffer size : " + szBufferSize + ". Use the default one instead");
        }

        String szUDPEnabled = moProperties.getProperty(TAG_UDP_ENABLED);

        if (szUDPEnabled == null) {
            //udp info is not mandatory.
            return;
        }

        mbUdpEnable = Boolean.valueOf(szUDPEnabled);

        String szUdpIpAddress = moProperties.getProperty(TAG_UDP_SERVER_IP);

        if (szUdpIpAddress != null) {
            mszUDPIPAddress = szUdpIpAddress;
        }

        String szUdpPort = moProperties.getProperty(TAG_UDP_SERVER_PORT);

        if (szUdpPort != null) {
            try {
                miUDPPort = Integer.valueOf(szUdpPort);
            }
            catch (NumberFormatException e) {
                log4jDebugLogger.debug("Invalid udp port : " + szUdpPort);
            }
        }
    }


    /**
     * Starts up the BufferedHighPerformanceStreamWriter.
     *
     * @throws com.nortel.cdma.gsf.InitializationFailureException upon initialization failure
     * @throws com.nortel.cdma.gsf.InvalidDeploymentException upon invalid deployment
     */
    public void startup() throws InitializationFailureException, InvalidDeploymentException {
        if (mIsStarted) {
            log4jDebugLogger.debug("Already started.");

            throw new InitializationFailureException("StreamWriter ",
                "StreamWriter is already started.");
        }


        initSocketDataWriter();

        drainBuffer();

        startLogLostSummary();

        if (mbUdpEnable) {

            monitorBufferSize();

            moIpAddUdp = UdpUtil.getIPAddress(mszUDPIPAddress);

            UdpUtil.sendDefinition(moIpAddUdp,
                miUDPPort,
                "HPASW",
                "Packet#,Min,Max,Position",
                "");
        }
        mIsStarted = true;
    }

    /**
     *   Initialize BufferedHighPerformanceStreamWriter.
     */
    private void initSocketDataWriter()  {

        mSocketDataWriter = new SocketDataWriter(this);

        Thread oThreadSocketDataWriter = new Thread( new Runnable()  {

            public void run() {

                try {
                    mSocketDataWriter.startup();
                }
                catch (InitializationFailureException e) {
                    log4jDebugLogger.error("Unable to start SocketDataWriter:" + e);
                }
            }
        });

        oThreadSocketDataWriter.setName( "initSocketDataWriter") ;
        oThreadSocketDataWriter.start();
    }

    /**
     * Thread function that drains data from  byte buffer.
     */
    protected void drainBuffer() {
        Thread oThreadDrainBuffer = new Thread( new Runnable()  {

            public void run() {

                while ( ! mIsShuttingDown ) {
                    if ( miState == mkiFill ) {
                        if (miCAS_Connect_Status == CAS_CONNECTTED)  {
                            synchronized( moByteBuffer ) {
                                moByteBuffer.flip();
                                miState = mkiDrain;

                                boolean bHasRemaining = moByteBuffer.hasRemaining();

                                if (bHasRemaining) {
                                    if (!mSocketDataWriter.writeByteBuffer(moByteBuffer)) {
                                        synchronized (lock) {
                                            mNumLogsLost += moByteBuffer.limit();
                                        }
                                    }
                                    moByteBuffer.clear();
                                }
                            }
                        }
                    }
                    else {
                        try {
                            Thread.sleep(miDrainSleepTime);
                        }
                        catch (InterruptedException e) {
                        }
                    }
                }
            }
            //To change body of implemented methods use File | Settings | File Templates.
        });

        oThreadDrainBuffer.setName( "drainBuffer") ;
        oThreadDrainBuffer.start();

    }

    /**
     * Thread function that monitors the buffer usage and send to udp server.
     */
    private void monitorBufferSize() {

        moCheckBufferTimer = new ScheduleSafeTimer();
        try {
            moCheckBufferTimer.scheduleAtFixedRate(new TimerTask() {
                public void run() {
                    mbSendUdp = true;

                }
            },0, 10000);
        }
        catch (IllegalStateException  ex) {
            log4jDebugLogger.error("Cannot schedule a timer task", ex);
        }
    }

    /**
     *  Restart socket connection to cas due to the cas IP and/or Port changes.
     */
    protected void restartSocketConnection() {
        if (mSocketDataWriter != null) {
            mSocketDataWriter.setDestinationAddress(mszSocketDestination);
            mSocketDataWriter.setPortId(miPort);
            mSocketDataWriter.restart();
        }
    }

    /**
     * Shuts down the BufferedHighPerformanceStreamWriter.
     */
    public void shutdown() {
        if (!mIsStarted) {
            log4jDebugLogger.debug("Already shutdown, canceling shutdown request.");

            return;
        }

        if (mIsShuttingDown) {
            log4jDebugLogger.debug("Shutdown is in progress, reject another "
                + "shutdown request.");

            return;
        }

        mIsShuttingDown  = true;

        moCheckBufferTimer.cancel();

        if(mSocketDataWriter != null) {
            mSocketDataWriter.shutdown();
        }

        mIsStarted = false;

        mIsShuttingDown  = false;
    }

    /**
     * The IStreamReceiver interface implementation that handles the stream.
     * @param abInputBuffer the byte array to be handled
     * @param iOffset the offset in the byte array of the data to be handled
     * @param iLength the length of the byte array to be handled
     */
    public void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {

        switch (miCAS_Connect_Status) {
            case CAS_CONNECTTED:
                fillBuffer(abInputBuffer, iOffset, iLength);
                break;

            case CAS_CONNECTION_LOST:
                synchronized (lock) {
                    mNumLogsLost += iLength;
                }
                break;

            default:
                break;
        }

        for ( IStreamReceiver oIStreamReceiver : moHashSetStreamReceivers ) {
            oIStreamReceiver.handleStream(abInputBuffer, iOffset, iLength);
        }
    }

    /**
     * Thread function that fills data to byte buffer.
     */
    protected void fillBuffer(byte[] abInputBuffer, int iOffset, int iLength) {

        int iPosition;

        synchronized( moByteBuffer ) {
            int iLimit = moByteBuffer.limit();
            int iCapacity = moByteBuffer.capacity();
            iPosition = moByteBuffer.position();

            if ( miState == mkiDrain ) {
                miState = mkiFill;
            }

            if ( iCapacity > iPosition + iLength ) {
                moByteBuffer.put(abInputBuffer, 0, iLength);
                if (mbErrMsgRaised) {
                    Date now = new Date(System.currentTimeMillis());
                    log4jDebugLogger.warn("Byte buffer is recovered at "  + now + ".");
                    mbErrMsgRaised = false;
                }
            }
            else {
                moByteBuffer.clear();
                synchronized (lock) {
                    mNumLogsLost += iLimit + iLength;
                }

                if (!mbErrMsgRaised) {
                    Date now = new Date(System.currentTimeMillis());
                    log4jDebugLogger.warn("Byte buffer is nearly full at "  + now + ". Start to drop data in the buffer");
                    mbErrMsgRaised = true;
                }
            }
        }

        if (mbUdpEnable) {
            if ( iPosition < miPositionMin ) {
                miPositionMin = iPosition;
            }

            if ( iPosition > miPositionMax ) {
                miPositionMax = iPosition;
            }

            if (mbSendUdp) {
                mbSendUdp = false;

                String szMessage = miPacketNumber++ + "," + miPositionMin + "," + miPositionMax + "," + iPosition;

                UdpUtil.sendData(moIpAddUdp, 2500, "HPASW", "Big Buffer", "update", szMessage );
            }
        }
    }

    /**
     * starts the timer to send lost record statistics every 5 minutes.
     */
    private void startLogLostSummary(){

        mShowStatsTimer = new ScheduleSafeTimer();

        long  period = 5*60*1000L;  // 5 minutes in milliseconds

        long  currentTime = System.currentTimeMillis();

        long  delay = period - currentTime%period;  // milliseconds till next half hour

        mShowStatsTimer.scheduleAtFixedRate(new TimerTask() {
            public void run() {
                sendLostRecordSummary();
            }
        }, delay, period);
    }



    /**
     * Report lost record statistics into debug logs.
     */
    private void sendLostRecordSummary(){
        synchronized (lock) {
            mTotalLogsLost += mNumLogsLost;
            if (mNumLogsLost != 0) {
                //only write info to log file once there was data lost
                Date now = new Date(System.currentTimeMillis());
                String szTimeStamp = mDateFormatter.format(now);

                log4jDebugLogger.warn(HEADER_BYTE_LOST_REPORT + "\n"
                    + DATA_BYTE_LOST_REPORT + ","
                    + szTimeStamp + ","
                    + mNumLogsLost +", "
                    + mTotalLogsLost + "\n");

                mNumLogsLost = 0;
            }
        }
    }

    /**
     * Main  class for design testing only.
     * @param aszArgs
     */

    public static void main(String[] aszArgs) {

        int iNumLoops = 10;

        int iSleepTime = 30;

        for ( int i = 0 ; i < aszArgs.length ; ++i ) {
            switch ( i ) {
                case 0:
                    try {
                        iNumLoops = Integer.parseInt( aszArgs[i] );
                    }
                    catch (NumberFormatException e) {
                        iNumLoops = 10;
                    }
                    break;

                case 1:
                    try {
                        iSleepTime = Integer.parseInt( aszArgs[i] );
                    }
                    catch (NumberFormatException e) {
                        iSleepTime = 30;
                    }
                    break;
                default:
                    break;
            }
        }

        try {
            UdpWriter oUdpWriter = new UdpWriter();
            Properties oPropertiesUdp = new Properties();

            oPropertiesUdp.setProperty( PLUGIN_NAME, "UDP - SLS" );
            oPropertiesUdp.setProperty( CONFIG_FILE_PROPERTY, "/tmp/udpwriter.properties" );
            oPropertiesUdp.setProperty( XMLTAG_ENABLED, "true");

            oUdpWriter.config(oPropertiesUdp);
            oUdpWriter.startup();


            BufferedHighPerformanceStreamWriter oHighPerformanceStreamWriter = new BufferedHighPerformanceStreamWriter();
            Properties oProperties = new Properties();

            oProperties.setProperty( PLUGIN_NAME, "BHPASW" );
            oProperties.setProperty( CONFIG_FILE_PROPERTY, "/tmp/bhpasw.properties" );
            oProperties.setProperty(XMLTAG_ENABLED, "true");
//            oProperties.setProperty("ipaddress", "127.0.0.1");
//            oProperties.setProperty("outport", "5000");
//            oProperties.setProperty("connectretryinterval", "5000");
//            oProperties.setProperty("connecttimeout", "5000");
//            oProperties.setProperty("connectretryalarmthreshold", "5");

            oHighPerformanceStreamWriter.config(oProperties);
            oHighPerformanceStreamWriter.register(oUdpWriter);

            oHighPerformanceStreamWriter.startup();

            int iLength = 0x8000;
            byte[] abBig = new byte[iLength];
            abBig[0] = (byte) 0x80;
            abBig[1] = (byte) 0x00;

            for (int i=0; i< iNumLoops; i++) {
                oHighPerformanceStreamWriter.handleStream(abBig, 0, iLength);

                try {
                    Thread.sleep( iSleepTime );
                }
                catch (InterruptedException e) {
                }
            }
        }
        catch (InitializationFailureException e) {
            log4jDebugLogger.error(e);
        }
        catch (InvalidDeploymentException e) {
            log4jDebugLogger.error(e);
        }
    }
}
