/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */

package com.nortel.cdma.service.csl.sls.writer.syslog;

import com.nortel.cdma.service.csl.sls.writer.Writer;
import com.nortel.cdma.service.common.syslog.Syslog;
import com.nortel.cdma.service.common.syslog.SyslogException;
import com.nortel.cdma.service.common.syslog.SyslogConstants;

import java.util.Properties;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.apache.log4j.Logger;

/**
 * This class describes a DiskWriter which describes how to write data disk using the SectionRouter.
 */
public class SyslogWriter extends Writer implements SyslogConstants, SyslogWriterConstants {
  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(SyslogWriter.class);

  /**
   * Constant for the 'Raw' output format.
   */
  private final String mkszOutputFormatRaw = "raw";

  /**
   * Constant for the 'Decimal' output format.
   */
  private final String mkszOutputFormatDecimal = "decimal";

  /**
   * The default syslog Priority.
   */
  private int mkiDefaultSyslogPriority = LOG_INFO;

  /**
   * The default syslog Facility.
   */
  private final int mkiDefaultSyslogFacility = LOG_LOCAL0;

  /**
   * The default log name for syslog. Used during property parsing errors.
   */
  private final String mkszDefaultSyslogLogname = "CSL";

  /**
   * Constant value used to set the syslog server hostname if it is not set.
   */
  private final String mkszLocalHost = "127.0.0.1";

  /**
   * The Default syslog port for syslog daemons.
   */
  private final int mkiDefaultSyslogPort = 514;

  /**
   * The Streamhandler variable set when we know whether we are receiving
   * binary data or text.
   */
  private SyslogDataWriter moStreamHandler;

  /**
   * The reference to the syslog instance.
   */
  private Syslog moSyslog;

  /**
   * A property indicating that the input is binary vs text.
   */
  private boolean mbIsBinaryInput = false;

  /**
   * The hostname that the syslog daemon is running on.
   */
  private String mszSyslogServerHostname = mkszLocalHost;

  /**
   * The port that the syslog daemon is running on.
   */
  private int miSyslogServerPort = mkiDefaultSyslogPort;

  /**
   * The logname that each syslog record is tagged with.
   */
  private String mszSyslogLogname = mkszDefaultSyslogLogname;

  /**
   * A flag bitmask containing extra syslog options. Defaults to no options.
   */
  private int miSyslogFlags = 0;

  /**
   * The syslog Facility. Default is LOG_USER.
   */
  private int miSyslogFacility = mkiDefaultSyslogFacility;

  /**
   * The syslog Priority. Default is LOG_INFO.
   */
  private int miSyslogPriority = mkiDefaultSyslogFacility;

  /**
   * The output format. Default is hex.
   */
  private int miOutputFormat = mkiOutputHex;

  /**
   * A flag to indicate whether the hex prefix should be shown. Default is to not show the "0x" prefix.
   */
  private boolean mbShowHexPrefix = false;

  /**
   * The default constructor the SyslogWriter.
   */
  public SyslogWriter() {
    mszName = "SyslogWriter";
  }

  /**
   * Runs the plug-in specific startup code.
   */
  protected void localStartup() {
    readLocalProperties();

    moSyslog = initSyslog();

    initStreamHandler();
  }

  /**
   * Sets up the stream handler based on the user preferences read from the configuration file.
   */
  private void initStreamHandler() {

    if ( mbIsBinaryInput ) {
      moStreamHandler = new SyslogBinaryDataWriter(moSyslog, miOutputFormat, miSyslogFacility, miSyslogPriority, mbShowHexPrefix );
    }
    else {
      moStreamHandler = new SyslogAsciiDataWriter(moSyslog, miOutputFormat, miSyslogFacility, miSyslogPriority );
    }
  }

  /**
   * Helper method to initialize the syslog object.
   * @return reference to the syslog object
   */
  private Syslog initSyslog() {

//    <entry key="inputtype">binary</entry>
//
//    <entry key="syslog.serverhostname">fdifranc-3</entry>
//    <entry key="syslog.serverport">514</entry>
//    <entry key="syslog.logname">Fab</entry>
//    <entry key="syslog.flags">0x20</entry>
//    <entry key="syslog.facility">1</entry>
//    <entry key="syslog.priority">6</entry>

    Syslog oSyslog = null;

    try {
      oSyslog = new Syslog(mszSyslogServerHostname, miSyslogServerPort, mszSyslogLogname, miSyslogFlags);
    }
    catch (SyslogException e) {
      log4jDebugLogger.error(e.getMessage(), e);
    }

    return ( oSyslog );
  }

  /**
   * Reads the plug-in specific config file and sets the data members with the file contents.
   * @return the properties. Not required since all preference attributes are set in this method
   */
  private Properties readLocalProperties() {

    Properties oLocalProperties = new Properties();

    String szConfigFile =  getConfigfile();

    FileInputStream in = null;

    /**
     * Read the properties file and then parse the individual attributes.
     */

    try {
      in = new FileInputStream( szConfigFile );

      oLocalProperties.loadFromXML(in);
    }
    catch (IOException e) {
      log4jDebugLogger.error("Error reading SyslogWriter properties.", e);
    }
    finally {
      if ( in != null ) {
        try {
          in.close();
        }
        catch (IOException e) {
          log4jDebugLogger.error("Error closing SyslogWriter properties.", e);
        }
      }
    }

    /**
     * Read the port property. If there is a problem setting it then use the default
     * syslog port (514).
     */
    try {
      miSyslogServerPort = Integer.parseInt( oLocalProperties.getProperty( "syslog.serverport" ) );
    }
    catch (NumberFormatException e) {
      log4jDebugLogger.debug("Error reading 'syslog.serverport'. Using default.", e);

      miSyslogServerPort = mkiDefaultSyslogPort;
    }

    /**
     * Read the property that determines whether the input datastream that comes in is
     * binary or ASCII.
     */
    mbIsBinaryInput = oLocalProperties.getProperty( "inputtype" ).equalsIgnoreCase("binary");

    String szIsBinaryInput = oLocalProperties.getProperty( "inputtype" );

    if ( szIsBinaryInput == null ) {
      log4jDebugLogger.debug("Error reading 'inputtype'. Using default.");
      mbIsBinaryInput = false;
    }
    else {
      mbIsBinaryInput = Boolean.parseBoolean( szIsBinaryInput );
    }

    /**
     * Read the syslog server hostname. It can be either an IP address or
     * a hostname. If there is a problem setting this then default to the
     * localhost.
     */
    mszSyslogServerHostname = oLocalProperties.getProperty( "syslog.serverhostname" );

    if ( mszSyslogServerHostname == null ) {
      log4jDebugLogger.debug("Error reading 'syslog.serverhostname'. Using default.");

      mszSyslogServerHostname = mkszLocalHost;
    }

    /**
     * Read the syslog log name. If it cannot be read then default to
     * the string "CSL".
     */
    mszSyslogLogname = oLocalProperties.getProperty( "syslog.logname" );

    if ( mszSyslogLogname == null ) {
      log4jDebugLogger.debug("Error reading 'syslog.logname'. Using default.");

      mszSyslogLogname = mkszDefaultSyslogLogname;
    }

    /**
     * Read the syslog flags. If there is a problem reading them
     * then set the flags to 0.
     */
    String szSyslogFlags = oLocalProperties.getProperty( "syslog.flags" );

    if ( szSyslogFlags == null ) {
      log4jDebugLogger.debug("Error reading 'syslog.flags'. Using default.");

      miSyslogFlags = 0;
    }
    else {
      if ( szSyslogFlags.indexOf("0x") > -1 ) {
        szSyslogFlags = szSyslogFlags.substring(2);
      }

      try {
        miSyslogFlags = Integer.parseInt( szSyslogFlags, 16 );
      }
      catch (NumberFormatException e) {
        log4jDebugLogger.debug("Error converting 'syslog.flags'. Using default.", e);

        miSyslogFlags = 0;
      }
    }

    /**
     * Read the syslog facility. If there is a problem reading it then
     * default to LOG_USER.
     */

    String szSyslogFacility = oLocalProperties.getProperty( "syslog.facility" );

    if ( szSyslogFacility == null ) {
      log4jDebugLogger.debug("Error reading 'syslog.facility'. Using default.");

      miSyslogFacility = mkiDefaultSyslogFacility;
    }
    else {
      try {
        miSyslogFacility = Integer.parseInt( szSyslogFacility );
      }
      catch (NumberFormatException e) {
        log4jDebugLogger.debug("Error converting 'syslog.facility'. Using default.", e);

        miSyslogFacility = mkiDefaultSyslogFacility;
      }
    }

    /**
     * Read the syslog priority. If there is a problem reading it then
     * default to LOG_INFO.
     */
      String szSyslogPriority = oLocalProperties.getProperty( "syslog.priority" );

      if ( szSyslogPriority == null ) {
        log4jDebugLogger.debug("Error reading 'syslog.priority'. Using default.");

        miSyslogPriority = mkiDefaultSyslogPriority;
      }
      else {
        try {
          miSyslogPriority = Integer.parseInt( szSyslogPriority );
        }
        catch (NumberFormatException e) {
          log4jDebugLogger.debug("Error converting 'syslog.priority'. Using default.", e);

          miSyslogPriority = mkiDefaultSyslogPriority;
        }
      }

    /**
     * Read the output format property. If there is a problem then default
     * to hex with no prefix.
     */
    String szOutputFormat = oLocalProperties.getProperty( "output.format" ) ;

    if ( szOutputFormat == null ) {
      log4jDebugLogger.debug("Error reading 'syslog.priority'. output.format.");

      miOutputFormat = mkiOutputHex;
    }
    else {
      if ( szOutputFormat.equalsIgnoreCase( mkszOutputFormatRaw ) ) {
        miOutputFormat = mkiOutputRaw;
      }
      else if ( szOutputFormat.equalsIgnoreCase( mkszOutputFormatDecimal ) ) {
        miOutputFormat = mkiOutputDecimal;
      }
      else {
        miOutputFormat = mkiOutputHex;

        String szUseHexPrefix = oLocalProperties.getProperty( "output.hexprefix" );

        if ( szUseHexPrefix == null ) {
          log4jDebugLogger.debug("Error reading 'output.hexprefix'. output.format.");
        }
        else {
          mbShowHexPrefix = Boolean.parseBoolean( szUseHexPrefix );
        }
      }
    }

    return ( oLocalProperties );
  }

  /**
   * The IStreamReceiver interface implementation that handles the stream.
   * @param abInputBuffer the byte array to be handled
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the byte array to be handled
   */
  public void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {
    if ( abInputBuffer == null || iLength == 0 ) {
      return;
    }

    if ( moStreamHandler != null ) {
      moStreamHandler.handleStream(abInputBuffer, iOffset, iLength);
    }
  }
}

/**
 * The base class for Binary and ASCII syslog writers.
 */
abstract class SyslogDataWriter {
  /**
   * The reference to the syslog instance.
   */
  protected Syslog moSyslog;

  /**
   * The output format.
   */
  protected int miOutputFormat;

  /**
   * The syslog Facility.
   */
  protected int miSyslogFacility;

  /**
   * The syslog Priority.
   */
  protected int miSyslogPriority;

  /**
   * The constructor for the base class.
   * @param oSyslog the syslog reference used for sending messsages to syslog daemon
   * @param iOutputFormat the output format indicating hex(1), decimal(2), or raw(3)
   * @param iSyslogFacility the facility id used for all syslog messages
   * @param iSyslogPriority the priority id used for all syslog messages
   */
  public SyslogDataWriter(Syslog oSyslog, int iOutputFormat, int iSyslogFacility, int iSyslogPriority) {
    moSyslog = oSyslog;
    miOutputFormat = iOutputFormat;
    miSyslogFacility = iSyslogFacility;
    miSyslogPriority = iSyslogPriority;
  }

  /**
   * The abstract method that all subclasses must implement depending on their behaviour.
   * @param abInputBuffer the streamed data to be processed
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the buffer to process
   */
  abstract public void handleStream(byte[] abInputBuffer, int iOffset, int iLength);
}

/**
 * This class will will convert binary data that it receives into ASCII printable data
 * and write it to syslog.
 */
class SyslogBinaryDataWriter extends SyslogDataWriter implements SyslogWriterConstants {
  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(SyslogBinaryDataWriter.class);

  /**
   * A flag to indicate whether the user preference is to show the hex prefix.
   */
  private boolean mbShowHexPrefix = false;

  /**
   * The constructor for the binary version of the syslog writer.
   * @param oSyslog the syslog reference used for sending messsages to syslog daemon
   * @param iOutputFormat the output format indicating hex(1), decimal(2), or raw(3)
   * @param iSyslogFacility the facility id used for all syslog messages
   * @param iSyslogPriority the priority id used for all syslog messages
   * @param bShowHexPrefix a flag indicating that the '0x' prefix should be shown
   */
  public SyslogBinaryDataWriter(Syslog oSyslog, int iOutputFormat, int iSyslogFacility, int iSyslogPriority, boolean bShowHexPrefix) {
    super( oSyslog, iOutputFormat, iSyslogFacility, iSyslogPriority );

    mbShowHexPrefix = bShowHexPrefix;
  }

  /**
   * The implementation for this abstract method which is responsible
   * for converting the binary stream to ASCII readable version before
   * sending it to syslog.
   * @param abInputBuffer the streamed data to be processed
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the buffer to process
   */
  public void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {

    try {
      String szInputBuffer = toPrintableString( abInputBuffer, iOffset, iLength );

      if ( szInputBuffer != null ) {
        moSyslog.syslog(miSyslogFacility, miSyslogPriority, szInputBuffer);
      }
    }
    catch (SyslogException e) {
      log4jDebugLogger.error("Error writing to syslog.", e);
    }
  }

  /**
   * Converts the binary data to ASCII hex format.
   * @param abInputBuffer the streamed data to be converted to ASCII
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the buffer to process
   * @return an ASCII hex format of the binary stream
   */
  private String toPrintableString( byte[] abInputBuffer, int iOffset, int iLength ) {
    StringBuffer oszStringBuffer = new StringBuffer();

    for ( int i = iOffset; i < iLength ; ++i ) {
      int iByte = abInputBuffer[i] & 0xFF;
      String szByte;

      if ( miOutputFormat == mkiOutputHex ) {
        String szPrefix;

        if ( mbShowHexPrefix ) {
          szPrefix = "0x";
        }
        else {
          szPrefix = "";
        }

        if ( iByte < 0x10 ) {
          szPrefix += "0";
        }

        szByte = szPrefix + Integer.toHexString( iByte );
      }
      else if ( miOutputFormat == mkiOutputDecimal ) {
        szByte = "00" + iByte;
        szByte = szByte.substring(szByte.length() - 3,szByte.length());
      }
      else { // it's raw
        szByte = "" + iByte;
      }

      oszStringBuffer.append( szByte ).append( " " );
    }

    return ( oszStringBuffer.toString() );
  }
}

/**
 * This class will will take the ASCII data that it receives
 * and write it to syslog.
 */
class SyslogAsciiDataWriter extends SyslogDataWriter {
  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(SyslogAsciiDataWriter.class);

  /**
   * Constructor for the syslog ascii writer.
   * @param oSyslog the syslog reference used for sending messsages to syslog daemon
   * @param iOutputFormat the output format indicating hex(1), decimal(2), or raw(3)
   * @param iSyslogFacility the facility id used for all syslog messages
   * @param iSyslogPriority the priority id used for all syslog messages
   */
  public SyslogAsciiDataWriter(Syslog oSyslog, int iOutputFormat, int iSyslogFacility, int iSyslogPriority) {
    super( oSyslog, iOutputFormat, iSyslogFacility, iSyslogPriority );
  }

  /**
   * The implementation for this abstract method which is responsible
   * for sending the received stream to syslog.
   * @param abInputBuffer the streamed data to be processed
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the buffer to process
   */
  public void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {

    try {
      String szInputBuffer = new String( abInputBuffer, iOffset, iLength, "UTF-8" );

      moSyslog.syslog(miSyslogFacility, miSyslogPriority, szInputBuffer);
    }
    catch (UnsupportedEncodingException e) {
      log4jDebugLogger.error("Error writing to syslog.", e);
    }
    catch (SyslogException e) {
      log4jDebugLogger.error("Error writing to syslog.", e);
    }
  }
}
