/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */

package com.nortel.cdma.service.csl.sls.writer.syslog;

/**
 * An interface which contains various constants
 * required by the syslog writers.
 */
public interface SyslogWriterConstants {
  /**
   * Constant for Hex Output.
   */
  public final int mkiOutputHex = 1;

  /**
   * Constant for Decimal Output.
   */
  public final int mkiOutputDecimal = 2;

  /**
   * Constant for Raw Output.
   */
  public final int mkiOutputRaw = 3;
}
