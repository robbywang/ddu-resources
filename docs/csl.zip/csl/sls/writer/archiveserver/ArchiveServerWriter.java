/*
* Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
*/

package com.nortel.cdma.service.csl.sls.writer.archiveserver;

import com.nortel.cdma.service.csl.sls.writer.Writer;
import com.nortel.cdma.service.csl.sls.writer.GenericStreamWriter;
import com.nortel.cdma.service.csl.sls.xml.DigesterStreamingLogServer;
import com.nortel.cdma.service.common.util.AlarmUtil;
import com.nortel.cdma.service.common.util.ScheduleSafeTimer;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import com.nortel.cdma.common.alarm.interfaces.AlarmDefinition;
import com.nortel.cdma.common.internationalization.CemsAlarmTextMessageCategory;
import com.nortel.cdma.common.internationalization.ProbableCauseMessageCategory;
import com.nortel.cdma.common.internationalization.CallSummaryLogMessageCategory;
import com.nortel.cdma.common.data.autogen.LocalName;
import com.nortel.cdma.service.csl.common.CSLUtil;
import com.nortel.cdma.service.csl.common.ExternalServerConfig;

import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.net.InetAddress;
import java.net.Socket;
import java.net.InetSocketAddress;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.nio.channels.SocketChannel;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * This class describes an ArchiveServerWriter which describes how to write data to the Customer Archive Server.
 */
public class ArchiveServerWriter extends GenericStreamWriter {
  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(ArchiveServerWriter.class);

  /**
   *  The Socket connecting to the Customer Archive Server.
   */
  private Socket moSocketDestination;

  /**
   *  The output stream which is used to write to CAS
   */
  private OutputStream outputStreamToCAS;

  /**
   * Flag indicating if an alarm has been raised. A null indicates that
   * the information is not available.
   */
  private volatile boolean mAlarmHasBeenRaised = false;

  /**
   * Attribute name for  ATT_DestinationPort.
   */
  public final static String DESTINATION_PORT = LocalName.ELM_CSLProfile.ATTGRP_ExternalServerConfig.ATT_DestinationPort;

  /**
   * Attribute name for  ATT_ServerHostName.
   */
  public final static String SERVER_HOSTNAME = LocalName.ELM_CSLProfile.ATTGRP_ExternalServerConfig.ATT_ServerHostName;

  /**
   * Time interval to check the connection to CAS. It is 30 seconds by default.
   * Unit: milliseconds
   */
  private final int CHECK_CONNECTION_INTERVAL = 30000;

  /**
   * Fake CAS IP address which indicates that CSL is not enabled.
   */
  private final String DUMMY_CAS_IP = "0.0.0.1";
  
  /**
   * True if CAS IP address is equal to DUMMY_CAS_IP.
   */
  private volatile boolean isDummyCasIp = true;

  /**
   * The timeout value to be used for socket connection. It is 10 seconds by
   * default.
   */
  private final int TIMEOUT_CONNECTION = 10000;

  /**
   * The maximum number of elements to fetch from records queue.
   * Unit: elements
   */
  private int maxElementsNumberToFetch = 5;

  /**
   * loop Queue is used to control buffer access.
   */
  private ArrayBlockingQueue<byte[]> recordsQueue;
  
  /**
   * The size of queue which is used to store data to CAS.
   */
  private int recordsQueueSize = 1000;

  /**
   *  The timeout value to be used for write records to CAS.
   *  Unit: milliseconds
   */
  private int timeoutForWriteToCAS = 20 * 1000;
  
  /**
   * True if last offer to queue operation is successfully.
   */
  private boolean offerQueueSuccessfullyLastTime = true; 
  
  /**
   * Timer to periodically generate statistics lost logs.
   */
  private Timer mShowStatsTimer;

  /**
   * Total number of lost log records when connection to CAS is OK.
   */
  private long totalLogsLostWhenConnOK = 0L;

  /**
   * Total number of lost log records when connection to CAS is down.
   */
  private long totalLogsLostWhenConnDown = 0L;
  
  /**
   * Number of lost log records when connection to CAS is OK in this period.
   */
  private volatile long thisPeriodLogsLostWhenConnOK = 0L;

  /**
   * Number of lost log records when connection to CAS is down in this period.
   */
  private volatile long thisPeriodLogsLostWhenConnDown = 0L;
  
  /**
   * lock object to synchronize lost logs calculation.
   */
  private Object lock = new Object();

  /**
   * Delay (in ms) between successive log messages indicating IO issue on writing to CAS.
   * Unit: milliseconds
   */
  private static final int IO_ISSUE_CALLSTACK_DEBOUNCE_DELAY = 5000;
  
  /**
   * Timestamp when message of IO issue on writing to CAS was logged.
   */
  private long ioIssueTimestamp = 0;

  volatile private static long dequeueBytes = 0l;
  volatile private static long enqueueBytes = 0l;
  volatile private static long loglostBytes = 0l;

  /**
   * The name of thread writes to CAS
   */
  private static String threadName = "Write to Archive server";
  
  /**
   *  The Debug flag. True if some detail debug info need to be printed.
   *  Default is false.
   */
  private boolean debugFlag = false;

  /**
   * The state of socket connection to CAS.
   */
  private volatile ConnectionState connState;
  
  /**
   * True if CAS is switched.
   * When handleExternalServerConfigAttGrpUpdate method is called, this flag may be set to true
   * according to logic of the method.
   * In customerArchiveServerConnectorThread, this flag is used and then is set to false.
   */
  private volatile boolean isCasSwitch = false;
  
  /**
   * Lock guarding connState access
   */
  private final ReentrantLock connectionLock;;
  
  /**
   * Condition for waiting connection establishment
   */
  private final Condition connectionDown;
  
  /**
   * Condition for waiting writes data through the connection.
   */
  private final Condition connectionOK;
  
  /**
   * Thread which maintain the socket connection to CAS.
   * If the connection is not down, it waits connectionDown condition.
   * If the connection is down, it is signaled to reestablish the connection.
   * If connection establishment fail, it tries to create connection periodically.
   * 
   * When connection need to be reestablished, it closes current connection if exist, 
   * and then tries to connect to CAS. After connection is created, state of connection 
   * is marked as ConnectionState.TRY. Now, peerSocketCloseDetectorThread is started 
   * and 5 seconds waiting happens. If peer socket does not close the connection after 
   * the 5 seconds, the connection is considered as OK and connectionOK condition is signaled.
   */
  private Thread customerArchiveServerConnectorThread;
  
  /**
   * Thread which write records to CAS from socket connection.
   * If the connection is not OK, it waits connectionOK condition.
   * If IO exception arises during write, it signals connectionDown.
   */
  private Thread writeToCustomerArchiveServerThread;
  
  /**
   * Thread which detect close operation of peer socket.
   * If peer socket close, it will signal connectionDown. 
   */
  private Thread peerSocketCloseDetectorThread;
  
  /**
   * True if it is the first time for CSL to connect to CAS.
   */
  private boolean isConnectAtTheFirstTime = true;
  
  /**
   * True if need shutdown.
   */
  private volatile boolean isStopping = false;

  /**
   *  Default constructor for the ArchiveServerWriter.
   */
  public ArchiveServerWriter() {
    super();
    connectionLock = new ReentrantLock();
    connectionDown = connectionLock.newCondition();
    connectionOK = connectionLock.newCondition();
    connState = ConnectionState.DOWN;
  }

  /**
   * Configures a PlugIn.
   * @param oProperties the set of Properties created by an XML file
   */
  public void config(Properties oProperties) {
    super.config(oProperties);

    if ( oProperties == null ) {
      return;
    }

    String ssQueueSize = (String) oProperties.get( DigesterStreamingLogServer.TAG_WRITER_QUEUE_SIZE );
    if ( ssQueueSize == null ) {
      log4jDebugLogger.warn( "Queue Size is null, so using default.");
    }
    else {
      recordsQueueSize = Integer.parseInt(ssQueueSize);
    }

    String szDebugFlag = (String) oProperties.get( DigesterStreamingLogServer.TAG_WRITER_DEBUG_FLAG );
    if ( szDebugFlag == null ) {
      log4jDebugLogger.warn( "Debug flag is null, so using default.");
    }
    else {
      if (szDebugFlag.equalsIgnoreCase("off")) {
        debugFlag = false;
      }
      else if (szDebugFlag.equalsIgnoreCase("on")) {
        debugFlag = true;
      }
    }

    String maxDequeueNumber = (String) oProperties.get( DigesterStreamingLogServer.TAG_WRITER_MAX_DEQUEUE_NUMBER );
    if ( maxDequeueNumber == null ) {
      log4jDebugLogger.warn( "Maximum number of elements to fetch from records queue is null using default.");
    }
    else {
      maxElementsNumberToFetch = Integer.parseInt(maxDequeueNumber);
    }
    
    String szWriteTimeout = (String) oProperties.get( DigesterStreamingLogServer.TAG_WRITER_TIMEOUT );
    if ( szWriteTimeout == null ) {
      log4jDebugLogger.warn( "Write timeout is null using default.");
    }
    else {
      timeoutForWriteToCAS = Integer.parseInt(szWriteTimeout);
    }
  }

  /**
   * Starts up the ArchiveServerWriter PlugIn.
   */
  protected void localStartup() throws InitializationFailureException,
    InvalidDeploymentException {

    log4jDebugLogger.warn("Creating queue of ArrayBlockingQueue, size is:" + recordsQueueSize
        + " Max elements number of drainTo is: " + maxElementsNumberToFetch
        + " Write timeout is: " + timeoutForWriteToCAS + " milliseconds.");
    recordsQueue = new ArrayBlockingQueue<byte[]>(recordsQueueSize);

    getArchiveServerConfigFromDB();

    connectToArchiveServer();

    if (debugFlag) {
      new Thread() {
        public void run() {
          long preDequeueBytes, preEnqueueBytes, preLoglostBytes;
          
          while (true) {
            preDequeueBytes = dequeueBytes;
            preEnqueueBytes = enqueueBytes;
            preLoglostBytes = loglostBytes;
            
            try {
              Thread.sleep(1000);
            }
            catch (Exception e) {
              log4jDebugLogger.error("log enquebytes error but be ignored", e);
            }
            
            byte[][] elements = recordsQueue.toArray(new byte[0][0]);
            int eleNumberOccupiedOfQueue = elements.length;
            int bytesNumberOccupiedOfQueue = 0;
            for (int i = 0; i < elements.length; i++) {
              bytesNumberOccupiedOfQueue += elements[i].length;
            }
            elements = null;
            log4jDebugLogger.warn("dequeueBytes in one seconds:" + (dequeueBytes - preDequeueBytes)
                + "enqueueBytes in one seconds:" + (enqueueBytes - preEnqueueBytes)
                + "loglostBytes in one seconds:" + (loglostBytes - preLoglostBytes)
                + "\nnumber of elements in queue: " + eleNumberOccupiedOfQueue
                + ", size of queue in bytes is: " + bytesNumberOccupiedOfQueue);
          }
        }
      }.start();
    }

    writeToCustomerArchiveServerThread = new Thread (threadName){
      public void run() {
        ArrayList<byte[]> recordsList = new ArrayList<byte[]>(); 
        while (!isStopping) {
          try {
            connectionLock.lockInterruptibly();
            try {
              try {
                while (connState != ConnectionState.OK)
                  connectionOK.await();
              }
              catch (InterruptedException ie) {
                connectionOK.signal(); // propagate to non-interrupted thread
                throw ie;
              }
            }
            finally {
              connectionLock.unlock();
            }
            
            fetchRecords(recordsList);
            writeRecordsToCAS(recordsList);
            recordsList.clear();
          }
          catch (InterruptedException ie) {
            //do nothing
          }
          catch (Exception ie) {
            log4jDebugLogger.error(ie);
          }
        }
      }
    };
    writeToCustomerArchiveServerThread.start();

    this.startLogLostSummary();
  }

  /**
   * starts the timer to send lost record statistics every 5 minutes.
   */
  private void startLogLostSummary() {
    mShowStatsTimer = new Timer();

    long period = 5 * 60 * 1000L; // 5 minutes in milliseconds
    long currentTime = System.currentTimeMillis();
    long delay = period - currentTime % period; // milliseconds till next half
    // hour

    mShowStatsTimer.scheduleAtFixedRate(new TimerTask() {
      public void run() {
        sendLostRecordSummary();
      }
    }, delay, period);
  }

  /**
   * report lost record statistics into debug logs.
   */
  private void sendLostRecordSummary(){
    synchronized(lock){
      totalLogsLostWhenConnOK += thisPeriodLogsLostWhenConnOK;
      totalLogsLostWhenConnDown += thisPeriodLogsLostWhenConnDown;
      if (log4jDebugLogger.isEnabledFor(Level.WARN)) {
        log4jDebugLogger.warn("Lost log Statistics (unit: bytes):"
                                  + "\n logs lost when connection is not down = " + thisPeriodLogsLostWhenConnOK
                                  + ", logs lost when connection is down = " + thisPeriodLogsLostWhenConnDown
                                  + ", sum = " + (thisPeriodLogsLostWhenConnDown+thisPeriodLogsLostWhenConnOK)
                                  + "\n total logs lost when connection is not down = " + totalLogsLostWhenConnOK
                                  + ", total logs lost when connection is down = " + totalLogsLostWhenConnDown
                                  + ", total sum = " + (totalLogsLostWhenConnDown+totalLogsLostWhenConnOK));
      }
      thisPeriodLogsLostWhenConnOK = 0;
      thisPeriodLogsLostWhenConnDown = 0;
    }
  }

  /**
   * Shuts down the ArchiveServerWriter plugin.
   */
  public synchronized void shutdown() {
    log4jDebugLogger.warn("Shutdown operation of ArchiveServerWriter begin......");
//    flush();
    mbIsStopping = true;
    isStopping = true;
    //Interrupt these 3 thread so that they stop soon if they are 
    //sleeping or waiting something.
    if (customerArchiveServerConnectorThread != null 
        && customerArchiveServerConnectorThread.isAlive()) {
      customerArchiveServerConnectorThread.interrupt();
    }
    if (peerSocketCloseDetectorThread != null 
        && peerSocketCloseDetectorThread.isAlive()) {
      peerSocketCloseDetectorThread.interrupt();
    }
    if (writeToCustomerArchiveServerThread != null
        && writeToCustomerArchiveServerThread.isAlive()) {
      writeToCustomerArchiveServerThread.interrupt();
    }
    closeCurrentSocket();
    super.shutdown();
    log4jDebugLogger.warn("Shutdown operation of ArchiveServerWriter finished.");
  }

  /**
   * Flush the outputstream.
   */
  public synchronized void flush() {
  flushData();

    if (moSocketDestination != null) {
      try{
        OutputStream iOutputStream = moSocketDestination.getOutputStream();
        iOutputStream.flush();
      }
      catch (IOException e){
        log4jDebugLogger.error("Unable to flush CSL data to CAS", e);
      }
    }
  }

  /**
   * Flush data in buffer to CAS.
   */
  private void flushData(){
    connectionLock.lock();
    try {
      try {
        writeRecordsToCAS(getRemainRecords());
      }
      catch (InterruptedException e) {
        // do nothing
      }
    }
    finally {
      connectionLock.unlock();
    }
  }

  /**
   * Retrieve the external server configuration (IPAddress and port Id) from
   * the database.
   */
  private void getArchiveServerConfigFromDB () {

    ExternalServerConfig oCASConfig = CSLUtil.getExternalServerConfig();

    if (oCASConfig != null) {
      if (oCASConfig.isValid()) {
        String tmpCasIP = oCASConfig.getExternalServerIPAddress();
        if (tmpCasIP != null) {
          mszSocketDestination = tmpCasIP;
        }

        short tmpPortId =  oCASConfig.getExternalServerPortId();

        if (tmpPortId != -1) {
          miPort = tmpPortId;
        }
      }
    }
  }

  /**
   *  Connects to the Archive Server specified by this instance's IP address and port information.
   */
  private void connectToArchiveServer() {

    customerArchiveServerConnectorThread = new Thread("Connect To Customer Archive Server")  {
      public void run() {
        while ( !isStopping ) {
          try {
            connectToCAS();
            Thread.sleep( CHECK_CONNECTION_INTERVAL );
          }
          catch (InterruptedException e1) {
            // do nothing
          }
        }
      }
    };

    customerArchiveServerConnectorThread.start();
  }
  
  /**
   * If the socket connection to CAS is not down, waits connectionDown condition.
   * Otherwise, close current connection if exist and make new connection to CAS.
   * After new connection is created, state of connection is marked as ConnectionState.TRY.
   * Then peerSocketCloseDetectorThread is started and 5 seconds waiting begin. If peer socket
   * does not close the connection after the 5 seconds, the connection is considered as OK and
   * connectOK condition is signaled.
   * @throws InterruptedException
   */
  private void connectToCAS() throws InterruptedException {
    connectionLock.lock();
    try {
      try {
        while (connState != ConnectionState.DOWN)
          connectionDown.await();
      }
      catch (InterruptedException ie) {
        connectionDown.signal(); 
        throw ie;
      }
      
      if (DUMMY_CAS_IP.equalsIgnoreCase(mszSocketDestination)) {
        isDummyCasIp = true;
      }
      else {
        isDummyCasIp = false;
      }
    }
    finally {
      connectionLock.unlock();
    }
    
    // Begin reconnect, so interrupt peerSocketCloseDetectorThread first.
    if (peerSocketCloseDetectorThread != null && peerSocketCloseDetectorThread.isAlive()) {
      peerSocketCloseDetectorThread.interrupt();
    }
    
    if (isDummyCasIp) {
      raiseOrClearAlarm(false);
      log4jDebugLogger.warn("IP of CAS is dummy: " + DUMMY_CAS_IP);
      return;
    }
    // If CAS is just switched, then do not raise alarm here.
    // If this is the first time to connect to CAS, do not raise alarm here.
    // Otherwise, raise alarm here because getting here means the existing connection goes wrong.
    // Alarm is raised in makeNewConnectionToCAS method if can not connect to new CAS.
    if (!isConnectAtTheFirstTime && !isCasSwitch) {
      raiseAlarm();
    }
    
    // If this is not the first time to connect to CAS, prints message and close current socket.
    if (!isConnectAtTheFirstTime) {
      printConnectionChangeMessage();
      closeCurrentSocket();  
    }
    else {
      isConnectAtTheFirstTime = false;
    }
    
    if (isCasSwitch) {
      isCasSwitch = false;
    }
    
    makeNewConnectionToCAS();
    
    connectionLock.lockInterruptibly();
    try {
      if (connState == ConnectionState.DOWN) {
        return;
      }
    }
    finally {
      connectionLock.unlock();
    }
    
    peerSocketCloseDetectorThread = startPeerSocketCloseDetector();
    Thread.sleep(5*1000);
    
    boolean passByDetector = false;
    connectionLock.lockInterruptibly();
    try {
      if (connState == ConnectionState.TRY) {
        connState = ConnectionState.OK;
        connectionOK.signal();
        //Socket connection OK now. Interrupt the thread so that
        //it can walk around the interval sleep and begin waiting 
        //for connectionDown as soon as possible.
        if (customerArchiveServerConnectorThread != null
            && customerArchiveServerConnectorThread.isAlive()) {
          customerArchiveServerConnectorThread.interrupt();
        }

        passByDetector = true;
      }
    }
    finally {
      connectionLock.unlock();
    }
    
    if (passByDetector) {
      log4jDebugLogger.warn("Connection to Archive Server ("
          + mszSocketDestination + ", " + miPort
          + ") is established and pass 5s peer close check at " + new Date());
      raiseOrClearAlarm(false);
    }
    else {
      log4jDebugLogger.warn("Connection to Archive Server (" + mszSocketDestination +
          ", " + miPort + ") was established but has been closed by peer during 5s peer close check.");
      raiseAlarm();
    }
  }

  /**
   * One is that current connection become down and need to reconnect.
   * The other is that connection need to switch from current CAS to another CAS.
   */
  private void printConnectionChangeMessage() {
    if (moSocketDestination != null) {
      String theIP = "";
      InetAddress ipAddr = moSocketDestination.getInetAddress();
      int port = moSocketDestination.getPort();
      if (ipAddr == null || port == 0) {
        return;
      }

      theIP = ipAddr.getHostAddress();
      
      if (!theIP.equals(mszSocketDestination) || miPort != port) {
        log4jDebugLogger.warn("Switch connection from Archive Server (" + ipAddr + ", " + port + ")"
            + " to Archive Server (" + mszSocketDestination + ", " + miPort + ")");
      }
    }
  }

  /**
   * Sets up socket connection to external customer archive server.
   * @throws InterruptedException 
   */
  private void makeNewConnectionToCAS() throws InterruptedException {
    try {
      if ((mszSocketDestination == null) || (miPort == 0)) {
        return;
      }
      
      log4jDebugLogger.warn("Current socket connection is down, try to create a socket connection to Archive Server ("
          + mszSocketDestination + ", " + miPort + ")");
      
      InetSocketAddress addr;
      connectionLock.lockInterruptibly();
      try {
        addr = new InetSocketAddress(mszSocketDestination, miPort);
      }
      finally {
        connectionLock.unlock();
      }
      
      moSocketDestination = new Socket();
      moSocketDestination.setTcpNoDelay(true);
      int iOutputBufferSize = getOutputBufferSize();
      moSocketDestination.setSendBufferSize(iOutputBufferSize);
      moSocketDestination.connect(addr, TIMEOUT_CONNECTION);
      outputStreamToCAS = new BufferedOutputStream(moSocketDestination.getOutputStream(), 
          moSocketDestination.getSendBufferSize());
      
      connectionLock.lockInterruptibly();
      try {
        connState = ConnectionState.TRY;
      }
      finally {
        connectionLock.unlock();
      }
      
      //create journal log
      CSLUtil.createJournalLog(CallSummaryLogMessageCategory.CAS_CONNECTION_ESTABLISHED,
          new String [] {mszSocketDestination, String.valueOf(miPort), new Date().toString()});
      if (log4jDebugLogger.isDebugEnabled()) {
        log4jDebugLogger.debug("Connection to Archive Server (" + mszSocketDestination +
            ", " + miPort + ") established at " + new Date());
      }
    }
    catch (IOException e) {
      // It is normal if the user has not turn on CSL logging and hence
      // CAS is not reachable. But it is a problem if the CSL is enabled and
      // an alarm will be raised if we do get CSL data
      log4jDebugLogger.error("Unable to connect to archive server (" + mszSocketDestination +
          ", " + miPort + ")");
      raiseAlarm();
    }
  }
  
  /**
   * Create and start peerSocketCloseDetectorThread.
   * @return peerSocketCloseDetectorThread
   */
  private Thread startPeerSocketCloseDetector() {
    Thread peerSocketCloseDetector = new Thread("Peer Socket Close Detector") {
      public void run() {
        try {
          detectPeerSocketClose();
        }
        catch (InterruptedException e) {
          // do nothing
        }
      }

    };
    peerSocketCloseDetector.start();
    return peerSocketCloseDetector;
  }

  /**
   * Read from the socket connection to CAS.
   * If -1 returned, the connection is closed by peer socket.
   * If IO exception arisen, the connection is closed by local or peer socket.
   * If these happens, connState is set and connectionDown condition is signaled.
   * Presupposition: CAS never write data to the connection.
   * To avoid the exception which CAS sends some data to the connection, do loop is used. 
   * @throws InterruptedException
   */
  private void detectPeerSocketClose() throws InterruptedException {
    if (moSocketDestination != null) {
      boolean loop = false;
      boolean got = false;
      do {
        byte[] buff = new byte[20];
        loop = false;
        try {
          int len = moSocketDestination.getInputStream().read(buff);
          if (len == -1) {
            log4jDebugLogger.warn("Detected by peerSocketCloseDetectorThread: connection " 
                + moSocketDestination + " is closed by peer");
            got = true;
          }
          else {
            loop = true;
          }
        }
        catch (IOException e) {
          log4jDebugLogger.warn("Detected by peerSocketCloseDetectorThread: " + e.getMessage());
          got = true;
        }
        
        if (got) {
          connectionLock.lockInterruptibly();
          try {
            connState = ConnectionState.DOWN;
            connectionDown.signal();
          }
          finally {
            connectionLock.unlock();
          }
        }
        
        if(loop) {
          Thread.sleep(1000);
        }
      } while (loop);
    }
  }
  
  /**
   * The IStreamReceiver interface implementation that handles the stream and write to buffer.
   * @param abInputBuffer the byte array to be handled
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the byte array to be handled
   */
  public void handleStream(byte[] abInputBuffer, int iOffset, int iLength) {
    if (isDummyCasIp) {
      return;
    }
    
    byte[] buffer = new byte [iLength];
    System.arraycopy(abInputBuffer,iOffset,buffer,0, iLength);
    try{
      enqueueBytes += buffer.length;

      if (!fillRecordsToQueue(buffer)){
        if (connState == ConnectionState.OK) {
          long currentTime = System.currentTimeMillis();
          if (currentTime - ioIssueTimestamp > IO_ISSUE_CALLSTACK_DEBOUNCE_DELAY) {
            ioIssueTimestamp = currentTime;
            log4jDebugLogger
                .warn("Socket I/O to CAS is abnormal, please check the thread call stack. Log lost size this time: "
                    + iLength);
            try {
              log4jDebugLogger.warn(""
                  + LogMXBeansInfoUtility.getThreadMXBeanInfo());
            }
            catch (Exception e) {
              //do nothing.
            }
          }
        }
        loglostBytes += iLength;
        synchronized(lock){
          if (connState == ConnectionState.OK) {
            thisPeriodLogsLostWhenConnOK += iLength;
          }
          else {
            thisPeriodLogsLostWhenConnDown += iLength;
          }
        }
      }
    }
    catch(InterruptedException ie){
      log4jDebugLogger.error("Unable to write data to buffer", ie);
    }
  }

  /**
   * Persist data to CAS.
   *
   * @param buffer
   * @return
   * @throws InterruptedException
   */
  private boolean fillRecordsToQueue(byte[] buffer) throws InterruptedException{
    /*
    Below logical is confirmed and got from eBSC team.
    There are 2 error scenarios:
    1.Wrote error when transfer a log object to CEMS. The connection will be closed
          wrote = send(Sock, msgptr, msgsize, 0);
          if (wrote > 0)
          {
             // We should never encounter partial wrtie since in blocking mode
             // the send() call is blocked until there are enough space in
             // TCP/IP buffer
             if (wrote != msgsize)
             {
                XdmStr.Clear() << "Partial log sent ("
                   << wrote << " of " << msgsize << ")";
                TRACEOUT_DOMAIN_ERROR(XdmStr)
             }
          }
          else
          {
             // EINTR is not an error, so we just retry again
             if (wrote == -1 && errno == EINTR)
             {
                NumberOfEINTR++;
                continue;
             }
             else if (wrote == -1 && errno != EINTR)
          {
          //......
         // This will make IsConnectionFailed() to return true,
         // and higher level code will close connection and retry
         IsConnectionFail = true;
         return;
       }
    2. If DataSendGuardTimer found this round of send log have been lasted for too long (excced the SEND_BLOCK_TIME_THRESHOLD), it will close this connection.

    void SLogTransportAgent::ProcessDataSendGuardTimerExpiry()
    {
       // This is commented out so we do not clog the debug window, uncomment
       // as needed
       //TRACEOUT_METHOD_ENTRY()

       ACLST_SystemTime currentTime;

       // If the Start time is not set, which mean no send() in progress
       if (SocketSendStartTime.GetSecCount() == 0)
       {
          return;
       }
       // Calculate the elapsed time since send() blocked

       ACLSTS_SystemTimeServer::GetTime(currentTime, FALSE);

       ACLST_SystemTime elapsedTime = currentTime - SocketSendStartTime;

       // Close connection to unblock the send() if it hangs
       if (elapsedTime.GetSecCount() > SEND_BLOCK_TIME_THRESHOLD)
       {
          Stream->CloseConnection();

          SocketSendStartTime.SetTime(0);

          NumberOfSendBlockedTooLong++;

       }

       // This is commented out so we do not clog the debug window, uncomment
       // as needed
       //TRACEOUT_METHOD_RETURN()
    }
    ------------------------------------------------------------------------------------------------------------------------------------------------

    // Threshold in seconds to close connection and re-connect if a send()

    // hang too long

    const word16 SEND_BLOCK_TIME_THRESHOLD = 120;

    3. After the connection has been closed, a ConnReopenTimer will be started to re-open the connection.

    ConnReopenTimer.Start(RetryInterval, REX_ONE_SHOT);

    4. If the re-connection still failed, we will continuous have re-try. Every time the retry interval time will be doubled. Max interval time will be 60s. After it have re-tried 5 time, a alarm will be raised to indicate the connection failed.

    const MicrosecondsType ACPTUNE_SLOG_TransAgnt_ConnRetryInterval = 1000000;

    const MicrosecondsType ACPTUNE_SLOG_TransAgnt_MaxConnRetryInterval = 60*1000000;

    const byte ACPTUNE_SLOG_TransAgnt_ConnReopenFailureReportThreshold = 5;

    5. From Above data, you can see that there are several scenarios will have the queue only have input no output for several seconds. If CEMS have the short time out, I thinks it is safe.
     */
    if (offerQueueSuccessfullyLastTime) {
      offerQueueSuccessfullyLastTime = recordsQueue.offer(buffer, timeoutForWriteToCAS, TimeUnit.MILLISECONDS);
    }
    else {
      offerQueueSuccessfullyLastTime = recordsQueue.offer(buffer);
    }
    
    return offerQueueSuccessfullyLastTime;
  }
  
  /**
   * Write records to CAS.
   * 
   * @param recordsList
   * @throws InterruptedException 
   */
  private void writeRecordsToCAS(ArrayList<byte[]> recordsList) throws InterruptedException {

    try {
      for (byte[] records : recordsList) {
        outputStreamToCAS.write(records);
        dequeueBytes += records.length;
      }
      outputStreamToCAS.flush();
    }
    catch (IOException e) {
      log4jDebugLogger.error("Exception is raised during writeRecordsToCAS", e);
      connectionLock.lockInterruptibly();
      try {
        connState = ConnectionState.DOWN;
        connectionDown.signal();
        if (customerArchiveServerConnectorThread != null) {
          customerArchiveServerConnectorThread.interrupt();
        }
      }
      finally {
        connectionLock.unlock();
      }
    }
    catch (Exception e) {
      log4jDebugLogger.error("Exception is raised during writeRecordsToCAS", e);
    }    
  }

  /**
   * Fetch records from recordsQueue.
   * First take() so that waits until the queue is not empty.
   * If records comes, removes at most the given number of available elements 
   * from records queue and adds them to the given collection.
   * 
   * @param recordsList - the collection to transfer elements into
   * @throws InterruptedException
   */
  private void fetchRecords(ArrayList<byte[]> recordsList) throws InterruptedException {
    recordsList.add(recordsQueue.take());
    recordsQueue.drainTo(recordsList, maxElementsNumberToFetch);
  }
  
  /**
   * Removes all available elements from records queue and adds them to the given collection. 
   * @return
   */
  private ArrayList<byte[]> getRemainRecords() {
    ArrayList<byte[]> list = new ArrayList<byte[]>();
    recordsQueue.drainTo(list);
    return list;
  }

  /**
   *  Raise alarm if the connection to CAS failed.
   */
  private void raiseAlarm () {

    if(!mAlarmHasBeenRaised) {
      Date now = new Date(System.currentTimeMillis());
      CSLUtil.createJournalLog(CallSummaryLogMessageCategory.CAS_CONNECTION_LOST,
        new String [] {mszSocketDestination, String.valueOf(miPort), now.toString()});

      //Once we do have CSL data to write to CAS but the connection
      //is not available, raise an alarm
      raiseOrClearAlarm(true);
    }
  }

  /**
   * Raises or clears an alarm when connection to CAS is closed or reopened.
   *
   * @param isRaise If true indicates a raise, otherwise a clear
   */
  private void raiseOrClearAlarm(boolean isRaise) {

    // If the alarm flag is null, raise or clear the alarm
    if (isRaise == mAlarmHasBeenRaised) {
      // Nothing to do - the alarm has already been raised/cleared
      return;
    }

    String debugMsg = isRaise ? "Raise_Alarm" : "Clear_Alarm";
    log4jDebugLogger.warn(debugMsg);

    int  alarmType  = AlarmDefinition.EVENT_TYPE_COMMUNICATIONS;

    int  severity   = AlarmDefinition.SEVERITY_MINOR;

    int  messageKey =
      CemsAlarmTextMessageCategory.CEMS_CSLProfile_1_0.intValue();

    int  probableCause =
      ProbableCauseMessageCategory.COMM_SUBSYSTEM_FAIL;

    Object[]  args       = null;

    AlarmUtil alarmUtil = AlarmUtil.getInstance();
    if (alarmUtil.raiseOrClearAlarmOnCSLProfileME(isRaise, alarmType, severity,
      messageKey, probableCause, args)) {
      mAlarmHasBeenRaised = isRaise;
    }
    else {
      log4jDebugLogger.error("Unable to " + debugMsg + " for connection to CAS");
    }
  }

  /**
   * If there are some changes in CEMS DB regarding ExternalServerConfig attribute
   * group, then retrieves the updated CAS host name and port info.
   * Interrupt customerArchiveServerConnectorThread and signal connectionDown so that
   * customerArchiveServerConnectorThread close current connection and connect to new CAS.
   * 
   * @param szIPAddress the IP address from  ExternalServerConfig attribute group
   * @param portId the port Id from  ExternalServerConfig attribute group
   */
  public void handleExternalServerConfigAttGrpUpdate(String szIPAddress, short portId)  {
    connectionLock.lock();
    try {
      // interrupt customerArchiveServerConnectorThread so that
      // it can reconnect to new CAS as soon as possible.
      if (customerArchiveServerConnectorThread != null
          && customerArchiveServerConnectorThread.isAlive()) {
        customerArchiveServerConnectorThread.interrupt();
      }
      
      isCasSwitch = false;
      if ((szIPAddress != null)
          && (!szIPAddress.equalsIgnoreCase(mszSocketDestination))) {
        // update the cached values only if it is changed.
        mszSocketDestination = szIPAddress;
        log4jDebugLogger.debug("Got updated ServerHostName = "
            + mszSocketDestination);
        isCasSwitch = true;
      }

      if ((portId != -1) && (portId != miPort)) {
        // update the cached values only if it is changed.
        miPort = portId;
        log4jDebugLogger.debug("Got updated  DestinationPort = " + miPort);
        isCasSwitch = true;
      }

      // restart the connection if there is update
      if (isCasSwitch) {
        connState = ConnectionState.DOWN;
        connectionDown.signal();
      }
    }
    finally {
      connectionLock.unlock();
    }

  }
  
  /**
   *  Close the current open socket if any.
   */
  private void closeCurrentSocket() {
    if (moSocketDestination != null) {
      try {
        log4jDebugLogger.warn("Close socket: " + moSocketDestination + "......");
        moSocketDestination.close();
        log4jDebugLogger.warn("Close socket: " + moSocketDestination + "...Finished");
        moSocketDestination = null;
      }
      catch (IOException e) {
        log4jDebugLogger.error("Unable to close socket");
        moSocketDestination = null;
      }
    }
    if (outputStreamToCAS != null) {
      try {
        outputStreamToCAS.close();
        outputStreamToCAS = null;
      }
      catch (IOException e) {
        // do nothing
      }
    }
  }
  
  

  /**
   * This is an enum class to show state of socket connection to CAS.
   * There are three states: DOWN, TRY and OK.
   */
  private enum ConnectionState {
    /**
     * The socket connection to CAS has some problems and 
     * need to be reconnected.
     */
    DOWN, 
    /**
     * The socket connection to CAS has been connected 
     * but 5 seconds peer socket close check has not been finished.
     * This is for the customer case which connection is closed soon after created. 
     */
    TRY, 
    /**
     * The socket connection to CAS has been connected 
     * and has passed 5 seconds peer socket close check.
     */
    OK
  }

  /**
   * This is a utility class which used to retrieve MBean information of Write to Archive server Thread.
   */
  static class LogMXBeansInfoUtility{

      /**
       * Get information from ThreadMXBean.
       * @return formated string which hold information of ThreadMXBean.
       */
      public static String getThreadMXBeanInfo(){
        return getThreadMXBeanInfoValue(ManagementFactory.getThreadMXBean()).toString();
      }

      private static String getThreadMXBeanInfoValue(ThreadMXBean threadBean){
        StringBuffer buffer = new StringBuffer();
        StringBuffer infoBuffer = new StringBuffer();

        boolean isCASThreadExist = false;
        buffer.append("Total " + threadBean.getThreadCount() + " threads in current JVM.\n");
        for (long threadId : threadBean.getAllThreadIds()){
        boolean flag = isCASThread(threadBean,threadId);

        if(flag){
          isCASThreadExist = true;
            infoBuffer.append(getThreadCallStackInfo(threadBean, threadId));
            break;
        }
        }

        if(!isCASThreadExist){
          infoBuffer.append("No " + threadName + " Thread found.");
        }
        buffer.append(infoBuffer.toString());;

        return buffer.toString();
      }

      private static boolean isCASThread(ThreadMXBean threadBean, long threadId){
        return threadBean.getThreadInfo(threadId).getThreadName().equalsIgnoreCase(threadName);
      }

      private static String getThreadCallStackInfo(ThreadMXBean threadBean, long threadId){
        StringBuffer buffer = new StringBuffer();

        buffer.append(threadName + " Thread Call Stack information:\n");

        ThreadInfo threadInfo = threadBean.getThreadInfo(threadId,100);
        if (threadInfo == null){
            // can't get threadInfo maybe because this thread is over at this time.
          buffer.append("Thread ID : " + threadId + ", can't get thread information.\n");
        }
        else{
          buffer.append(formatThreadCallStack(threadInfo));
        }

        return buffer.toString();
      }

      private static String formatThreadCallStack(ThreadInfo threadInfo){
        StringBuffer buffer = new StringBuffer();

        buffer.append("Thread ID : " + threadInfo.getThreadId() +
            ", thread name : " + threadInfo.getThreadName() +
            ", thread state : " + threadInfo.getThreadState() + "\n");

        buffer.append("Thread call stack : \n");
        for (StackTraceElement traceElem: threadInfo.getStackTrace()){
          buffer.append(traceElem.toString() + "\n");
        }
        buffer.append("\n");

        return buffer.toString();
      }
   }
}

