/**
 * Copyright (c) 2005 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.xml;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import com.nortel.cdma.service.csl.sls.filter.Filter;
import com.nortel.cdma.service.csl.sls.reader.Reader;
import com.nortel.cdma.service.csl.sls.writer.Writer;
import com.nortel.cdma.service.csl.sls.common.interfaces.IPlugIn;
import com.nortel.cdma.service.common.xml.Digester;
import com.nortel.cdma.service.common.xml.Schema;

import java.io.File;
import java.util.Properties;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.apache.log4j.Logger;

/**
 * This class describes a DigesterStreamingLogServer which details how to parse the Streaming Log Server configuration
 * file which is in XML format.
 */
public class DigesterStreamingLogServer extends Digester {

  /**
   * Instance of Log4j.Logger.
   */
  final private static Logger log4jDebugLogger = Logger.getLogger(DigesterStreamingLogServer.class);

  /**
   * Tag used to specify that a Reader object is being retrieved.
   */
  private final String TAG_PLUGIN_READER = "reader";

  /**
   * Tag used to specify that a Reader object is being retrieved.
   */
  private final String TAG_PLUGIN_FILTER = "filter";

  /**
   * Tag used to specify that a Reader object is being retrieved.
   */
  private final String TAG_PLUGIN_WRITER = "writer";

  /**
   * Tag used to retrieve the ELC configuration file.
   */
  private final String TAG_NAME = "name";

  /**
   * Tag used to retrieve the ELC configuration file.
   */
  private final String TAG_NEXTREF = "nextRef";

  /**
   * Tag used to retrieve the ELC configuration file.
   */
  private final String TAG_PREVREF = "prevRef";

  /**
   * Tag used to retrieve the ELC configuration file.
   */
  private final String TAG_READER_PORT = "port";

  /**
   * Tag used to retrieve the Filter configuration file.
   */
  private final String TAG_CONFIGFILE = "configfile";

  /**
   * Tag used to retrieve the output buffer size.
   */
  private final String TAG_WRITER_OUTPUT_BUFFER_SIZE = "outputbuffersize";

  /**
   * Tag used to retrieve the dynamic queue blocks.
   */
  public static final String TAG_WRITER_QUEUE_SIZE = "queueSize";

  /**
   * Tag used to retrieve the dynamic queue block size.
   */
  public static final String TAG_WRITER_DEBUG_FLAG = "debug";

  /**
   * Tag used to retrieve the default dequeue bytes every read.
   */
  public static final String TAG_WRITER_MAX_DEQUEUE_NUMBER = "maxDequeueNumber";

  /**
   * Tag used to retrieve the timeout value to be used for writing to customer archive server.
   * Unit: millisecond
   */
  public static final String TAG_WRITER_TIMEOUT = "writeTimeout";

  /**
   * Tag used to retrieve the input buffer size.
   */
  private final String TAG_READER_INPUT_BUFFER_SIZE = "inputbuffersize";
  
  /**
   * Tag used to retrieve the destination address.
   */
  private final String TAG_WRITER_DESTINATION_ADDRESS = "destinationaddress";

  /**
   * Tag used to retrieve the ELC configuration file.
   */
  private final String TAG_WRITER_PORT = "port";

    /**
   * Tag used to indicate the incoming data are either XDR or XDRLite.
   */
  private final String TAG_CSL_DATATYPE = "datatype";

  /**
   * Constructs DataCollectorDigester object.
   * @param oXml the configure file
   * @throws InitializationFailureException
   * @throws InvalidDeploymentException

   */
  public DigesterStreamingLogServer(File oXml) throws
    InitializationFailureException, InvalidDeploymentException {
    super(oXml);
  }

  /**
   *  Retrieve the CSLSchema object.
   * @return SectionRouter instance
   */
  public SchemaStreamingLogServer getSchema() {
    return (SchemaStreamingLogServer) moSchema;
  }

  /**
   * Parse file management configure file, which is in xml format.
   * @param oXml the configuration file
   * @return  CSLSchema object
   * @throws InitializationFailureException
   * @throws InvalidDeploymentException
   */
  protected SchemaStreamingLogServer parseXml(File oXml) throws
    InitializationFailureException, InvalidDeploymentException {
    final String  msgPref = "SchemaStreamingLogServer - parseXML - ";

    String filePath = oXml.getPath();

    Document fmsSchemaDoc = getDocument(filePath);

    if (fmsSchemaDoc == null) {
      return null;
    }

    NodeList fileMgrSchemaNodes = fmsSchemaDoc.getElementsByTagName("streaminglogserverschema");

    if (fileMgrSchemaNodes.getLength() == 0) {
      log4jDebugLogger.warn(msgPref + "Missing streaminglogserverschema tag in file: " + filePath);
      return null;
    }

    // Process only the first one
    Node fileMgrSchemaNode = fileMgrSchemaNodes.item(0);

    SchemaStreamingLogServer oSchemaStreamingLogServer = new SchemaStreamingLogServer();

    NodeList  fmsEntityNodes = fileMgrSchemaNode.getChildNodes();
    int       entityCount = fmsEntityNodes.getLength();

    for (int i = 0; i < entityCount; i++) {
      Node  entityNode = fmsEntityNodes.item(i);

      if (!(entityNode instanceof Element)) {
        continue;   // Something we aren't interested in, like comments
      }
      Element entity = (Element)entityNode;

      String  entityType = entity.getLocalName();

      if (entityType.equalsIgnoreCase(TAG_PLUGIN_READER)) {
        Reader oReader = parseReader(entity, oSchemaStreamingLogServer);

        oSchemaStreamingLogServer.addReader(oReader);
      }
      else if (entityType.equalsIgnoreCase(TAG_PLUGIN_FILTER)) {
        Filter oFilter = parseFilter(entity, oSchemaStreamingLogServer);

        oSchemaStreamingLogServer.addFilter(oFilter);
      }
      else if (entityType.equalsIgnoreCase(TAG_PLUGIN_WRITER)) {
        Writer oWriter = parseWriter(entity, oSchemaStreamingLogServer);

        oSchemaStreamingLogServer.addWriter(oWriter);
      }
      else {
        log4jDebugLogger.warn(msgPref + "Ignoring unexpected element: " + entity);
      }
    }

    return oSchemaStreamingLogServer;
  }

  /**
   *  Parse a reader, which is in xml format.
   * @param entity the xml object
   * @param oSchemaStreamingLogServer a reference to the Streaming Log Server schema
   * @return  Reader object
   * @throws InitializationFailureException
   * @throws InvalidDeploymentException
   */
  protected Reader parseReader(Element entity, SchemaStreamingLogServer oSchemaStreamingLogServer)
    throws InitializationFailureException, InvalidDeploymentException {
    /*
    <reader>
    <name>Read XDR lite Streams</name>
    <class>com.nortel...</class>
    <port>1300</port>
    <inputbuffersize>4194304</inputbuffersize>
    <nextRef></nextRef>
    <prevRef></prevRef>
    </reader>
    */
    Reader oReader = instantiateEntity(entity, Reader.class);

    if (oReader != null) {
      String szName = getStringValueForTag(entity, TAG_NAME);
      String szPort = getStringValueForTag(entity, TAG_READER_PORT);
      String szInputBufferSize = getStringValueForTag(entity, TAG_READER_INPUT_BUFFER_SIZE);
      String szNextRef = getStringValueForTag(entity, TAG_NEXTREF);
      String szPrevRef = getStringValueForTag(entity, TAG_PREVREF);

      oReader.setName( szName );

      if ( szPort != null ) {
        oReader.setPort( Integer.parseInt( szPort ) );
      } 
      else {
        szPort = "5258";
      } 

      if ( szInputBufferSize == null ) {
        szInputBufferSize = "4194304";
      } 

      IPlugIn oIPlugInNext = oSchemaStreamingLogServer.getPlugIn(szNextRef);

      if ( oIPlugInNext != null ) {
        oReader.register( oIPlugInNext );
      }

      IPlugIn oIPlugInPrev = oSchemaStreamingLogServer.getPlugIn(szPrevRef);

      if ( oIPlugInPrev != null ) {
        oIPlugInPrev.register( oReader );
      }

      Properties oProperties = new Properties();
      addProperty(oProperties, TAG_NAME, szName);
      addProperty(oProperties, TAG_READER_PORT, szPort);
      addProperty(oProperties, TAG_READER_INPUT_BUFFER_SIZE, szInputBufferSize);

      oReader.config(oProperties);
      oReader.startup();
    }

    return ( oReader );
  }

  /**
   *  Parse a filter, which is in xml format.
   * @param entity the xml object
   * @param oSchemaStreamingLogServer a reference to the Streaming Log Server schema
   * @return  Reader object
   * @throws InitializationFailureException
   * @throws InvalidDeploymentException
   */
  protected Filter parseFilter(Element entity, SchemaStreamingLogServer oSchemaStreamingLogServer)
    throws InitializationFailureException, InvalidDeploymentException {
/*
<filter>
<name>ODL Parser</name>
<class>com.nortel...</class>

<prevRef>XDR Lite Converter</prevRef>
<nextRef></nextRef>
</filter>
*/
    Filter oFilter = instantiateEntity(entity, Filter.class);

    if (oFilter != null) {
      String szName = getStringValueForTag(entity, TAG_NAME);
      String szConfigFile = getStringValueForTag(entity, TAG_CONFIGFILE);
      String szNextRef = getStringValueForTag(entity, TAG_NEXTREF);
      String szPrevRef = getStringValueForTag(entity, TAG_PREVREF);
      String szDataType = getStringValueForTag(entity, TAG_CSL_DATATYPE);

      oFilter.setName( szName );

      IPlugIn oPlugInNext = oSchemaStreamingLogServer.getPlugIn(szNextRef);

      if ( oPlugInNext != null ) {
        oFilter.register( oPlugInNext );
      }

      IPlugIn oPlugInPrev = oSchemaStreamingLogServer.getPlugIn(szPrevRef);

      if ( oPlugInPrev != null ) {
        oPlugInPrev.register( oFilter );
      }

      Properties oProperties = new Properties();
      addProperty(oProperties, TAG_NAME, szName);
      addProperty(oProperties, TAG_CONFIGFILE, szConfigFile);

      oFilter.config(oProperties);
      oFilter.startup();
      if (szDataType != null) {
        oFilter.setCSLDataType(szDataType);
      }
    }

    return ( oFilter );
  }

  /**
   *  Parse a writer, which is in xml format.
   * @param entity the xml object
   * @param oSchemaStreamingLogServer a reference to the Streaming Log Server schema
   * @return  a Writer object
   * @throws InitializationFailureException
   * @throws InvalidDeploymentException
   */
  protected Writer parseWriter(Element entity, SchemaStreamingLogServer oSchemaStreamingLogServer)
    throws InitializationFailureException, InvalidDeploymentException {
    /*
    <writer>
    <name>Write To Customer Archive Server</name>
    <class>com.nortel...</class>
    <destinationaddress>127.0.0.1</destinationaddress>
    <destinationport>1300</destinationport>
    <outputbuffersize>4194304</outputbuffersize>
    <prevRef>XDR Lite Converter</prevRef>
    </writer>
    */
    Writer oWriter = instantiateEntity(entity, Writer.class);

    if (oWriter != null) {

      String szName = getStringValueForTag(entity, TAG_NAME);
      String szDestinationAddress = getStringValueForTag(entity, TAG_WRITER_DESTINATION_ADDRESS);
      String szPort = getStringValueForTag(entity, TAG_WRITER_PORT);
      String szOutputBufferSize = getStringValueForTag(entity, TAG_WRITER_OUTPUT_BUFFER_SIZE);
      String szConfigFile = getStringValueForTag(entity, TAG_CONFIGFILE);
      
      String ssQueueSize = getStringValueForTag(entity, TAG_WRITER_QUEUE_SIZE);
      String szDebugFlag = getStringValueForTag(entity, TAG_WRITER_DEBUG_FLAG);
      String szMaxDequeueNumber = getStringValueForTag(entity, TAG_WRITER_MAX_DEQUEUE_NUMBER);
      String szWriteTimeout = getStringValueForTag(entity, TAG_WRITER_TIMEOUT);
      
      String szNextRef = getStringValueForTag(entity, TAG_NEXTREF);
      String szPrevRef = getStringValueForTag(entity, TAG_PREVREF);

      oWriter.setName(szName);
      oWriter.setDestinationAddress(szDestinationAddress);

      if ( szPort != null ) {
        oWriter.setPort( Short.parseShort( szPort)  );
      }

      if ( szOutputBufferSize == null ) {
        szOutputBufferSize = "4194304";
      }

      IPlugIn oIPlugInNext = oSchemaStreamingLogServer.getPlugIn(szNextRef);

      if ( oIPlugInNext != null ) {
        oWriter.register( oIPlugInNext );
      }

      IPlugIn oIPlugInPrev = oSchemaStreamingLogServer.getPlugIn(szPrevRef);

      if ( oIPlugInPrev != null ) {
        oIPlugInPrev.register( oWriter );
      }

      Properties oProperties = new Properties();
      addProperty(oProperties, TAG_NAME, szName);
      addProperty(oProperties, TAG_WRITER_DESTINATION_ADDRESS, szDestinationAddress);
      addProperty(oProperties, TAG_WRITER_PORT, szPort);
      addProperty(oProperties, TAG_WRITER_OUTPUT_BUFFER_SIZE, szOutputBufferSize);
      addProperty(oProperties, TAG_CONFIGFILE, szConfigFile);
      addProperty(oProperties, TAG_WRITER_QUEUE_SIZE, ssQueueSize);
      addProperty(oProperties, TAG_WRITER_DEBUG_FLAG, szDebugFlag);
      addProperty(oProperties, TAG_WRITER_MAX_DEQUEUE_NUMBER, szMaxDequeueNumber);
      addProperty(oProperties, TAG_WRITER_TIMEOUT, szWriteTimeout);
      
      oWriter.config(oProperties);
      oWriter.startup();
    }

    return ( oWriter );
  }

  /**
   *  Datafill the policy object caches based on the CSLSchema
   *  object which contains user specification.
   * @param oSchema the file manager schema
   */
  protected void buildObjects(Schema oSchema) {
    // not needed since the Schema is the cache
  }

  /**
   * Builds a Properties object from the Entity object containing the tags in an XML file.
   * @param oEntity the element containing the XML tags
   * @return a Properties containing the tags from an XML file
   */
  protected Properties extractTokens(Element oEntity) {
    Properties oProperties = new Properties();

    return ( oProperties );
  }

  /**
   * Helper method that performs null pointer checks prior to adding a new set into a Property object.
   * @param oProperties the set of Properties to add to
   * @param szKey the key used to hold the specific property
   * @param szValue the value of the specific property
   */
  private void addProperty(Properties oProperties, String szKey, String szValue) {
    if ( ( szKey != null ) && ( szValue != null ) ) {
      oProperties.put(szKey, szValue);
    }
  }
}
