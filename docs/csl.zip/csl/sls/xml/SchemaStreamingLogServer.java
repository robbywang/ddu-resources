/**
 * Copyright (c) 2005 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.xml;

import com.nortel.cdma.service.common.xml.Schema;
import com.nortel.cdma.service.csl.sls.reader.Reader;
import com.nortel.cdma.service.csl.sls.filter.Filter;
import com.nortel.cdma.service.csl.sls.writer.Writer;
import com.nortel.cdma.service.csl.sls.common.interfaces.IPlugIn;

import java.util.Collection;
import java.util.TreeMap;

/**
 * This class describes a SchemaStreamingLogServer which details the contents of the Streaming Log Server schema.
 * It contains methods used to retrieve Streaming Log Server data structures.
 */
public class SchemaStreamingLogServer extends Schema {

  /**
   * Hashtable of SectionManager objects.
   */
  private TreeMap<String, Reader> moCollectionReader;

  /**
   *  Hashtable of Strategy objects.
   */
  private TreeMap<String, Filter> moCollectionFilter;

  /**
   * Hashtable of FilenameDescription objects.
   */
  private TreeMap<String, Writer> moCollectionWriter;

  /**
   * Constructor.
   */
  public SchemaStreamingLogServer() {
    moCollectionReader = new TreeMap<String, Reader>();
    moCollectionFilter = new TreeMap<String, Filter>();
    moCollectionWriter = new TreeMap<String, Writer>();
  }

  /**
   * Gets the IPlugIn object matching the name passed in.
   * @param szName the name of an IPlugIn reference
   * @return the IPlugIn object matching the name passed in
   */
  public IPlugIn getPlugIn(String szName) {
    IPlugIn oIPlugIn = null;

    if ( szName != null ) {
      oIPlugIn = moCollectionReader.get( szName );

       if ( oIPlugIn == null ) {
         oIPlugIn = moCollectionFilter.get( szName );
       }

       if ( oIPlugIn == null ) {
         oIPlugIn = moCollectionWriter.get( szName );
       }
    }

    return ( oIPlugIn );
  }

  /**
   * Gets all Reader objects.
   * @return  Collection of Reader objects.
   */
  public Collection<Reader> getReaders() {

    return ( moCollectionReader.values() );
  }

  /**
   * Adds a Reader object to the internal collection.
   * @param oReader the Reader object to add.
   */
  public void addReader(Reader oReader) {
    moCollectionReader.put(oReader.getName(), oReader);
  }

  /**
   * Gets a Reader object matching the name provided.
   * @param szName the name of the Reader object matching the name provided
   * @return a Reader object matching the name provided
   */
  public Reader getReader( String szName ) {
    return ( moCollectionReader.get( szName ) );
  }

  /**
   * Gets all Filter objects.
   * @return  Collection of Filter objects.
   */
  public Collection<Filter> getFilters() {
    return ( moCollectionFilter.values() );
  }

  /**
   * Adds a Filter object to the internal collection.
   * @param oFilter the Filter object to add.
   */
  public void addFilter(Filter oFilter) {
    moCollectionFilter.put(oFilter.getName(), oFilter);
  }

  /**
   * Gets a Filter object matching the name provided.
   * @param szName the name of the Filter object matching the name provided
   * @return a Filter object matching the name provided
   */
  public Filter getFilter( String szName ) {
    return ( moCollectionFilter.get( szName ) );
  }

  /**
   * Gets all Writer objects.
   * @return  Collection of Writer objects.
   */
  public Collection<Writer> getWriters() {
    return ( moCollectionWriter.values() );

//    return cloneCollection(moCollectionStrategy);
  }

  /**
   * Adds a Writer object to the internal collection.
   * @param oWriter the Writer object to add.
   */
  public void addWriter(Writer oWriter) {
    moCollectionWriter.put(oWriter.getName(), oWriter);
  }

  /**
   * Gets a Writer object matching the name provided.
   * @param szName the name of the Writer object matching the name provided
   * @return a Writer object matching the name provided
   */
  public Writer getWriter( String szName ) {
    return ( moCollectionWriter.get( szName ) );
  }

  /**
   * Returns a string representation of the object contents.
   * @return the content of this object
   */
  public String toString() {
    String newline = System.getProperty( "line.separator" );
    StringBuffer buf = new StringBuffer();

    Collection [] vArray = { getReaders(),
                            getFilters(),
                            getWriters() };

    String [] tagArray = {"Readers(s)",
                          "Filters(s)",
                          "Writers(s)"};

    int i = 0 ;
    for (Collection col: vArray) {
      buf.append( "------- " ).append( tagArray[i++] ).append( newline );

      if (!col.isEmpty()) {
        String itemType = col.getClass().getName();
        
        buf.append( "------- " ).append( itemType ).append(" defined in the SLS.xml file -------" ).
            append( newline );
        
        for(Object item: col){
          buf.append( item ).append( newline );
        }
      }
    }
    return buf.toString();
  }
}
