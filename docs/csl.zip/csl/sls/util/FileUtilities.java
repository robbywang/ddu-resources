/*
* Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
*/

package com.nortel.cdma.service.csl.sls.util;

import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.io.File;
import java.io.IOException;

import com.nortel.cdma.service.csl.lc.ebsc.EBSCLogCollector;

/**
 * The intent of this class is to provide methods related to File Management.
 */
public class FileUtilities {

  /**
   * Instance of Log4j.Logger.
   */
  final private static Logger log4jDebugLogger = Logger.getLogger(FileUtilities.class);

  /**
   * CSL Directory to create files in.
   */
    private static final String mkszCSLDirectory = "/opt/cems/log";

  /**
   * CSL filename prefix.
   */
    private static String mkszCSLFilePrefix = "dlog";

    /**
     * A static field to hold the instance of this class.
     */
    private static FileUtilities moInstance = new FileUtilities();

    /**
     * Creates an instance of this class.
     */
    public FileUtilities() {
    }

    /**
     * Get the singleton instance of the FileHelper.
     * @return FileHelper object instance
     */
    public synchronized static FileUtilities getInstance() {
        return moInstance;
    }

    /**
     * Creates a new log file. Path name is not needed, uses default path
     * @param szDirectory the name of the log to be created
     * @param szFilename the name of the log to be created
     * @return a new log file object
     */
    public File createFile(String szDirectory, String szFilename) {

        String szFullPath = szDirectory + File.separatorChar + szFilename;

        File outputFile = new File(szFullPath);

        try {
            outputFile.createNewFile();
        }
        catch (IOException e) {
            log4jDebugLogger.error("Unable to create new LogFile section. Log file already exists", e);
        }

        return ( outputFile );
    }

    /**
     * Creates a new log file. Path name is not needed, uses default path.
     * @return an archive log file object
     */
    public File createCSLArchiveFile() {
        long currTimeMillis = System.currentTimeMillis();
        Date timestamp = new Date(currTimeMillis);
        String timestampString = timestamp.toString();

        SimpleDateFormat output = new SimpleDateFormat("yyyyMMddHHmmss");

        try {
            timestampString = output.format(timestamp);
        }
        catch (Exception e) {
            log4jDebugLogger.error("Can't convert time to appropriate format", e);
        }

        String szArchiveFilename = mkszCSLFilePrefix + "." + timestampString + ".csl";

        File oFile = createFile( mkszCSLDirectory, szArchiveFilename );

        return ( oFile );
    }

    /**
     * Deletes a file.
     * @param file the file to delete
     * @throws SecurityException if could not access file or directory
     */
    public void deleteFile(File file) throws SecurityException {
        file.delete();
        log4jDebugLogger.info("CSL - FileUtilities::deleteFile() - " + file.getName() );
    }
}

