/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.xdrlite;

import com.nortel.cdma.service.csl.sls.filter.common.ParsingFilter;
import com.nortel.cdma.service.csl.sls.filter.common.DigesterConfiguration;
import com.nortel.cdma.service.csl.sls.filter.common.DatatypesDigesterConfiguration;
import com.nortel.cdma.service.csl.sls.filter.common.InputSchemaDigesterConfiguration;
import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;

// Debug logging
import org.apache.log4j.Logger;
import org.xml.sax.InputSource;

/**
 * Converts a stream of data in "XDR-Lite" format to XDR format.
 */

public class XDRLiteFilter extends ParsingFilter {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(XDRLiteFilter.class);

  /**
   *   The default name of the xdrlite configuration file.
   */
  protected  final String DEFAULT_CONFIG_FILE =
    mszDefaultfilePath + "xcf_xdrlitetoxdr_config.xml";

  /**
   * The default name of the datatypes file.
   */
  protected static final String DEFAULT_DATATYPES_MAPPING_FILE =
    mszDefaultfilePath + "datatypes_mapping.xml";

  /**
   * The default name of the input schema file, in case it cannot be
   * obtained from the configuration file.
   */
  protected static final String DEFAULT_INPUT_SCHEMA_FILE =
    mszDefaultfilePath + "xdrliteschema/streamlog_v1.xml";

  /**
   * The default name of the output schema file, in case it cannot be
   * obtained from the configuration file.
   */
  protected static final String DEFAULT_OUTPUT_SCHEMA_FILE =
    mszDefaultfilePath + "xcf_outputxdr.xml";

  /**
   * Constructs a plug-in filter.
   */
  public XDRLiteFilter() {
    super();
    mszDefault_Config = DEFAULT_CONFIG_FILE;
    mszDefault_DataType_file = DEFAULT_DATATYPES_MAPPING_FILE;
    mszDefault_input_schema = DEFAULT_INPUT_SCHEMA_FILE;
    mszDefault_Output_Schema = DEFAULT_OUTPUT_SCHEMA_FILE;
  }

  /**
   * Main method for stand-alone XDR-Lite filter.
   *
   * @param args the command line arguments
   */
  public static void main(String[] args) {

    if ( args.length < 2 ) {
      System.out.println("Usage: xdrlitefilter configfile datafile [verbose]");
    }
    else {
      boolean bVerbose = (args.length >= 3);

      XDRLiteFilter oXDRLiteFilter = new XDRLiteFilter();

      oXDRLiteFilter.runStandAlone("Stand-alone XDRLite Filter", args, bVerbose);
    }
  }

  /**
   *  Gets the digester configuration based on the input source of data typtes.
   * @param input the InputSource object which contains the datatypes definition
   * @return DigesterConfiguration
   */
  protected DigesterConfiguration getDataTypeDigesterConfig(InputSource input) {
    return new DatatypesDigesterConfiguration (input);
  }

  /**
   *  Gets the digester configuration based on the input source of input schema.
   * @param input the InputSource object which contains the input schema definition
   * @return DigesterConfiguration
   */
  protected  DigesterConfiguration getInputDigesterConfig(InputSource input) {
    return new InputSchemaDigesterConfiguration(input);
  }

  /**
   *  Gets the digester configuration based on the input source of output schema.
   * @param input the InputSource object which contains the output schema definition
   * @return DigesterConfiguration
   */
  protected DigesterConfiguration getOutputDigesterConfig(InputSource input) {
    return new OutputSchemaDigesterConfiguration(input);
  }

  /**
   * Processes the parsing results. If the data stream comes from the command-line (e.g.
   * stand-alone parser), outputs the ASCII contents to the console. Otherwise, call next
   * level of handleStream
   * @param  mOutput mOutput the ExtendableBuffer which contains the output info
   */
  protected void processResults (ExtendableBuffer mOutput) {
    if (mOutput != null) {

      // Set the record size of the output. Assumes record size is
      // in first four bytes of record.
      int recordSize = mOutput.getLength();

      mOutput.setValue(0, recordSize);

      byte []  outBytes = mOutput.toByteArray();
      int iLength   = mOutput.getLength();
      if ((outBytes != null) && (iLength > 0)) {

        if (moHashSetStreamReceivers.size() ==0) {
          log4jDebugLogger.error("No IStreamReceiver is registered. Stop sending data");
          return;
        }
        for (IStreamReceiver oStreamReceiver : moHashSetStreamReceivers) {
          oStreamReceiver.handleStream(outBytes, 0, iLength);
        }

        log4jDebugLogger.debug("Sent "+ iLength+" bytes");
      }
    }
  }

  /**
   * Set CSL log data type which is either XDRLite  or XDR.
   * @param szDataType the string value of the CSL log data type
   */
  public void setCSLDataType(String szDataType) {
    //do nothing since CSL data type is "XDRLite" by default.
  }
}
