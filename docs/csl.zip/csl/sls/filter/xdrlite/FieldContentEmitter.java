/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.xdrlite;

//Debug logging
import org.apache.log4j.Logger;
import com.nortel.cdma.service.csl.sls.filter.common.Field;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;


/**
 * An implementation of a FieldEmitter that simply outputs the
 * contents of the specified field.
 */
public class FieldContentEmitter extends FieldEmitter {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger
                  .getLogger(FieldContentEmitter.class);


  /**
   * Outputs the contents of the specified field.
   *
   * @param field   the field to be emitted.
   * @param input   the data buffer containing the current field instance
   * @return        a boolean value indicating whether anything was written
   *                to the output buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  @Override
  public boolean emit(Field field, InputBuffer input)
         throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException("Output buffer is null");
    }
    if (input == null) {
      throw new ProcessingException("Input buffer is null");
    }
    if (field == null) {
      throw new ProcessingException("Input field is null");
    }
    // Tell the field to output its contents.
    // Pass a reference to ourself so that the field can invoke
    // {@link #appendContent}, and so nested fields can hook back
    // through this emitter to be properly added to the output.
    field.emitContents(input, this);
    return true;
  }

  /**
   * Invoked after all of the fields have been processed, giving an
   * emitter the opportunity to do any required post-processing of
   * the output record.
   * @param field   the field to be emitted.
   * @param input   the data buffer containing the current field instance
   * @return false if the output should be discarded, otherwise true
   * @throws ProcessingException
   */
  public boolean postProcess(Field field, InputBuffer input)
         throws ProcessingException {

    // Default does nothing.
    return true;
  }

  /**
   * Append an array of bytes to the output stream.
   *
   * @param bytes       the byte array to be appended to the end of the buffer
   * @param srcOffset   offset within the array to the start of the data to be appended
   * @param inputSize      the length (in bytes) of the data in the byte array to be appended
   * @param padLeft     if true, add any required padding to the left of the data,
   *                    otherwise add it on the right
   */
  @Override
  public void appendContent(byte[] bytes, int srcOffset, int inputSize, boolean padLeft) {

    if ((bytes != null) && (buffer != null))  {
      try {

        buffer.append(bytes, srcOffset, inputSize);
      }
      //catch (BufferUnderflowException e) {
      catch (Exception e) {
        insufficientDataError(bytes.length, srcOffset, inputSize);
      }
    }
  }

  /**
   * Append the contents of a field to the output stream. Uses the input buffer as
   * the data source.
   *
   * @param srcOffset   offset within the array to the start of the data to be appended
   * @param inputSize      the length (in bytes) of the data in the byte array to be appended
   * @param padLeft     if true, add any required padding to the left of the data,
   *                    otherwise add it on the right
   */
  @Override
  public void appendContent(int srcOffset, int inputSize, boolean padLeft) {

    if ((buffer != null) && (inputBufferContents != null)) {
      appendContent(inputBufferContents, srcOffset, inputSize, padLeft);
    }
  }

  /**
   * Logs an error message indicating that there is insufficient data provided
   * to satisfy the input schema.
   *
   * @param size the size of the input data
   * @param offset the offset of the start of the field
   * @param fieldSize the size of the field
   */
  protected void insufficientDataError(int size, int offset, int fieldSize) {

    log4jDebugLogger.error("Insufficient data; size='"+ size
                           + "' offset='" + offset
                           + "' fieldSize='" + fieldSize + "'");
  }
}
