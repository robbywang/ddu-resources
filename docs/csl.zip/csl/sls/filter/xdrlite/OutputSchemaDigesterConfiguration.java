package com.nortel.cdma.service.csl.sls.filter.xdrlite;
/**
 * <p>Copyright (C) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */
import org.apache.commons.digester.Digester;
import org.xml.sax.InputSource;
import com.nortel.cdma.service.csl.sls.filter.common.DigesterConfiguration;

/**
 * A configuration for the Apache Commons Digester appropriate for
 * parsing the output schema file.
 */
public class OutputSchemaDigesterConfiguration extends DigesterConfiguration {

  /**
   * Constructor.
   */
  public OutputSchemaDigesterConfiguration() {

    super();
  }

  /**
   * Constructor that allows a parsing rules XML file to
   * be specified for configuring the digester.
   * @param parsingRules an XML file containing digester
   *        parsing rules
   */
  public OutputSchemaDigesterConfiguration(InputSource parsingRules) {

    super(parsingRules);
  }

  /**
   * Creates and configures a Digester with parsing rules appropriate
   * for parsing the XDRLiteConverter datatypes file. The XML version
   * of these rules is as follows: (replace '?' with '*')
   *
   *   <digester-rules>
   *      <pattern value="?/field">
   *         <object-create-rule classname=
   *          "com.nortel.cdma.service.csl.sls.filter.xdrlite.EmitterAttributes"/>
   *         <set-next-rule methodname="createEmitter"/>
   *         <!-- for attributes -->
   *         <set-properties-rule/>
   *         <pattern value='emitter'>
   *            <bean-property-setter-rule/>
   *         </pattern>
   *         <pattern value='alignment'>
   *            <call-method-rule methodname='setAlignment' paramcount='1'/>
   *            <call-param-rule paramnumber='0'/>
   *         </pattern>
   *         <pattern value='priority'>
   *            <call-method-rule methodname='setPriority' paramcount='1'/>
   *            <call-param-rule paramnumber='0'/>
   *         </pattern>
   *      </pattern>
   *   </digester-rules>
   *
   * @return a configured Digester
   */
  protected Digester configureDigester() {

    Digester newDigester = super.configureDigester();

    if (newDigester != null) {
      if (parsingRulesFile == null) {
        // Configure default parsing rules.
        newDigester.addObjectCreate("*/field",
        "com.nortel.cdma.service.csl.sls.filter.common.EmitterAttributes");
        newDigester.addSetNext("*/field", "createEmitter");
        newDigester.addSetProperties("*/field"); // for attribute 'bitref'
        newDigester.addBeanPropertySetter("*/field/emitter");
        newDigester.addCallMethod("*/field/alignment", "setAlignment", 1);
        newDigester.addCallParam("*/field/alignment", 0);
        newDigester.addCallMethod("*/field/priority", "setPriority", 1);
        newDigester.addCallParam("*/field/priority", 0);
      }
    }

    return newDigester;
  }
}
