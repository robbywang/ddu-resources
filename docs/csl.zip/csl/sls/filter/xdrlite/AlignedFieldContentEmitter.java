/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.xdrlite;

//Debug logging
import org.apache.log4j.Logger;
import com.nortel.cdma.service.csl.sls.filter.common.EmitterAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.BufferUnderflowException;

/**
 * An implementation of a FieldEmitter that outputs the contents of the specified
 * field, padded with empty bytes as necessary in order to maintin a specified
 * field alignment.
 * @see #alignment
 */
public class AlignedFieldContentEmitter extends FieldContentEmitter {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(AlignedFieldContentEmitter.class);

  /**
   * Determines the output size of the field. When outputting the contents
   * of a field, the size of the field must be a multiple of the alignment
   * value; i.e. an alignment of 4 means that all fields will start and end
   * on 4-byte boundries.
   */
  private int    alignment = 1;

  /**
   * The value to use as a pad byte when the data needs to be padded to
   * satisfy the alignment. Stored as a byte because Java doesn't have an
   * 'unsignedByte' type.
   */
  private byte   padValue = 0;

  /**
   * Sets various attributes.
   *
   * @param attributes an object containing the attributes collected from
   *          the XML configuration file
   */
  @Override
  public void setAttributes(EmitterAttributes attributes) {

    if (attributes != null) {
      alignment = attributes.getAlignment();

      if ((alignment < 1) || (alignment > 8 )) {
        log4jDebugLogger.error("Invalid alignment value: '" + alignment
                             + "', must be greater than 0 and less than 9");
        alignment = 1;
      }
      padValue  = attributes.getPadValue();
    }
  }

  /**
   * Append the contents of a field to the output stream.
   *
   * @param bytes the byte array to be appended to the end of the buffer
   * @param srcOffset offset within the array to the start of the data to
   *          be appended
   * @param inputSize the length (in bytes) of the data in the byte array
   *          to be appended
   * @param padLeft if true, add any required padding to the left of the
   *          data, otherwise add it on the right
   *
   * @todo  Could eliminate the divide operation and speed this method up by
   *        using a lookup table for typical data sizes and alignments.
   */
  public void appendContent(byte[] bytes, int srcOffset, int inputSize, boolean padLeft) {

    if ((bytes != null) && (buffer != null)) {
      // Determine whether any padding is required to satisfy the alignment setting.

      try {
        if (alignment > 1) {
          int outputSize = 0;
          int remainder  = inputSize % alignment;
          if (remainder > 0) {
            outputSize = inputSize + (alignment - (inputSize % alignment));
          }
          else {
            outputSize = inputSize;
          }
          buffer.append(bytes, srcOffset, inputSize, outputSize, padValue, padLeft);
        }
        else {
          buffer.append(bytes, srcOffset, inputSize);
        }
      }
      catch (BufferUnderflowException e) {
        insufficientDataError(bytes.length, srcOffset, inputSize);
      }
    }
  }
}
