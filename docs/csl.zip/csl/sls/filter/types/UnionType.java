/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import java.util.Iterator;

import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;
import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.ParsingException;
import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.Field;
import com.nortel.cdma.service.csl.sls.filter.common.UnionAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.FieldList;
//Debug logging.
import org.apache.log4j.Logger;

/**
 * A data type that selects between a number of different field definitions
 * based on the value of another field in the data stream. The field whose
 * value determines the "state" of this data type is referred to as the
 * "discriminant".
 * The various possible fields that can be selected
 * depending on the discriminant value are referred to as the union "cases".
 */
public class UnionType extends DataType{

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(UnionType.class);

  /**
   * The field whose value determines which union case is selected.
   */
  private Field  discriminant;

  /**
   * The union cases. This is a {@link FieldList} object where the names are
   * referenced by their union case value rather than by name.
   */
  private FieldList cases = null;

  /**
   * The currently selected case, based on the value of the discriminant field
   * in the input data stream currently being processed.
   */
  private Field currentCase = null;

  /**
   * The string that identifies the default case in a union.
   */
  private static final String DEFAULT_CASE_SELECTOR = "default";

  /**
   * Indicates whether or not the discriminant field should be output along
   * with the union case field.
   */
  private boolean outputDiscriminant = true;

  /**
   * The string that indicates that the discriminant should not be output.
   */
  private static final String OD_OFF_SELECTOR = "no";

  /**
   * The string that indicates that the discriminant should be output.
   */
  private static final String OD_ON_SELECTOR = "yes";

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String UNION_LABEL = "union";

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String DISCRIMINANT_LABEL = " discriminant=";

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String OUTPUT_DISCRIMINANT_LABEL = " outputdiscriminant=";

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String CASE_LABEL = "case";

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String VALUE_LABEL = " value=";


  /**
   * Constructs a UnionType with no attributes set.
   *
   */
  public UnionType() {
    super();
  }

  /**
   * Sets the name, discriminant, and cases attributes, based on the values
   * obtained from the UnionAttributes object (ultimately from the input schema).
   *
   * @param attributes  a {@link UnionAttributes} object containing the attributes
   *                    specified in the input schema
   * @return            true if successful, otherwise false
   */
  @Override
    public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result;

    if ( (attributesNotNull(attributes))
      && (super.setAttributes(attributes))
      && (attributes instanceof UnionAttributes) )  {

      UnionAttributes unionAttributes = (UnionAttributes) attributes;

      discriminant = unionAttributes.getDiscriminantField();

      if ((discriminant == null) || (!discriminant.isNumeric())) {
        log4jDebugLogger.error(errorString("Union field definition invalid discriminant"));
        result = false;
      }

      String od = unionAttributes.getOutputdiscriminant();

      if (od != null) {
        if (od.equalsIgnoreCase(OD_OFF_SELECTOR)) {
          outputDiscriminant = false;
        }
        else if (od.equalsIgnoreCase(OD_ON_SELECTOR)) {
          // outputDiscriminant = true;   // default setting
        }
        else {
          log4jDebugLogger.error(errorString("Union field definition invalid outputDiscriminant setting")
            + " outputDiscriminant='" + od + "'");
          result = false;
        }
      }
      cases = unionAttributes.getSubFields();
      result = true;
    }
    else {
      result = false;
    }
    return result;
  }

  /**
   * Creates a new instance of this datatype with a unique value mapping derived
   * from the field definition.
   *
   * @param attributes  an object containing the attributes
   *                    needed to define the data type
   * @return            the newly defined DataType object
   */
  @Override
    public UnionType cloneWithNewAttributes(DataTypeAttributes attributes) {

    UnionType result = (UnionType) this.clone();

    if ( (attributes == null)
      || (result == null)
      || (!result.setAttributes(attributes)) ) {

      result = new UnionType();
    }
    return result;
  }

  /**
   * Updates the discriminant reference after it has been cloned.
   *
   * @param list  the list of cloned fields
   */
  public void updateReferences(FieldList list) {

    if (list == null) {
      log4jDebugLogger.error("FieldList is null");
    }
    else {

      String discriminantName = null;

      if ( (discriminant == null)
        ||  ((discriminantName = discriminant.getName()) == null) ) {

        log4jDebugLogger.error(errorString("Union field invalid discriminant"));
      }
      else {
        discriminant = list.getField(discriminantName);

        if (discriminant == null) {
          log4jDebugLogger.error(errorString("Failed to update discriminant"));
        }
      }
    }
  }

  /**
   * Marks the location of the field associated with this data type
   * in the input buffer. Override the default behaviour because we have to
   * determine which union case is active.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return        the offset of the field in the buffer
   * @throws        ProcessingException if the field is corrupt
   * @throws        ParsingException if unable to parse the input data stream
   */
  public int markFieldLocationInBuffer(InputBuffer buffer)
    throws ParsingException, ProcessingException {

    int offset = 0;

    if (bufferNotNull(buffer)) {

      // Evaluate discriminant to determine which field to expect from input stream.
      if (discriminant == null) {
        throw new ProcessingException(errorString("Union field missing discriminant"));
      }

      if (cases == null) {
        throw new ProcessingException(errorString("Union field missing cases"));
      }

      int discriminantValue = buffer.getValue(discriminant);

      currentCase = cases.getField(String.valueOf(discriminantValue), DEFAULT_CASE_SELECTOR);

      if (currentCase == null) {
        throw new ParsingException(errorString("No union case matching discriminant value")
          + "value=" + discriminantValue);
      }

      offset = currentCase.markFieldLocationInBuffer(buffer);
    }
    return offset;
  }

  /**
   * Outputs the contents of the field this datatype is associated with. Override the
   * default behaviour to output both the discriminant and the current case.
   *
   * @param buffer      the input data stream
   * @param offset      the offset of the field in the input data stream
   * @param emitter     the object that determines what aspect of the field to output
   * @throws        ProcessingException if unable to parse the input data stream
   */
  public void emitContents(InputBuffer buffer, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException(errorString(NULL_BUFFER_MSG));
    }
    if (emitter == null) {
      throw new ProcessingException(errorString(NULL_EMITTER_MSG));
    }

    if ((discriminant != null) && outputDiscriminant) {
      emitter.emit(discriminant, buffer);
    }

    if (currentCase != null) {
      emitter.emit(currentCase, buffer);
    }
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  public String getXdrDefinition(int level) {

    StringBuffer sb = new StringBuffer();

    if (cases != null) {
      Iterator<String> caseIterator = cases.mapIterator();

      while (caseIterator.hasNext()) {

        String key   = caseIterator.next();

        if (key != null) {

          Field  field = cases.getField(key);

          if (field != null) {

            String label = CASE_LABEL + VALUE_LABEL + key.toString();

            sb.append(TextUtil.getDefinitionOpenString(level + 1, label) + TextUtil.NEW_LINE
              + field.getXdrDefinition(level + 2)
              + TextUtil.getDefinitionCloseString(level + 1, CASE_LABEL));
          }
        }
      }
    }

    return sb.toString();
  }

  /**
   * Returns a string to be used as an attribute of the field
   * definition when generating a string representation of the
   * structure of this object.
   *
   * @return A string containing the attribute name and value
   */
  public String getXdrDefinitionAttributes() {

    String s = DISCRIMINANT_LABEL;

    if (discriminant != null) {
      s += discriminant.getName();
    }

    return s;
  }


  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                 int offset, int level) throws ProcessingException {

    String result = TextUtil.STRING_TERMINATOR;

    if (buffer != null) {

      if (discriminant != null) {
        result = " disc='" + discriminant.getName() + "'";

        if (isInBuffer) {

          int discriminantOffset = discriminant.getInputOffset();
          String sOffset = (Integer.toHexString(discriminantOffset)).toUpperCase();

          result += " offset=" + sOffset;
        }
      }

      if (currentCase != null) {
        result += TextUtil.NEW_LINE;

        String sField = currentCase.getFieldValue(buffer, isInBuffer, level + 1);
        if (sField != null) {
          result += sField;
        }
      }
    }
    return result;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer,
                                      int offset, int level, String format)  throws ProcessingException {
    StringBuffer result = sb;

    if (result != null) {

      if (currentCase != null) {
        DataType oType = currentCase.getType();
        if (!(oType instanceof VoidType)) {
          //add the field value
          result.append(currentCase.getASCIIFieldContents(buffer, level));
        }
      }
    }

    return result;
  }
}