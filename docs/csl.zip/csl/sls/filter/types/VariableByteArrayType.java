/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.ParsingException;
import com.nortel.cdma.service.csl.sls.filter.common.FieldList;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.FieldAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;

//Debug logging.
import org.apache.log4j.Logger;

/**
 * A variable-size array of bytes. The size of the array is specified by
 * a header field in the data stream.
 */
public class VariableByteArrayType extends ArrayType {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(VariableByteArrayType.class);

  /**
   * The maximum expected number of array elements.
   */
  protected int   maxSize = 0;

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String VARIABLEBYTEARRAY_LABEL = "variableByteArray";


  /**
   * Constructs a VariableByteArray. Before use, the lengthHeader field
   * should be set using the {@link #setAttributes} method.
   */
  public VariableByteArrayType() {
    super();
  }

  /**
   * Sets the lengthHeader of the array based on the information specified
   * in the field attributes object.
   *
   * @param attributes a {@link FieldAttributes} object containing the
   *          attributes needed to define the data type
   * @return true if successful, otherwise false
   */
  @Override
  public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result = false;

    if ( (attributesNotNull(attributes))
      && (super.setAttributes(attributes)) ) {

      // The array size specifies the maximum possible size of the array.
      maxSize = getArraySize(attributes, true);

      if (maxSize > 0) {

        // The length header for a variable array is the first
        // field in the subfields of the attributes object.
        FieldList attributesSubFields = attributes.getSubFields();

        if ((attributesSubFields == null)
          || ((lengthHeader = attributesSubFields.getFirstField()) == null)) {

          log4jDebugLogger.error(errorString("Field definition no length header value defined"));
        }
        else {
          if (!lengthHeader.isNumeric()) {

            log4jDebugLogger.error(errorString("Field definition invalid length header specified"));
          }
          else {
            result = true;
          }
        }
      }
    }
    return result;
  }

  /**
   * Creates a new instance of this datatype with the lengthHeader derived
   * from the field definition.
   *
   * @param attributes  a {@link DataTypeAttributes} object containing the attributes
   *                    needed to define the data type
   * @return            the newly defined DataType object
   */
  @Override
  public VariableByteArrayType cloneWithNewAttributes(DataTypeAttributes attributes) {

    VariableByteArrayType result;

    if (lengthHeader != null) {
      result = this;
    }
    else {
      // This is a generic type that needs to be refined.
      result = this.clone();

      if ( (attributes == null)
        || (result == null)
        || (!result.setAttributes(attributes)) ) {

        result = new VariableByteArrayType();
      }
    }
    return result;
  }

  /**
   * Returns a clone of this datatype. Override superclass in order
   * to clone length header field as well.
   *
   * @return    an object that is a clone of this one
   */
  @Override
  public VariableByteArrayType clone()  {

    VariableByteArrayType theClone = (VariableByteArrayType) super.clone();

    if ( (theClone != null)
      && (lengthHeader != null) ) {
      theClone.lengthHeader = lengthHeader.clone();
    }
    return theClone;
  }

  /**
   * Marks the location of the field associated with this data type
   * in the input buffer.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return        the offset of the field in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  @Override
  public int markFieldLocationInBuffer(InputBuffer buffer) throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException(errorString(NULL_BUFFER_MSG));
    }

    if (lengthHeader == null) {
      throw new ProcessingException(errorString("Length header is null"));
    }

    // First mark the length header.
    int offset = lengthHeader.markFieldLocationInBuffer(buffer);

    // And then mark the array itself.
    arraySize = lengthHeader.getValue(buffer);

    if (arraySize > maxSize) {
      // Throw a ParsingException, we might just be out of sync.
      throw new ParsingException(errorString("Array size exceeds maximum")
        +" maximum size='" + maxSize + "'");
    }

    contentOffset = markArrayContents(buffer);

    return offset;
  }

  /**
   * Marks the location of the array contents in the input buffer.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return  the offset of the contents in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  protected int markArrayContents(InputBuffer buffer)
    throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException(errorString(NULL_BUFFER_MSG));
    }

    int alignment = buffer.getFieldAlignment();

    arraySize = adjustFieldSizeToAlign(arraySize, alignment);

    int offset = buffer.markFieldLocation(arraySize);

    return offset;
  }

  /**
   * Outputs the contents of the field this datatype is associated with. In
   * the case of a VariableByteArray, output the length header and then
   * output the body of the array.
   *
   * @param buffer the input data stream
   * @param offset the offset of the field in the input data stream
   * @param emitter the object that determines what aspect of the field to
   *          output
   * @throws  ProcessingException if unable to get the value from the
   *          input data stream.
   */
  @Override
  public void emitContents(InputBuffer buffer, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if ((bufferNotNull(buffer)) && (emitterNotNull(emitter))) {

      // Output the length header.
      emitter.emit(lengthHeader, buffer);

      // Output the array elements.
      if (arraySize > 0) {
        emitter.appendContent(contentOffset, arraySize, padLeft);
      }
    }
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  @Override
    public String getXdrDefinition(int level) {

    String s = getDatatypeString(level, VARIABLEBYTEARRAY_LABEL)
      + getLengthHeaderDefinitionAsString(level);

    return s;
  }

  /**
   * Returns a string to be used as an attribute of the field
   * definition when generating a string representation of the
   * structure of this object.
   *
   * @return A string containing the attribute name and value
   */
  @Override
  public String getXdrDefinitionAttributes() {

    String s = MAXLENGTH_LABEL + maxSize;

    return s;
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
  public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                 int offset, int level)
    throws ProcessingException {

    String result = null;

    if (buffer != null) {

      if (lengthHeader != null) {

        String sLengthHdr = lengthHeader.getFieldValue(buffer, isInBuffer, level + 1);
        result = TextUtil.NEW_LINE + sLengthHdr;
      }
    }
    return result;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer, int offset, int level, String format)
    throws ProcessingException {
    if (lengthHeader != null) {
      String szValue = lengthHeader.getASCIIFieldContents(buffer, level + 1);
      if (szValue != null) {
        sb.append(TextUtil.NEW_LINE);
        sb.append(szValue);
        if (arraySize > 0) {
          //append the array contents
          sb.append(TextUtil.NEW_LINE);
          sb.append(TextUtil.getIndent(level + 1));
          sb.append("value(s) = ");
          sb.append(TextUtil.getValueAsString(buffer, contentOffset, arraySize, format));
        }
      }
    }
    return sb;
  }

  /**
   *  Returns the maxisum size of the array.
   * @return the integer value of  maxisum size of the array
   */
  protected int getMaxArraySize () {
    return maxSize;
  }
}
