/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;

/**
 * A signed integer data type.
 */
public class IntType extends UintType {

  /**
   * Constructs a signed integer data type with default attribute
   * settings.
   */
  public IntType () {
    super();
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer, int offset, int level, String format)
    throws ProcessingException {

    StringBuffer defaultBf = new StringBuffer();

    if ((sb != null) && (buffer != null)) {
      defaultBf = sb;
      String fieldValue = null;

      if (format != null) {
        fieldValue = TextUtil.getValueAsString(buffer, offset, inputSize, format, true);
      }
      else {
        if (fieldValue == null) {  //hex by default
          fieldValue = TextUtil.getValueAsString(buffer, offset, inputSize, "hex");
        }
      }
      defaultBf.append(" = " + fieldValue);
    }
    return defaultBf;
  }

}
