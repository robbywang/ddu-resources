/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.Field;
import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.FieldList;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;

import org.apache.log4j.Logger;

/**
 * A datatype that consists of a collection of subfields which may be of
 * various data types.
 */
public class StructType extends DataType{

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(StructType.class);

  /**
   * The list of subfields.
   */
  protected FieldList subFields = null;

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String STRUCT_LABEL = "struct";

  /**
   * String constant of the field name:Number of digits.
   */
  private static final String NUM_DIGITS = "Number of digits";


  /**
   * String constant of the field name: IMSI.
   */
  private static final String IMSI = "IMSI";
  /**
   * Constructs a StructType with no subfields defined.
   */
  public StructType() {
    subFields = new FieldList();
    padLeft = false;
  }

  /**
   * Sets the subfields of the struct.
   *
   * @param attributes  a {@link DataTypeAttributes} object containing the attributes
   *                    needed to define the data type
   * @return            true if successful, otherwise false
   */
  @Override
    public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result;

    if (attributesNotNull(attributes) && (super.setAttributes(attributes))) {

      FieldList attributesSubFields = attributes.getSubFields();

      if (attributesSubFields != null)  {
        if ((subFields != null) && (subFields.size() < 1)) {
          subFields = attributesSubFields;
        }
      }

      if ((subFields != null) && (!subFields.isValid())) {
        log4jDebugLogger.error(errorString("Struct field definition invalid"));
        result = false;
      }
      else {
        result = true;
      }
    }
    else {
      result = false;
    }
    return result;
  }

  /**
   * Creates a new instance of this datatype. If the base type is a generic struct
   * (i.e. name equals <em>struct</em>) then it is refined using the supplied attributes.
   * Otherwise this is a case where a previously defined struct is being reused in the
   * definition of a new field, so we need to simply clone the struct (and subfields).
   *
   * @param attributes  a {@link DataTypeAttributes} object containing the attributes
   *                    needed to define the data type
   * @return            the newly defined DataType object
   */
  @Override
    public StructType cloneWithNewAttributes(DataTypeAttributes attributes) {

    if (attributesNotNull(attributes)) {

      StructType newType = this.clone();

      if ( (newType != null)
        &&  (newType.setAttributes(attributes)) ) {
        return newType;
      }
    }
    return new StructType();
  }

  /**
   * Returns a clone of this datatype. Any and all subfields are cloned as well.
   *
   * @return    an object that is a clone of this one
   */
  @Override
    public StructType clone() {

    StructType theClone = (StructType) super.clone();

    if (theClone != null) {
      theClone.subFields = subFields.clone();
    }
    return theClone;
  }

  /**
   * Marks the location of each of the subfields in the input buffer.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return        the offset of the struct in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  @Override
    public int markFieldLocationInBuffer(InputBuffer buffer) throws ProcessingException {

    int offset = 0;

    if (bufferNotNull(buffer)) {

      // Mark the sub fields
      for (Field field : subFields) {
        if (field != null) {
          field.markFieldLocationInBuffer(buffer);
        }
      }
      // The offset of the struct is the offset of the first field.
      Field firstField = subFields.getFirstField();
      if (firstField != null) {
        offset = firstField.getInputOffset();
      }
    }
    return offset;
  }

  /**
   * Returns the value of a field of this datatype at a specific location in
   * a data stream. Override to throw an exception, since it doesn't make sense
   * for a StructType.
   *
   * @param buffer  the input data stream from which to extract the field value
   * @param offset  the location of the field in the data stream
   * @return        the integer value of the field at the specified location
   * @throws        ProcessingException if unable to parse the input data stream
   */
  @Override
    public int getValue(InputBuffer buffer, int offset)
    throws ProcessingException {
    // Doesn't make sense for a struct.
    throw new ProcessingException(errorString("Attempt to getValue on a struct"));
  }

  /**
   * Returns the field associated with a given field name.
   *
   * @param fieldName   the name of the requested field
   * @return            the requested field, or null if it does not exist
   */
  @Override
    public Field getField(String fieldName) {

    return subFields.getField(fieldName);
  }

  /**
   * Outputs the contents of each of the subfields.
   *
   * @param buffer      the input data stream
   * @param offset      the offset of the field in the input data stream
   * @param emitter     the object that determines what aspect of the field to output
   * @throws        ProcessingException if unable to parse the input data stream
   */
  @Override
    public void emitContents(InputBuffer buffer, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if ((bufferNotNull(buffer)) && (emitterNotNull(emitter))) {

      emitSubFields(buffer, offset, emitter);
    }
  }

  /**
   * Outputs the contents of each of the subfields.
   *
   * @param buffer      the input data stream
   * @param offset      the offset of the field in the input data stream
   * @param emitter     the object that determines what aspect of the field to output
   * @throws        ProcessingException if unable to parse the input data stream
   */
  protected void emitSubFields(InputBuffer buffer, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if ((bufferNotNull(buffer)) && (emitterNotNull(emitter))) {

      for (Field field : subFields) {
        emitter.emit(field, buffer);
      }
    }
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  @Override
    public String getXdrDefinition(int level) {

    StringBuffer sb = new StringBuffer();

    sb.append(getDatatypeString(level, STRUCT_LABEL));

    for (Field field : subFields) {
      if (field != null) {
        sb.append(field.getXdrDefinition(level));
      }
    }
    return sb.toString();
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is in put data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
    public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                   int offset, int level)
    throws ProcessingException {

    String result = null;

    if (buffer != null) {
      result = getSubfieldsAsString(buffer, isInBuffer, level);
    }
    return result;
  }

  /**
   * Returns the value of the subfields formatted as a text string for
   * debugging.
   *
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  protected String getSubfieldsAsString(ExtendableBuffer buffer,
                                        boolean isInBuffer, int level)
    throws ProcessingException {

    String result = "";

    if (buffer != null) {

      for (Field field : subFields) {

        if (field != null) {
          result +="\n";

          String sField = field.getFieldValue(buffer, isInBuffer, level + 1);
          if (sField != null) {
            result += sField;
          }

          if (result.endsWith(TextUtil.STRING_TERMINATOR)) {
            break;
          }
        }
      }
    }
    return result;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer,
                                      int offset, int level, String format)
    throws ProcessingException {

    StringBuffer sbResults = new StringBuffer("");
    if (sb == null) {
      log4jDebugLogger.error("got null StringBuffer");
      return sbResults;
    }
    sbResults = sb;
    if (buffer == null) {
      log4jDebugLogger.error("got null InputBuffer");
      return sbResults;
    }

    if (name.equalsIgnoreCase(IMSI)) {
      sbResults = getIMSIASCIIContent(sbResults, buffer, level, format);
    }
    else {
      if (subFields != null) {
        for (Field field : subFields) {
          if (field != null) {

            String sField = field.getASCIIFieldContents(buffer, level +1 );
            if (sField.endsWith(TextUtil.STRING_TERMINATOR)) {
              break;
            }

            if (sField.length() == 0) {
              continue;
            }
            sbResults.append(TextUtil.NEW_LINE);
            sbResults.append(sField);
          }
        }
      }
    }
    return sbResults;
  }

  /**
   * Return IMSI contends which contain number of digits, IMSI length and array contents.
   * @param sb the StringBuffer object which contains the ASCII results
   * @param buffer the InputBuffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return IMSI contends
   * @throws ProcessingException
   */
  private StringBuffer getIMSIASCIIContent(StringBuffer sb, InputBuffer buffer,
                                           int level, String format)
    throws ProcessingException {

    int iNumDigits = 0;
    if (subFields != null) {
      for (Field field : subFields) {
        if (field != null) {
          String szName = field.getName();
          if (szName == null) {
            throw new ProcessingException("got null field name");
          }
          sb.append(TextUtil.NEW_LINE);
          sb.append(TextUtil.getIndent(level +1));
          if (szName.equalsIgnoreCase(NUM_DIGITS)) {
            int iValue = field.getValue(buffer);
            iNumDigits = iValue;
            sb.append(szName + " = " + iValue);
          }
          else {
            sb.append(szName + TextUtil.NEW_LINE);
            DataType mType = field.getType();
            format = field.getOutputformat();

            if (mType instanceof VariableByteArrayType) {
              VariableByteArrayType vbArray = (VariableByteArrayType)mType;
              Field mLengthHeader = vbArray.getLengthHeader();

              if (mLengthHeader == null) {
                throw new ProcessingException ("Got null LengthHeader field from IMSI VariableByteArrayType");
              }

              String szField = mLengthHeader.getASCIIFieldContents(buffer, level + 2 );
              sb.append(szField);
              sb.append(TextUtil.NEW_LINE);
              sb.append(TextUtil.getIndent(level + 2));

              //add variable array contents
              sb.append("value(s) = ");
              sb.append(getIMSIArrayContents (buffer, iNumDigits, vbArray, format));

            }
          }
        }
      }
    }
    return sb;
  }

  /**
   * In order to retrieve the IMSI array contents, we need to consider 3 integer values which
   * are all defined in the schema file: Number of digits, IMSI_Length and maximum value of
   * IMSI variable array size. The algorithm is as follows
   *   (1) Use IMSI_Length to get ByteArray contents unless IMSI_Length is greater than max array size.
   *       In that case, log the error and use max array size to retrieve the array contends
   *   (2) If Number_of_digits is less than IMSI_Length,  we need to refine the IMSI array generated in (1).
   *       Only ouput the IMSI data array which matches the size defined in Number_of_digits.
   *
   * @param buffer the InputBuffer
   * @param iNumDigits the value of Number of Digits field
   * @param vbArray the related
   * @param format the output format
   * @return retrieve the IMSI array contents
   * @throws ProcessingException
   */
  private String getIMSIArrayContents (InputBuffer buffer,
                                       int iNumDigits, 
                                       VariableByteArrayType vbArray, 
                                       String format) throws ProcessingException {

    int iMaxSize = vbArray.getMaxArraySize();
    int iArraySize = vbArray.getMaxArraySize();
    int iContentOffset = vbArray.getContentOffset();
    int iActualArraySize = iArraySize;

    if (iArraySize > iMaxSize) {
      log4jDebugLogger.error("IMSI variable array length is greater than the max array size " +
        iMaxSize);
      iActualArraySize = iMaxSize;
    }
    String szResult = TextUtil.getValueAsString(buffer, iContentOffset , iActualArraySize, format);
    int iDifference = iActualArraySize *2 - iNumDigits;
    if (iDifference < 0) {
      log4jDebugLogger.error("Number of digits is greater than the variable array size " +
        iActualArraySize);
    }
    //only re-generate the output if iNumDigits is less than  iActualArraySize
    else if (iDifference > 0) {
      szResult = szResult.trim();
      int iSize = szResult.length();
      try {
        szResult = szResult.substring(0, szResult.length() - iDifference );
      }
      catch (IndexOutOfBoundsException  e) {
        throw new ProcessingException ("Unable to get IMSI contents: original result string size = " + iSize +
          ", NumOfDigits = " + iNumDigits + ", IMSI_Length = " + iActualArraySize);
      }
    }
    return szResult;
  }
}

