/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;
import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.Field;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.ValueMap;
import com.nortel.cdma.service.csl.sls.filter.common.FieldList;

//Debug logging
import org.apache.log4j.Logger;

/**
 * Interprets a single byte as up to 8 boolean subfields of type
 * {@link BitType}, which are referenced by {@link UnionType}s as boolean
 * discriminants.
 */
public class BitmapType extends StructType{

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(BitmapType.class);

  /**
   * Constructs an empty BitmapType object.
   */
  public BitmapType() {
    super();
  }

  /**
   * Sets the attributes of the data type based on information derived from an
   * attributes object.
   *
   * @param attributes  an object containing the attributes
   *                    needed to define the data type
   * @return            true if successful, otherwise false
   */
  @Override
    public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result = false;

    if (attributes == null) {
      logNullAttributes();
    }
    else if (super.setAttributes(attributes)) {

      ValueMap mapping = attributes.getMapping();

      if (mapping != null) {
        if (!mapping.isValid()) {
          log4jDebugLogger.error(errorString("Bitmap definition has invalid values"));
        }
        else {
          // Define a separate subfield corresponding to each bit in the bitmap.
          subFields = new FieldList();
          BitType bit      = null;
          Field   bitField = null;
          int     value    = 0;
          try {
            for (String key : mapping) {
              value = mapping.getValue(key);
              bit = new BitType();
              bit.setMask(value);
              bitField = new Field(bit, name+"."+key);
              subFields.addField(key, bitField);
            }
            result = true;
          }
          catch (IllegalArgumentException e) {
            log4jDebugLogger.error(errorString("Bitmap definition has invalid bit mask"));
          }
        }
      }
      setInputSize(attributes);

      if (inputSize == INVALID_INPUTSIZE) {
        result = false;
      }
    }
    return result;
  }

  /**
   * Creates a new instance of this datatype with a unique value mapping derived
   * from the field definition.
   *
   * @param attributes  a {@link DataTypeAttributes} object containing the attributes
   *                    needed to define the data type
   * @return            the newly defined DataType object
   */
  @Override
    public BitmapType cloneWithNewAttributes(DataTypeAttributes attributes) {

    BitmapType result;

    if (subFields.size() > 0) {
      result = this;
    }
    else {
      // This is a generic type that needs to be refined.
      result = (BitmapType) this.clone();

      if ( (attributes == null)
        || (result == null)
        || (!result.setAttributes(attributes)) ) {

        result = new BitmapType();
      }
    }
    return result;
  }

  /**
   * Marks the location of the field associated with this data type
   * in the input buffer. Override the default behaviour because we have a
   * series of subfields to mark.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return        the offset of the field in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  public int markFieldLocationInBuffer(InputBuffer buffer) throws ProcessingException {

    int offset = 0;

    if (bufferNotNull(buffer)) {

      // Mark the sub fields (bit fields).
      for (Field field : subFields) {
        field.markFieldLocationInBuffer(buffer);
      }
      offset = buffer.markFieldLocation(inputSize);
    }
    return offset;
  }

  /**
   * Outputs the contents of the field this datatype is associated with. Override the
   * default behaviour so that nothing is output. The individual flags will be output as
   * union discriminant fields.
   *
   * @param in          the input data stream
   * @param offset      the offset of the field in the input data stream
   * @param emitter     the object that determines what aspect of the field to output
   *                    Subclasses that override this method should invoke emitter.write
   *                    to output subfields
   * @throws  ProcessingException if invalid parameters specified
   */
  public void emitContents(InputBuffer in, int offset, FieldEmitter emitter)
    throws ProcessingException {
    // Do nothing. We don't emit a bitmap. The individual bit flags will be output as
    // union discriminant fields.
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  public String getXdrDefinition(int level) {

    // Bitmaps are not included in XDR schema.
    // Override superclass in order to return nothing.
    return "";
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                 int offset, int level)
    throws ProcessingException {

    String result = null;

    // Note: a bitmap does not exist in the outputbecause the individual bits
    // are output as separate union discriminant fields.

    if (isInBuffer && (buffer != null)) {

      result = TextUtil.getValueAsHexString(buffer, offset, inputSize);
      result += super.getValueAsString(buffer, isInBuffer, offset, level);
    }
    return result;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer,
                                      int offset, int level, String format)
    throws ProcessingException {
    StringBuffer sbResults = new StringBuffer("");
    if ((sb != null) && (buffer != null)) {
      //display overal bitamp flag
      sb.append(" = ");
      sb.append(TextUtil.getValueAsString(buffer, offset, inputSize, format));

     //append indivitual field values
      sbResults = super.getASCIIContent(sb, buffer, offset, level, format);
    }
    return sbResults;
  }
}
