/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;


import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.Field;
import com.nortel.cdma.service.csl.sls.filter.common.FieldAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;

import java.util.ListIterator;

import org.apache.log4j.Logger;


/**
 * A variable-size array of fields which are all of the same data type. The
 * size of the array is specified by a header field in the data stream. The
 * implementation takes advantage of the fact that this is effectively a
 * {@link StructType} where all of the elements are identical.
 */
public final class VariableArrayType extends VariableByteArrayType {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(VariableArrayType.class);


  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String VARIABLEARRAY_LABEL = "variableArray";

  /**
   * Constructs a VariableArrayType.
   */
  public VariableArrayType () {
    super();
  }

  /**
   * Sets the lengthHeader and element type of the array based on the
   * information specified in the field attributes object.
   *
   * @param attributes a {@link FieldAttributes} object containing the
   *          attributes needed to define the data type
   * @return true if successful, otherwise false
   */
  @Override
    public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result = false;

    if ( (attributesNotNull(attributes))
      && (super.setAttributes(attributes)) ) {

      // Since we don't know how many elements are going to be in the array,
      // create just one element. If additional ones are needed they will
      // be added at run time by cloning the first one.
      // We could create the number of elements specified by
      // maxlength, but that would be a waste of memory if maxlength is allowed
      // to default to MAXINT and there is never an array of that size in the
      // data stream.
      if (setArrayElement(attributes)) {
        result = true;
      }
    }
    return result;
  }

  /**
   * Creates a new instance of this datatype with the array size and
   * element type derived from the specified attributes.
   *
   * @param attributes a {@link DataTypeAttributes} object containing the
   *          attributes needed to define the data type
   * @return the newly defined DataType object
   */
  @Override
    public VariableArrayType cloneWithNewAttributes(DataTypeAttributes attributes) {

    VariableArrayType result = (VariableArrayType) this.clone();

    if ( (attributes == null)
      || (result == null)
      || (!result.setAttributes(attributes)) ) {

      result = new VariableArrayType();
    }
    return result;
  }

  /**
   * Marks the location of the array contents in the input buffer.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return  the offset of the contents in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  @Override
    protected int markArrayContents(InputBuffer buffer)
    throws ProcessingException {

    int   subFieldCount = subFields.size();

    if (subFieldCount < arraySize) {

      // There aren't enough elements in the array to
      // match the current array size, so create them.
      addArrayElements(arraySize);
    }

    // Now mark each field in the array.

    int   fieldNumber = 0;
    Field field;
    ListIterator<Field> iterator = subFields.iterator();

    while( (iterator.hasNext() )
        && (fieldNumber < arraySize) ) {

      field = iterator.next();
      if (field != null) {
        field.markFieldLocationInBuffer(buffer);
      }
      fieldNumber++;
    }

    int offset = subFields.getFirstField().getInputOffset();
    return offset;
  }


  /**
   * Outputs the contents of the field this datatype is associated with. In
   * the case of a VariableByteArray, output the length header and then
   * output the body of the array.
   *
   * @param buffer the input data stream
   * @param offset the offset of the field in the input data stream
   * @param emitter the object that determines what aspect of the field to
   *          output
   * @throws  ProcessingException if unable to get the value from the
   *          input data stream.
   */
  @Override
  public void emitContents(InputBuffer buffer, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if ((bufferNotNull(buffer)) && (emitterNotNull(emitter))) {

      // Output the length header.
      emitter.emit(lengthHeader, buffer);

      // Output the array elements.
      if (arraySize > 0) {
        emitSubFields(buffer, contentOffset, emitter);
      }
    }
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  @Override
    public String getXdrDefinition(int level) {

    String s = getDatatypeString(level, VARIABLEARRAY_LABEL)
      + getLengthHeaderDefinitionAsString(level)
      + getArrayElementDefinitionAsString(level);

    return s;
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
  public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                   int offset, int level)
    throws ProcessingException {

    String result = TextUtil.STRING_TERMINATOR;

    if (buffer != null) {

      result = super.getValueAsString(buffer, isInBuffer, offset, level);
      if (arraySize > 0) {
        result += getSubfieldsAsString(buffer, isInBuffer, level);
      }
    }
    return result;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer,
                                      int offset, int level, String format)
    throws ProcessingException {

    StringBuffer result = sb;
    if (buffer == null) {
      log4jDebugLogger.error("got null input buffer");
    }
    else {
      if (result == null) {
        log4jDebugLogger.error("got null stringbuffer");
        result = new StringBuffer();
      }
      else {
        if (lengthHeader != null) {
          String szValue = lengthHeader.getASCIIFieldContents(buffer, level + 1);
          if (szValue != null) {
            sb.append(TextUtil.NEW_LINE);
            sb.append(szValue);
          }
        }

        if (arraySize > 0) {
          if (subFields != null) {

            int   fieldNumber = 0;
            Field field;
            ListIterator<Field> iterator = subFields.iterator();

            // Can't use a for loop because subFields might have more elements than arraysize.
            while( (iterator.hasNext() )
                && (fieldNumber < arraySize) ) {

              field = iterator.next();
              if (field != null) {
                result.append(TextUtil.NEW_LINE);
                result = field.getASCIIOutput(result, buffer, level + 1);
                if (result.toString().endsWith(TextUtil.STRING_TERMINATOR)) {
                  break;
                }
              }
              fieldNumber++;
            }
          }
        }
      }
    }
    return result;
  }
}
