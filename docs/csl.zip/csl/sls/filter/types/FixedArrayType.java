/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;
import com.nortel.cdma.service.csl.sls.filter.common.FieldAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;

import org.apache.log4j.Logger;

/**
 * A fixed-size array of fields which are all of the same data type. The
 * implementation takes advantage of the fact that this is effectively a
 * {@link StructType} where all of the elements are identical.
 */
public class FixedArrayType extends ArrayType {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(FixedArrayType.class);

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String FIXEDARRAY_LABEL = "fixedArray";


  /**
   * Constructs a FixedArrayType with no size specified. Before use, the
   * size must be set using the {@link #setAttributes} method.
   */
  public FixedArrayType () {
    super();
  }

  /**
   * Sets the size and element type of the array based on the values
   * specified in the field attributes object.
   *
   * @param attributes a {@link FieldAttributes} object containing the
   *          attributes needed to define the data type
   * @return            true if successful, otherwise false
   */
  @Override
  public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result = false;

    if ( (attributesNotNull(attributes))
      && (super.setAttributes(attributes)) ) {

      arraySize = getArraySize(attributes, false);

      if ( (arraySize > 0)
        && (setArrayElement(attributes)) ) {

        try {
          addArrayElements(arraySize);
          result = true;
        }
        catch (ProcessingException e) {
          log4jDebugLogger.error(e.getErrorMessage());
        }
      }
    }
    return result;
  }

  /**
   * Creates a new instance of this datatype with the array size and
   * element type derived from the field definition.
   *
   * @param attributes a {@link DataTypeAttributes} object containing the
   *          attributes needed to define the data type
   * @return the newly defined DataType object
   */
  @Override
  public FixedArrayType cloneWithNewAttributes(DataTypeAttributes attributes) {

    if (attributesNotNull(attributes)) {

      FixedArrayType newType = (FixedArrayType) this.clone();

      if ( (newType != null)
       &&  (newType.setAttributes(attributes)) ) {
        return newType;
      }
    }
    return new FixedArrayType();
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  @Override
  public String getXdrDefinition(int level) {

    String s = getDatatypeString(level, FIXEDARRAY_LABEL)
             + TextUtil.getDefinitionString(level,
                   ARRAYSIZE_LABEL, Integer.toString(arraySize) )
             + getArrayElementDefinitionAsString(level + 1);

    return s;
  }

}
