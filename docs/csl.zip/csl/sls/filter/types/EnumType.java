/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ValueMap;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.ParsingException;

//Debug logging
import org.apache.log4j.Logger;


/**
 * Represent an unsigned integer enumeration. Enumerations may
 * be defined by creating a unique instance of this class (using the
 * {@link #cloneWithNewAttributes} method) with an attributes (@see DataTypeAttributes)
 * object that has a unique name and a valid mapping (@see
 * com.nortel.cdma.service.csl.sls.filter.common.ValueMap).
 */
public class EnumType extends DataType {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(EnumType.class);

  /**
   * A collection of name value pairs that constitute the enumerations.
   */
  protected ValueMap values = null;

  /**
   * The value returned when an enumeration does not contain a specified name.
   */
  public static final int NONEXISTANT_ENUM_VALUE = -1;

  /**
   * Constructs an EnumType with default attribute settings.
   */
  public EnumType() {
    values = new ValueMap();
  }

  /**
   * Sets the value mapping (enumerations).
   *
   * @param attributes a DataTypeAttributes object containing the value mapping
   * @return            true if successful, otherwise false
   */
  @Override
  public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result = false;

    if (attributes == null) {
      logNullAttributes();
    }
    else if (super.setAttributes(attributes)) {

      ValueMap mapping = attributes.getMapping();
      result = true;

      if (mapping != null) {
        values = mapping;

        if (!values.isValid()) {
          log4jDebugLogger.error(errorString("Enum definition has invalid values"));
          result = false;
        }
      }
      setInputSize(attributes);

      if (inputSize == INVALID_INPUTSIZE) {
        result = false;
      }
    }
    return result;
  }

  /**
   * Creates a new instance of this datatype with a unique value mapping
   * derived from the field definition.
   *
   * @param attributes a {@link DataTypeAttributes} object containing the
   *          attributes needed to define the data type.
   * @return the newly defined DataType object.
   */
  @Override
  public EnumType cloneWithNewAttributes(DataTypeAttributes attributes) {

    EnumType result;

    if (values.isValid()) {
      result = this;
    }
    else {
      // This is a generic type that needs to be refined.
      result = (EnumType) this.clone();

      if ( (attributes == null)
        || (result == null)
        || (!result.setAttributes(attributes)) ) {

        result = new EnumType();
      }
    }
    return result;
  }
  /**
   * Returns true if the type is a numeric value (i.e. byte, integer,
   * long, or enum type).
   *
   * @return    true if the object is a numeric value
   */
  @Override
  public boolean isNumeric() {
    return true;
  }

  /**
   * Returns the value of a field of this datatype at a specific location
   * in a data stream. Overrides default implementation in order to add
   * error checking of the enum value.
   *
   * @param buffer the input data stream from which to extract the field
   *          value
   * @param offset the location of the field in the data stream
   * @return the integer value of the field at the specified location
   * @throws        ProcessingException if unable to get the value from the
   *                input data stream
   */
  @Override
  public int getValue(InputBuffer buffer, int offset) throws ProcessingException {

    int result = 0;

    if (bufferNotNull(buffer)) {

      result = buffer.getValue(offset, inputSize);

      if (!values.containsValue(result)) {
        throw new ParsingException(errorString("Enum field contains undefined value")
          + " offset='" + offset + "' value='" + result + "'");
      }
    }
    return result;
  }

  /**
   * Returns the enumeration value associated with the specified name.
   * @param key the name to look up
   * @return the enumeration value associated with the specified name
   */
  public int getMapping(String key) {

    if (key != null) {
      return values.getValue(key);
    }
    return NONEXISTANT_ENUM_VALUE;
  }

  /**
   * Outputs the contents of the field this datatype is associated with.
   * Overrides default implementation in order to add error checking of the
   * enum value.
   *
   * @param buffer the input data stream
   * @param offset the offset of the field in the input data stream
   * @param emitter the object that determines what aspect of the field to
   *          output. Subclasses that override this method should invoke
   *          the emitter method {@link FieldEmitter#emit} to output
   *          subfields
   * @throws  ProcessingException if unable to parse the input data stream
   */
  @Override
  public void emitContents(InputBuffer buffer, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if ((bufferNotNull(buffer)) && (emitterNotNull(emitter))) {

      getValue(buffer, offset); // Will throw exception if value is out of range.
      emitter.appendContent(offset, inputSize, padLeft);
    }
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   *@param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer,
                                        int offset, int level, String format)
    throws ProcessingException {
    StringBuffer defaultBf = new StringBuffer();
    if ((sb != null) && (buffer != null)) {
      defaultBf = sb;
      int iValue =  buffer.getValue(offset, inputSize);
      String szValue = values.getDisplayname(iValue);
      if (szValue == null) {
        throw new ParsingException(errorString("Enum field contains undefined value")
          + " value='" + iValue + "'");
      }
      defaultBf.append(" = " + szValue);
    }
    return defaultBf;
  }
}
