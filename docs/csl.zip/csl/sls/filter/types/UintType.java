/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;

/**
 * An unsigned integer data type.
 */
public class UintType extends DataType {

  /**
   * Constructs an unsigned integer data type with default attribute
   * settings.
   */
  public UintType () {
    super();
  }

  /**
   * Returns true if the type is a numeric value (i.e. byte, integer,
   * long, or enum type).
   *
   * @return    true if the object is a numeric value.
   */
  @Override
  public boolean isNumeric() {
    return true;
  }

  /**
   * Sets the input size.
   *
   * @param attributes a DataTypeAttributes object containing the input size
   * @return            true if successful, otherwise false
   */
  @Override
  public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result = false;

    if (attributes == null) {
      logNullAttributes();
    }
    else if (super.setAttributes(attributes)) {

      setInputSize(attributes);

      if (inputSize != INVALID_INPUTSIZE) {
        result = true;
      }
    }
    return result;
  }
}
