/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.ValueMap;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;

/**
 * A data type that interprets one byte as an 8-bit unsigned integer
 * where 0=false and 1=true.
 */
public class BoolType extends EnumType {

  /**
   * Constructs a bool data type. It is implemented as an enumerated type with
   * these two enumerations.
   */
  public BoolType () {
    super();
    values = new ValueMap();
    values.setValueObject(Boolean.FALSE.toString(), 0, null);
    values.setValueObject(Boolean.TRUE.toString(), 1, null);
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
    public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                   int offset, int level)
    throws ProcessingException {
    String result = "";
    if (buffer != null) {
      int iValue = buffer.getValue(offset, inputSize);
      result += getValueAsString(iValue);
    }
    return result;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer,
                                      int offset, int level, String format)
    throws ProcessingException {
    StringBuffer result = sb;
    if (buffer != null) {
      int iValue = buffer.getValue(offset, inputSize);
      result.append(getValueAsString(iValue));
    }
    return result;
  }

  /**
   * Helper method to return the BoolType String value.
   * @param value the BoolType value
   * @return a String object
   */
  private String getValueAsString(int value) {
    StringBuffer sb = new StringBuffer (" value = ");
    if (value == 0) {
      sb.append(Boolean.FALSE);
    }
    else {
      sb.append(Boolean.TRUE);
    }
    return sb.toString();
  }
}
