/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;
import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.Field;
import com.nortel.cdma.service.csl.sls.filter.common.FieldList;
import com.nortel.cdma.service.csl.sls.filter.common.FieldAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;

import org.apache.log4j.Logger;

/**
 * A fixed-size array of fields which are all of the same data type. The
 * implementation takes advantage of the fact that this is effectively a
 * {@link StructType} where all of the elements are identical.
 */
public abstract class ArrayType extends StructType {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(ArrayType.class);

  /**
   * The minimum allowed size of an array.
   */
  private static final int   MIN_ARRAY_SIZE = 1;

  /**
   * The maximum allowed size of an array.
   */
  private static final int   MAX_ARRAY_SIZE = 32768;

  /**
   * The number of array elements.
   */
  protected int   arraySize = 0;

  /**
   * The field containing the value indicating the array size.
   */
  protected Field lengthHeader = null;

  /**
   * The offset of the contents of the array (i.e. size of the length header).
   */
  protected int contentOffset = 0;

  /**
   * A character that is used in the definition of the SUBFIELD_SUFFIX string.
   */
  private static final String DEFAULT_INDEX = "0";

  /**
   * A suffix that is used to make the subfield names unique.
   */
  private static final String SUBFIELD_SUFFIX = "[" + DEFAULT_INDEX + "]";


  /**
   * A string that is used to modify a log message to distinguish between
   * array size and maximum array size.
   */
  private static final String MAXIMUM = "maximum ";

  /**
   * String constant used when generating a text representation of the type.
   */
  protected static final String ARRAYSIZE_LABEL = "arraysize";

  /**
   * String constant used when generating a text representation of the type.
   */
  protected static final String MAXLENGTH_LABEL = " maxlength=";

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String LENGTHHEADER_LABEL = "lengthheader";

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String ARRAYELEMENT_LABEL = "arrayelementtype";


  /**
   * Constructor.
   */
  public ArrayType () {
    super();
    padLeft = false;
  }

  /**
   * Returns the array size as specified in the input schema, converted
   * to an integer and range validated.
   *
   * @param attributes a {@link FieldAttributes} object containing the
   *          attributes needed to define the data type
   * @param isMax a boolean indicating whether to interpret the array size
   *          value as a maximum
   * @return the array size if successful, otherwise -1
   */
  protected int getArraySize(DataTypeAttributes attributes, boolean isMax) {

    int result;

    if ( (attributesNotNull(attributes))  // redundant with following clause
      &&  (attributes instanceof FieldAttributes) ) {

      FieldAttributes fieldAttributes = (FieldAttributes)attributes;

      String arraySizeString = fieldAttributes.getArraysize();

      if (arraySizeString == null) {
        if (!isMax) {
          log4jDebugLogger.error(errorString("Field definition array size not specified"));
          result = -1;
        }
        else {
          // Maximum array size not specified, so use default.
          result = MAX_ARRAY_SIZE;
        }
      }
      else {
        String messageModifier = "";

        if (isMax) {
          messageModifier = MAXIMUM;
        }

        try {
          result = Integer.parseInt(arraySizeString);
        }
        catch (NumberFormatException e) {
          log4jDebugLogger.error(errorString("Field definition invalid "
            + messageModifier + "array size specified")
            + " arraySize='" + arraySizeString + "'");
          result = -1;
        }
        if ((result < MIN_ARRAY_SIZE) || (result > MAX_ARRAY_SIZE)) {
          log4jDebugLogger.error(errorString("Field definition "
            + messageModifier + "array size out of range")
            + " arraySize='" + result + "'");
          result = -1;
        }
      }
    }
    else {
      result = -1;
    }
    return result;
  }


  /**
   * Sets up the array element fields based on the type specified in the
   * input schema.
   *
   * @param attributes a {@link FieldAttributes} object containing the
   *          attributes needed to define the data type
   * @return true if successful, otherwise false
   */
  protected boolean setArrayElement(DataTypeAttributes attributes) {

    boolean result;

    if ( (attributesNotNull(attributes))  // redundant with following clause
      &&  (attributes instanceof FieldAttributes) ) {

      FieldAttributes fieldAttributes = (FieldAttributes)attributes;

      String arrayElementTypeName = fieldAttributes.getArrayElementType();

      if (arrayElementTypeName == null) {
        log4jDebugLogger.error(errorString("Field definition array element type not specified"));
        result = false;
      }
      else {
        // Arrays are implemented as a struct with fields fieldName_element1,
        // fieldName_element2, etc. Construct a single element of the type
        // specified by the schema, which will later be cloned to create
        // the remaining array elements.

        String elementName = name + SUBFIELD_SUFFIX;

        FieldAttributes elementAttributes = new FieldAttributes();
        elementAttributes.setName(elementName);
        elementAttributes.setDatatype(arrayElementTypeName);

        Field field = elementAttributes.createField(subFields);

        subFields = new FieldList();
        subFields.addField(elementName, field);

        result = true;
      }
    }
    else {
      result = false;
    }
    return result;
  }

  /**
   * Clones the first field in an array to create additional
   * elements.
   *
   * @param totalNumberOfElements the desired total number of elements
   * @throws ProcessingException if unable to process the input data
   */
  protected void addArrayElements(int totalNumberOfElements)
    throws ProcessingException {

    Field firstField  = subFields.getFirstField();

    if (firstField == null) {
      throw new ProcessingException(errorString("Missing first array element"));
    }

    int    currentNumberOfElements = subFields.size();
    String defaultName = name + SUBFIELD_SUFFIX;

    for (int i = currentNumberOfElements; i < totalNumberOfElements; i++) {

      // Set the field name to 'name[i]'
      String fieldName  = defaultName.replaceAll(DEFAULT_INDEX, Integer.valueOf(i).toString());

      Field  cloneField = firstField.clone();

      if (cloneField == null) {
        throw new ProcessingException(errorString("Failed to clone array element"));
      }
      cloneField.setName(fieldName);
      subFields.addField(fieldName, cloneField);
    }
  }

  /**
   * Determines the actual size of a field when padding is added for field
   * alignment.
   *
   * @param iSize the field size
   * @param iAlignment the field alignment value
   * @return the field size including the padding required to align the
   *         field
   * @throws ProcessingException if unable to calculate the padding size
   */
  protected int adjustFieldSizeToAlign(int iSize, int iAlignment)
    throws ProcessingException {

    int iResult = iSize;

    if (iAlignment > 1) {

      int remainder = 0;
      try {
        remainder = iSize % iAlignment;
      }
      catch (Exception e) {
        throw new ProcessingException(errorString("Invalid alignment value: '") + iAlignment + "'");
      }
      // Adjust input size to include field alignment padding.
      if (remainder > 0) {
        iResult += iAlignment - remainder;
      }
    }
    return iResult;
  }

  /**
   * Returns a string describing the length header in XML format.
   *
   * @param level the indent level of the field in the schema
   *                from the left margin
   * @return        a string representation of the length header
   */
  protected String getLengthHeaderDefinitionAsString(int level) {

    StringBuffer sb = new StringBuffer();

    sb.append(TextUtil.getDefinitionOpenString(level, LENGTHHEADER_LABEL));

    if (lengthHeader != null) {

      sb.append(lengthHeader.getXdrDefinition(level + 1));
    }
    sb.append(TextUtil.getDefinitionCloseString(level, LENGTHHEADER_LABEL));

    return sb.toString();
  }

  /**
   * Returns a string describing the array element type in XML format.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the array element
   */
  protected String getArrayElementDefinitionAsString(int level) {

    StringBuffer sb = new StringBuffer();

    sb.append(TextUtil.getDefinitionOpenString(level, ARRAYELEMENT_LABEL));

    if (subFields != null) {

      Field element = subFields.getFirstField();
      if (element != null) {
        sb.append(element.getXdrDefinition(level + 1));
      }
    }
    sb.append(TextUtil.getDefinitionCloseString(level, ARRAYELEMENT_LABEL));

    return sb.toString();
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
    public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                   int offset, int level)
    throws ProcessingException {

    String result = TextUtil.STRING_TERMINATOR;

    if (buffer != null) {

      result = ARRAYSIZE_LABEL + arraySize;
      result += super.getValueAsString(buffer, isInBuffer, offset, level);
    }
    return result;
  }

  /**
   * Returns lengthHeader value.
   * @return lengthHeader field value
   */
  protected Field getLengthHeader () {
    return lengthHeader;
  }

  /**
   * Returns the array size.
   * @return the integer value of array size
   */
  protected int getArraySize () {
    return arraySize;
  }

  /**
   * Returns the array content offset.
   * @return the integer value of the array content offset
   */
  protected int getContentOffset () {
    return contentOffset;
  }
}
