/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.Field;
import com.nortel.cdma.service.csl.sls.filter.common.FieldList;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;

//Debug logging
import org.apache.log4j.Logger;

/**
 * Base definition of a data type. Simple datatypes such as unsigned integers
 * shorts, and bytes can be defined by creating instances of this class and setting
 * the inputSize and outputSize attributes as appropriate to specify the size of the
 * field contents in the input data stream and output data stream respectively. More
 * complex types would be defined by subclasses of this class and overriding the
 * appropriate methods.
 */
public class DataType implements Cloneable {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(DataType.class);

  /**
   * The name of the data type.
   */
  protected String      name = null;

  /**
   * The number of bytes occupied by the field in the input data stream.
   */
  protected int         inputSize = 0;

  /**
   * Indicates whether pad bytes should be added to the left (when true) or to
   * the right (when false) of the field contents in the output stream when
   * outputSize > inputSize.
   */
  protected boolean     padLeft = true;

  /**
   * Error string used when the input buffer is null.
   */
  protected String NULL_BUFFER_MSG = "InputBuffer is null";

  /**
   * Error string used when the emitter is null.
   */
  protected String NULL_EMITTER_MSG = "FieldEmitter is null";

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String DATATYPE_LABEL = "datatype";

  /**
   * String constant used when generating a text representation of the type.
   */
  protected static final String NAME_LABEL = "name";

  /**
   * Constant value specifying the minimum valid size (in bytes) of a
   * fixed size datatype.
   */
  private static int MINSIZE = 1;

  /**
   * Constant value specifying the maximum valid size (in bytes) of a
   * fixed size datatype.
   */
  private static int MAXSIZE = 8;

  /**
   * Constant value used to indicate that a type has been assigned an
   * invalid size.
   */
  public static int INVALID_INPUTSIZE = -1;

  /**
   * Constructs an empty DataType object.
   *
   */
  public DataType() {
  }

  /**
   * Returns the name of the data type.
   *
   * @return    the name of the data type
   */
  public String getName() {

    return name;
  }

  /**
   * Sets the attributes of the data type based on information derived from an
   * attributes object.
   *
   * @param attributes  a {@link DataTypeAttributes} object containing the attributes
   *                    needed to define the data type
   * @return            true if successful, otherwise false
   */
  public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result = false;

    if (attributes == null) {
      logNullAttributes();
    }
    else {
      name = attributes.getName();
      result = true;
    }
    return result;
  }

  /**
   * Set data type input size.
   * @param attributes the DataTypeAttributes
   */
  protected void setInputSize(DataTypeAttributes attributes) {

    if (attributes == null) {
      logNullAttributes();
    }
    else {
      if (inputSize == 0) {
        // Defining a root type - inputsize needs to be set from attributes.
        inputSize = attributes.getInputsize();

        if ((inputSize < MINSIZE) || (inputSize > MAXSIZE)) {
          log4jDebugLogger.error(errorString("Field definition input size out of range")
            + " inputSize='" + inputSize + "'");
          inputSize = INVALID_INPUTSIZE;
        }
      }
    }
  }

  /**
   * Subclasses may override this to generate a new specialized instance of
   * the data type with some attributes set to different values as
   * required.
   *
   * @param attributes a {@link DataTypeAttributes} object containing the
   *          attributes needed to define the data type
   * @return the newly defined DataType object
   */
  public DataType cloneWithNewAttributes(DataTypeAttributes attributes) {

    // Default behaviour is not to refine the datatype.
    // Subclasses may override to customize the behavior.
    return this;
  }

  /**
   * Returns a clone of this datatype. Subclasses that define subfields should override
   * this to ensure that all subfields are cloned as well.
   *
   * @return    an object that is a clone of this one
   */
  @Override
    public DataType clone()  {

    DataType theClone = null;
    try {
      theClone = (DataType) super.clone();
    }
    catch (CloneNotSupportedException e) {
      // This class is a subclass of Object, which supports cloning,
      // therefore we should never see this exception.
      log4jDebugLogger.error(errorString("Failed to clone data type"), e);
    }
    return theClone;
  }

  /**
   * Gives a field an opportunity to replace a reference to a specific
   * field which has been cloned with a reference to the clone. Subclasses
   * should override this method if they maintain a reference to other
   * fields.
   *
   * @param list  the list of cloned fields
   */
  public void updateReferences(FieldList list) {
    // Default does nothing.
  }

  /**
   * Returns true if the type is a numeric value (i.e. byte, integer,
   * long, or enum type).
   *
   * @return    true if the object is a numeric value
   */
  public boolean isNumeric() {

    return false;
  }

  /**
   * Marks the location of the field associated with this data type
   * in the input buffer.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return        the offset of the field in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  public int markFieldLocationInBuffer(InputBuffer buffer)
    throws ProcessingException {

    int offset = 0;

    if (bufferNotNull(buffer)) {
      offset = buffer.markFieldLocation(inputSize);
    }
    return offset;
  }

  /**
   * Returns the value of a field of this datatype at a specific location in
   * a data stream. This method only makes sense for integer data types that are
   * less than or equal to 4 bytes in length.
   *
   * @param buffer  the input data stream from which to extract the field value
   * @param offset  the location of the field in the data stream
   * @return        the integer value of the field at the specified location
   * @throws        ProcessingException if unable to get the value from the
   *                input data stream
   */
  public int getValue(InputBuffer buffer, int offset) throws ProcessingException {

    int value = -1;

    if (bufferNotNull(buffer)) {
      if (!isNumeric()) {
        throw new ProcessingException(
          errorString("Attempt to evaluate non-numeric field"));
      }
      if (inputSize > 4) {
        throw new ProcessingException(
          errorString("Attempt to evaluate field larger than four bytes"));
      }
      value = buffer.getValue(offset, inputSize);
    }
    return value;
  }

  /**
   * Returns the field associated with a given field name. The default method
   * does nothing. Subclasses that contain subfields should override this to return
   * the requested subfield.
   *
   * @param fieldName   the name of the requested field
   * @return            the requested field, or null if it does not exist
   */
  public Field getField(String fieldName) {

    return null;  // This class has no subfields defined
  }

  /**
   * Outputs the contents of the field this datatype is associated with.
   * The default behaviour is to simply copy the data from the input stream
   * to the output stream. More complex data types would override this
   * behaviour to (for example) output the contents of subfields.
   *
   * @param buffer the input data stream
   * @param offset the offset of the field in the input data stream
   * @param emitter the object that determines what aspect of the field to
   *          output Subclasses that override this method should invoke the
   *          emitter method {@link FieldEmitter#emit} to output subfields
   * @throws  ProcessingException if unable to get the value from the
   *          input data stream
   */
  public void emitContents(InputBuffer buffer, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if ((bufferNotNull(buffer)) && (emitterNotNull(emitter))) {
      emitter.appendContent(offset, inputSize, padLeft);
    }
  }

  /**
   * Checks whether the attributes object is null.
   *
   * @param attributes  a {@link DataTypeAttributes} object containing the attributes
   *                    needed to define the data type
   * @return            false if the object is null, otherwise true
   */
  protected boolean attributesNotNull(DataTypeAttributes attributes) {

    if (attributes == null) {
      logNullAttributes();
      return false;
    }
    return true;
  }

  /**
   * Logs an error message indicating that the DataTypeAttributes
   * object is null.
   */
  protected void logNullAttributes() {

    log4jDebugLogger.error("DataTypeAttributes is null");
  }

  /**
   * Checks whether the input buffer object is null.
   *
   * @param buffer  the input buffer
   * @return        true if the buffer is not null
   * @throws        ProcessingException if the buffer is null
   */
  protected boolean bufferNotNull(InputBuffer buffer) throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException(errorString(NULL_BUFFER_MSG));
    }
    return true;
  }

  /**
   * Checks whether the emitter object is null.
   *
   * @param emitter  the emitter
   * @return         true if the buffer is not null
   * @throws         ProcessingException if the buffer is null
   */
  protected boolean emitterNotNull(FieldEmitter emitter) throws ProcessingException {

    if (emitter == null) {
      throw new ProcessingException(errorString("FieldEmitter is null"));
    }
    return true;
  }

  /**
   * Returns an error string with the type name appended.
   *
   * @param error the error string to be extended
   * @return      a string containing the error string with the
   *              type name appended
   */
  protected String errorString(String error) {
    if (error == null) {
      error = "<missing message>";
    }
    return error + "; name='" + name + "'";
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  public String getXdrDefinition(int level) {

    return getDatatypeString(level, name);
  }

  /**
   * Subclasses may override this method to return a string
   * to be used as an attribute of the field definition
   * when generating a string representation of the
   * structure of this object.
   *
   * @return A string containing the attribute names and values
   */
  public String getXdrDefinitionAttributes() {

    // Default is to return no attributes.
    return "";
  }

  /**
   * Returns a string containing the datatype name formatted
   * as an XML element.
   *
   * @param level the indentation level of the hierarchy
   * @param typeName the datatype name
   * @return a string containing the the datatype name formatted
   * as an XML element
   */
  protected String getDatatypeString(int level, String typeName) {

    String s = TextUtil.getDefinitionString(level, DATATYPE_LABEL, typeName);

    return s;
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   *
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   *
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                 int offset, int level)
    throws ProcessingException {

    String result   = TextUtil.STRING_TERMINATOR;

    if (buffer != null) {

      result = TextUtil.getValueAsHexString(buffer, offset, inputSize);
    }
    return result;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer, int offset, int level, String format)
    throws ProcessingException {
    StringBuffer defaultBf = new StringBuffer();
    if ((sb != null) && (buffer != null)) {
      defaultBf = sb;
      String fieldValue = null;
      if (format != null) {
        fieldValue = TextUtil.getValueAsString(buffer, offset, inputSize, format);
      }
      else {
        if (fieldValue == null) {  //hex by default
          fieldValue = TextUtil.getValueAsString(buffer, offset, inputSize, "hex");
        }
      }
      defaultBf.append(" = " + fieldValue);
    }
    return defaultBf;
  }
}

