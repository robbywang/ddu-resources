package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;

/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

/**
 * A void data type. Doesn't consume any input, doesn't generate
 * any output.
 */
public class VoidType extends DataType {

  /**
   * Constructs a void data type.
   */
  public VoidType () {
    super();
    inputSize = 0;
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  @Override
  public String getXdrDefinition(int level) {

    return "";
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
  public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                                       int offset, int level)
                  throws ProcessingException {

    // Override superclass behaviour to output nothing.
    return null;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
    public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer,
                                        int offset, int level, String format)
      throws ProcessingException {

    // nothing to added; return the passed-in string buffer
      return sb;
  }
}
