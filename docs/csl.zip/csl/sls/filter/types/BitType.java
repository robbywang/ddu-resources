/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;

/**
 * A data type intended to be used as a subfield of the {@link BitmapType}.
 * It is a single bit type that is referenced by {@link UnionType}s as a boolean
 * discriminant.
 */
public class BitType extends DataType{

  /**
   * A mask that isolates the specific bit in the bitmap.
   */
  private int mask = 0;

  /**
   * A constant value that represents a set bit.
   */
  private static final byte[] SET_VALUE = {1};

  /**
   * A constant that represents an unset bit.
   */
  private static final byte[] UNSET_VALUE = {0};

  /**
   * Constructs a datatype representing a single bit.
   *
   */

  public BitType() {
    super();
    inputSize = 1; // The size (in bytes) of the entire bitmap to be retrieved.
  }

  /**
   * Sets the mask value.
   *
   * @param maskValue   a value with a single bit set indicating the bit position
   *                    of this type's field in a bitmap
   */
  public void setMask(int maskValue) {

    if ((maskValue > 0x80) || (Integer.bitCount(maskValue) != 1)) {
      throw new IllegalArgumentException(String.valueOf(maskValue));
    }
    mask = maskValue;
  }

  /**
   * Marks the location of the field associated with this data type
   * in the input buffer.
   *
   * @param buffer  the input buffer in which the field is being located.
   * @return        the offset of the field in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  @Override
    public int markFieldLocationInBuffer(InputBuffer buffer) throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException("Got null InputBuffer");
    }
    // The byte offset of a bit field is the same as its parent bitmap, so
    // just return the current buffer offset without changing it.
    return buffer.getOffset();
  }

  /**
   * Returns true because a bit in a bitmap is numeric (0 or 1).
   *
   * @return    true if the object is a numeric value
   */
  @Override
    public boolean isNumeric() {
    return true;
  }

  /**
   * Returns the value of a field of this datatype at a specific location in
   * a data stream. This method only makes sense for integer data types that are
   * less than or equal to four bytes in length.
   *
   * @param buffer  the input data stream from which to extract the field value
   * @param offset  the location of the field in the data stream
   * @return        the integer value of the field at the specified location
   * @throws        ProcessingException if unable to get the value from the
   *                input data stream
   */
  @Override
    public int getValue(InputBuffer buffer, int offset) throws ProcessingException {
    if (buffer == null) {
      throw new ProcessingException("Got null InputBuffer");
    }
    int result = 0;
    int bitmap = buffer.getValue(offset, inputSize);
    if ((bitmap & mask) == mask) {
      result = 1;
    }
    return result;
  }

  /**
   * Outputs the value of the bit as a field.
   *
   * @param in          the input data stream
   * @param offset      the offset of the field in the input data stream
   * @param emitter     the object that determines what aspect of the field to output
   * @throws  ProcessingException if invalid parameters specified
   */
  @Override
    public void emitContents(InputBuffer in, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if (emitter == null) {
      throw new ProcessingException("Got null FieldEmitter");
    }
    if (getValue(in, offset) == 1) {
      emitter.appendContent(SET_VALUE, 0, inputSize, padLeft);
    }
    else {
      emitter.appendContent(UNSET_VALUE, 0, inputSize, padLeft);
    }
  }

  /**
   * Returns the value of the field formatted as a text string for
   * debugging.
   * @param buffer the data stream
   * @param isInBuffer true if buffer is input data stream,
   *                   false if it is the output
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  @Override
  public String getValueAsString(ExtendableBuffer buffer, boolean isInBuffer,
                               int offset, int level)
         throws ProcessingException {

    String result   = TextUtil.STRING_TERMINATOR;
    if (buffer != null) {
      int value = buffer.getValue(offset, inputSize);
      result = getValueAsString(value);
    }
    return result;
  }

  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer,
                                      int offset, int level, String format)
    throws ProcessingException {

    if ((sb != null) && (buffer != null)) {
      int value = this.getValue(buffer, offset);
      sb.append(getValueAsString(value));
    }
    return sb;
  }

  /**
   * Helper method to return the BitType String value.
   * @param value the BitType value
   * @return a String object
   * @throws ProcessingException
   */
  private String getValueAsString(int value) throws ProcessingException {
    StringBuffer sb = new StringBuffer ("");
    byte[] maskByte = {(byte) (mask & 0xFF)};
    sb.append(" mask ='" + TextUtil.toHexString(maskByte) + "'");
    sb.append(" value =");
    if (value == 0) {
      sb.append(Boolean.FALSE);
    }
    else {
      sb.append(Boolean.TRUE);
    }
    return sb.toString();
  }
}
