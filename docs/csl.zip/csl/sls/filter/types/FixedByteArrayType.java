/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.types;

import com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;
import com.nortel.cdma.service.csl.sls.filter.common.FieldAttributes;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import org.apache.log4j.Logger;

/**
 * A fixed-size array of bytes.
 */
public class FixedByteArrayType extends ArrayType {

  /**
   * String constant used when generating a text representation of the type.
   */
  private static final String FIXEDBYTEARRAY_LABEL = "fixedByteArray";

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(FixedByteArrayType.class);

  /**
   * Constructs a FixedByteArray with no size specified. Before use, the
   * size should be set using the {@link #setAttributes} method.
   */
  public FixedByteArrayType () {
    super();
  }

  /**
   * Sets the size and element type of the array based on the values
   * specified in the field attributes object.
   *
   * @param attributes a {@link FieldAttributes} object containing the
   *          attributes needed to define the data type
   * @return            true if successful, otherwise false
   */
  @Override
  public boolean setAttributes(DataTypeAttributes attributes) {

    boolean result = false;

    if ( (attributesNotNull(attributes))
      && (super.setAttributes(attributes)) ) {

      arraySize = getArraySize(attributes, false);

      if (arraySize > 0) {

        inputSize = arraySize;
        result = true;
      }
    }
    return result;
  }

  /**
   * Creates a new instance of this datatype with the array size derived
   * from the field definition.
   *
   * @param attributes a {@link DataTypeAttributes} object containing the
   *          attributes needed to define the data type
   * @return the newly defined DataType object
   */
  @Override
  public FixedByteArrayType cloneWithNewAttributes(DataTypeAttributes attributes) {

    FixedByteArrayType result;

    if (inputSize > 0) {
      result = this;
    }
    else {
      // This is a generic type that needs to be refined.
      result = this.clone();

      if ( (attributes == null)
        || (result == null)
        || (!result.setAttributes(attributes)) ) {

        result = new FixedByteArrayType();
      }
    }
    return result;
  }

  /**
   * Returns a clone of this datatype. Override superclass because
   * we don't have subfields.
   *
   * @return    an object that is a clone of this one
   */
  @Override
  public FixedByteArrayType clone()  {

    FixedByteArrayType theClone = (FixedByteArrayType) super.clone();
    return theClone;
  }


  /**
   * Marks the location of the field associated with this data type
   * in the input buffer.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return        the offset of the field in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  @Override
  public int markFieldLocationInBuffer(InputBuffer buffer)
    throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException(errorString(NULL_BUFFER_MSG));
    }
    int alignment = buffer.getFieldAlignment();

    inputSize = adjustFieldSizeToAlign(inputSize, alignment);

    int offset = buffer.markFieldLocation(inputSize);

    return offset;
  }

  /**
   * Outputs the contents of the field this datatype is associated with.
   * Override superclass because we don't have subfields.
   *
   * @param buffer the input data stream
   * @param offset the offset of the field in the input data stream
   * @param emitter the object that determines what aspect of the field to
   *          output Subclasses that override this method should invoke the
   *          emitter method {@link FieldEmitter#emit} to output subfields
   * @throws  ProcessingException if unable to get the value from the
   *          input data stream
   */
  @Override
  public void emitContents(InputBuffer buffer, int offset, FieldEmitter emitter)
    throws ProcessingException {

    if ((bufferNotNull(buffer)) && (emitterNotNull(emitter))) {
      emitter.appendContent(offset, inputSize, padLeft);
    }
  }

  /**
   * Returns a string representation of the structure of this object.
   *
   * @param level the indent level of the field in the schema
   * @return        a string representation of the datatype
   */
  @Override
  public String getXdrDefinition(int level) {

    String s = getDatatypeString(level, FIXEDBYTEARRAY_LABEL)
      + TextUtil.getDefinitionString(level,
        ARRAYSIZE_LABEL, Integer.toString(arraySize) );
    return s;
  }
  /**
   * Returns the String value of the field for ASCII parsing, where the output format is
   * configurable.
   * @param sb the ouput StringBuffer
   * @param buffer the data stream
   * @param offset the offset of the field in the buffer
   * @param level the indent level of the field in the schema
   * @param format the output format
   * @return the string representation of the field contents
   * @throws ProcessingException if the contents of the field could not be
   *           retrieved from the buffer
   */
  public StringBuffer getASCIIContent(StringBuffer sb, InputBuffer buffer, int offset, int level, String format)
    throws ProcessingException {

    if (sb == null) {
      log4jDebugLogger.error("got null StringBuffer");
      sb = new StringBuffer("");
    }
    else if (buffer == null) {
      log4jDebugLogger.error("got null InputBuffer");
    }
    else {
      String result = TextUtil.getValueAsString(buffer, offset, arraySize, format);
      if (result != null) {
        sb.append(" = " + result);
      }
    }
    return sb;
  }
}
