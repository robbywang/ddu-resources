/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.common;

import java.util.Arrays;

/**
 * A wrapper class for a byte array. It allows new input data to be easily
 * appended to the end of the array and obsolete data to be discarded from
 * the front of the array. It also provides the ability to pad the data to be
 * appended to a specified size by adding pad bytes either before or after.
 */
public class ExtendableBuffer {

  /**
   * The actual byte array wrapped by this class.
   */
  private byte[] mabContents = null;  // mab = member array of bytes

  /**
   * The start of the valid data in this buffer. Everything before this start
   * point has effectively been discarded.
   */
  private int miStart;

  /**
   * The position in the buffer where the data ends, i.e. the point at which
   * additional data can be appended.
   */
  private int miOffset;

  /**
   * The number of bytes to add to the buffer when it is extended.
   */
  private static int BUFFER_INCREMENT = 4096;

  /**
   * Constructs a new empty ExtendableBuffer.
   */
  public ExtendableBuffer() {
    mabContents = new byte[BUFFER_INCREMENT];
    miStart = 0;
    miOffset = 0;
  }

  /**
   * Return the value of the offset at which new data will be appended to
   * this buffer.
   *
   * @return the value of the current buffer offset
   */
  public int getOffset() {
    return miOffset;
  }

  /**
   * Extend the buffer size to make room for additional data to be appended.
   * Any discarded data (@see #discard) is dropped while copying from the
   * old byte array to the new one.
   *
   * @param length  the number of bytes to add to the buffer size
   */
  private void extend(int length) {

    if (length < BUFFER_INCREMENT) {
      length = BUFFER_INCREMENT;
    }
    int bufferSize = mabContents.length - miStart;
    int newSize = bufferSize + length;

    byte[] newArray = new byte[newSize];

    // Copy the contents of the existing buffer into the new one.
    int dataSize = miOffset - miStart;

    System.arraycopy(mabContents, miStart, newArray, 0, dataSize);
    mabContents = newArray;

    miOffset = dataSize;
    miStart = 0;
  }

  /**
   * Append new data to the end of the buffer. Defaults the source offset value
   * to 0.
   *
   * @param bytes      the byte array to be appended to the end of the buffer
   * @param srcLength  the length (in bytes) of the data in the byte array to
   *                   be appended
   * @return           the offset at which the data was appended
   * @throws           BufferUnderflowException if there is insufficient data
   *                   in the buffer to accomodate the field length
   */
  public int append(byte[] bytes, int srcLength)
         throws BufferUnderflowException {

    return append(bytes, 0, srcLength);
  }

  /**
   * Append new data to the end of the buffer.
   *
   * @param bytes       the byte array to be appended to the end of the buffer
   * @param srcOffset   offset within the array to the start of the data to be appended
   * @param srcLength   the length (in bytes) of the data in the byte array to
   *                    be appended
   * @return           the offset at which the data was appended
   * @throws           BufferUnderflowException if there is insufficient data
   *                   in the buffer to accomodate the field length
   */
  public int append(byte[] bytes, int srcOffset, int srcLength)
         throws BufferUnderflowException {

    int result = -1;

    if (bytes != null) {
      if (srcOffset + srcLength > bytes.length) {
        throw new BufferUnderflowException("size='" + bytes.length
                  + "' offset='" + srcOffset + "' selected='" + srcLength);
      }
      if (srcOffset < 0) {
        throw new BufferUnderflowException("Invalid offset; value='" + srcOffset +"'");
      }

      if (srcLength > (mabContents.length - miOffset)) {
        extend(srcLength);
      }

      System.arraycopy(bytes, srcOffset, mabContents, miOffset, srcLength);
      result = miOffset;
      miOffset += srcLength;
    }
    return result;
  }

  /**
   * Append new data to the end of the buffer. Allows the output size to be
   * different than the input data size, and the output padded with filler bytes
   * either to the left or right of the data.
   *
   * @param bytes       the byte array to be appended to the end of the buffer
   * @param srcOffset   offset within the array to the start of the data to be appended
   * @param srcLength   the length (in bytes) of the data in the byte array to
   *                    be appended
   * @param destLength  the length (in bytes) of the appended data with padding;
   *                    destLength > srcLength implies padding;
   *                    destLength < srcLength is meaningless
   * @param padValue    the value to be inserted in the pad bytes
   * @param left        indicates whether to pad on the left (true) or right (false)
   * @return            the offset at which the data was appended
   */
  public int append(byte[] bytes, int srcOffset, int srcLength,
                     int destLength, byte padValue, boolean left) {

    int result = -1;

    if (bytes != null) {

      int padLength = destLength - srcLength;

      int length = srcLength + padLength;
      if ((length) > (mabContents.length - miOffset)) {
        extend(length);
      }
      result = miOffset;

      if (left && (padLength > 0)) {
        Arrays.fill(mabContents, miOffset, miOffset+padLength, padValue);
        miOffset += padLength;
      }

      System.arraycopy(bytes, srcOffset, mabContents, miOffset, srcLength);
      miOffset += srcLength;

      if (!left && (padLength > 0)) {
        Arrays.fill(mabContents, miOffset, miOffset+padLength, padValue);
        miOffset += padLength;
      }
    }
    return result;
  }

  /**
   * Discard data from the beginning of the buffer.
   *
   * @param length  the number of bytes to be discarded
   */
  public void discard(int length) {

    // Nothing is actually discarded here, simply move the 'start' offset
    // which indicates the beginning of the valid data. The bytes will
    // eventually be discarded the next time the buffer is extended.
    miStart += length;
  }

  /**
   * Discard data from the specified offset to the first end of record
   * marker - 0xFAAE.
   *
   * @param offset  the position in the buffer to start looking for
   *                the EOR marker
   * @return        the number of bytes remaining in the buffer
   */
  public int discardToEOR(int offset) {

    miStart += offset;

    while (miStart < miOffset) {

      byte b1 = mabContents[miStart];

      if (b1 == (byte)0xFA) {

        byte b2 = mabContents[miStart+1];

        if (b2 == (byte)0xAE) {

          miStart += 2;
          break;
        }
      }
      miStart++;
    }

    return miOffset - miStart;
  }

  /**
   * Determine the size (number of bytes) of the valid data in the buffer. Valid
   * implies not including anything that has been discarded.
   *
   * @return    the size (in bytes) of the valid data in the buffer
   */
  public int getLength() {

    return miOffset - miStart;
  }

  /**
   * Extracts a value from the buffer, given a specific offset and number of bytes.
   * This operation is only valid for length = 1, 2, or 4 bytes.
   *
   * @see #setValue
   * @param offset  location within the buffer where the value is to be extracted
   * @param length  number of bytes that comprise the value to be extracted
   * @return        the integer value of the specified byte sequence
   * @throws BufferUnderflowException if there is not sufficient data in the buffer
   *                to accomodate the request.
   * @throws ProcessingException if an invalid buffer offset value is specified
   */
  public int getValue(int offset, int length)
    throws BufferUnderflowException, ProcessingException {

    if (offset < 0) {
      throw new ProcessingException("Invalid offset; value='" + offset +"'");
    }
    if ((offset + length) > (miOffset - miStart)) {
      throw new BufferUnderflowException("start='" + miStart + "' end='" + miOffset
                                       + "' offset='" + offset + "' selected='" + length);
    }
    int value = 0;

    if (length <= 4) {
      int accumulator = 0;
      int position = miStart + offset;

      for (int i = length; i > 0; i--) {
        accumulator = mabContents[position + i - 1] & 0xFF;
        value += accumulator << ((length - i) * 8);
      }
    }
    return value;
  }

  /**
   * Sets the buffer contents at the specified offset to the specified
   * value.
   *
   * @see #getValue
   * @param offset the offset of the bytes to be modified
   * @param value the value to be set
   */
  public void setValue(int offset, int value) {

    for (int i = offset; i < 4; i++) {
      int shift = (3 - i) * 8;
      mabContents[i] = (byte) ((value >>> shift) & 0xFF);
    }
  }

  /**
   * Returns the contents of the buffer as a byte array.
   *
   * @return    the contents of the buffer
   *
   * @todo If the xdrliteconverter runs slowly and consumes excessive CPU,
   * it's probably because of all the temporary objects being created here.
   * Consider a better way to access the buffer contents.
   */
  public byte[] toByteArray() {

    byte[] result = null;

    if (mabContents != null) {

  	  // Clone the contents into a new array.
  	  int size = miOffset - miStart;
  	  result = new byte[size];
  	  System.arraycopy(mabContents, miStart, result, 0, size);
    }
    return result;
  }

  /**
   * Get the start offset of the valid data in this buffer.
   * @return the start offset
   * @see #setStartOffset
   */
   public int getStartOffset() {
    return miStart;
  }

  /**
   * Set the  start offset of the valid data in this buffer.
   * @param iNewStart the new start offset
   * @see #getStartOffset
   */
    public void setStartOffset(int iNewStart) {
    miStart = iNewStart;
  }
}
