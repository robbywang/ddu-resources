package com.nortel.cdma.service.csl.sls.filter.common;
/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

import javax.xml.parsers.FactoryConfigurationError;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import org.apache.commons.digester.Digester;
import org.apache.commons.digester.ExtendedBaseRules;
import org.apache.commons.digester.xmlrules.FromXmlRuleSet;

import org.apache.log4j.Logger;

/**
 * A configuration for the Apache Commons Digester.
 */
public class DigesterConfiguration {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(DigesterConfiguration.class);

  /**
   * A file containing parsing rules in XML format.
   * @see org.apache.commons.digester.xmlrules
   */
  protected InputSource parsingRulesFile;

  /**
   * An instance of the Digester appropriately configured.
   */
  protected Digester digester;

  /**
   * Constructor.
   */
  public DigesterConfiguration() {

    this(null);
  }

  /**
   * Constructor that allows a parsing rules XML file to
   * be specified for configuring the digester.
   * @param parsingRules an XML file containing digester
   *        parsing rules
   */
  public DigesterConfiguration(InputSource parsingRules) {

    this.parsingRulesFile = parsingRules;
    this.digester = configureDigester();
  }

  /**
   * Returns the configured Digester.
   *
   * @return the configured Digester
   */
  public Digester getDigester() {
    return digester;
  }

 /**
   * Creates and configures a SAX parser for use by the Digester.
   *
   * @return a configured SAX parser
   */
  protected SAXParser configureParser() {

    Throwable exception  = null;
    SAXParserFactory spf = null;
    SAXParser parser     = null;
    try {
      spf = SAXParserFactory.newInstance();
      // Setup SAX parser to handle XInclude.
      spf.setNamespaceAware(true);
      spf.setXIncludeAware(true);

      // Now get an instance of the parser with XInclude enabled.
      try {
        parser = spf.newSAXParser();
      }
      catch (ParserConfigurationException e) {
        exception = e;
      }
      catch (SAXException e) {
        exception = e;
      }
    }
    catch (FactoryConfigurationError e) {
      exception = e;
    }
    if (exception != null) {
      log4jDebugLogger.error("Failed to configure SAX parser", exception);
      return null;
    }
    return parser;
  }

  /**
   * Creates and configures a Digester for parsing XML files.
   * If a file containing parsing rules in XML format has
   * been specified, it is used to configure the Digester.
   * Subclasses override this to generate a custom-configured
   * Digester.
   *
   * @return a configured Digester
   */
  protected Digester configureDigester() {

    SAXParser parser = configureParser();
    Digester  newDigester;

    if (parser == null) {
      log4jDebugLogger.error("Parser is null");
      newDigester = null;
    }
    else {
      newDigester = new Digester(parser);

      if (newDigester == null) {
        log4jDebugLogger.error("Failed to create Digester");
      }
      else {
        if ((parsingRulesFile != null) && (newDigester != null)) {

          newDigester.setRules(new ExtendedBaseRules());
          FromXmlRuleSet ruleSet = new FromXmlRuleSet(parsingRulesFile);
          newDigester.addRuleSet(ruleSet);
        }
      }
    }
    return newDigester;
  }
}
