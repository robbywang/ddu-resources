package com.nortel.cdma.service.csl.sls.filter.common;
/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

/**
 * Exception class for use when a datastream does not match
 * the input schema. The filter will flush the input buffer
 * in an attempt to re-synchronize the stream with the schema.
 */
public class ParsingException extends ProcessingException {

  /**
   * Explanation of the failure associated with this exception.
   */
  private static final String MESSAGE =
    "Data stream did not match input schema; Reason: ";

  /**
   * Constructor.
   *
   * @param text detailed explanation of error
   */
  public ParsingException(String text) {

    super(MESSAGE + text);
    this.messageDetail = text;
  }

}
