/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.common;

import com.nortel.cdma.service.csl.sls.filter.types.DataType;
import com.nortel.cdma.service.csl.sls.filter.types.UnionType;
import com.nortel.cdma.service.csl.sls.filter.types.EnumType;
import com.nortel.cdma.service.csl.sls.filter.types.VoidType;

import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

//Debug logging
import org.apache.log4j.Logger;


/**
 * Collects all of the attributes of a {@link UnionType Union}-type field and
 * creates the field.
 * The XML input schema is parsed by Apache Commons Digester. The input schema
 * contains both {@link Field} and {@link UnionType Union} definitions. A union is
 * simply a field of type union, but since unions are distinctly identifed in the
 * schema, they need to be handled separately.
 * <p>
 * For each union it
 * encounters in the input schema, the Digester creates a UnionAttributes object and
 * populates the attributes from the information in the schema.
 * The Digester then invokes
 * the createField method on the "parent" object, which is typically a
 * (@link FieldList). The parent object invokes the UnionAttributes's
 * {@link UnionAttributes#createField} method,
 * which creates a {@link Field} object, gives it a UnionType data type, and sets the
 * attributes.
 */
public class UnionAttributes extends FieldAttributes {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(UnionAttributes.class);

  /**
   * Name of the field whose value is to be used to select the active union case.
   */
  private String    discriminant = null;

  /**
   * The discriminant field object.
   */
  private Field     discriminantField = null;

  /**
   * Indicates whether the discriminant should be output with the union field.
   */
  private String    outputDiscriminant = null;

  /**
   * Constant value to indicate the discriminant should not be output.
   */
  private static final String DONT_OUTPUT_DISCRIMINANT = "no";

  /**
   * Reference to a specific bit subfield when the discriminant field is a bitmap.
   */
  private String    bitref  = null;

  /**
   * The union cases. Each case is a distinct field with an associated
   * selector value.
   */
  private Map<String, FieldAttributes> unionCases;

  /**
   * The value associated with the next case field to be defined. As the input
   * schema is being parsed, the caseValue will be extracted first, followed by the
   * field associated with that value. This attribute stores the value until the
   * case (field + value) can be defined.
   */
  private String    caseSelectorValue = null;

  /**
   * The list of all defined case selectors.
   */
  private List<String> caseSelectors = null;

  /**
   * Constructs a new empty UnionAttributes object. This parameterless constructor
   * is required by the datatype definitions Digester parsing rules.
   */
  public UnionAttributes() {

    caseSelectors = new ArrayList<String>();
    unionCases = new HashMap<String, FieldAttributes>();
  }

  /**
   * Sets the discriminant attribute. This method is referenced by the input schema
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   *
   * @param text    the text to be used as the discriminant name
   */
  public void setDiscriminant(String text) {
    discriminant = text;
  }

  /**
   * Returns the discriminant field.
   *
   * @return    the field that is to be used as the discriminant
   */
  public Field getDiscriminantField() {
    return discriminantField;
  }

  /**
   * Sets the bitref attribute. This method is referenced by the input schema
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   * @see #getOutputdiscriminant
   * @param text    the text to be used as the outputDiscriminant setting
   */
  public void setOutputdiscriminant(String text) {
    outputDiscriminant = text;
  }

  /**
   * Returns the outputDiscriminant attribute.
   * @see #setOutputdiscriminant
   * @return  the outputDiscriminant attribute
   */
  public String getOutputdiscriminant() {
    return outputDiscriminant;
  }

  /**
   * Sets the bitref attribute. This method is referenced by the input schema
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   *
   * @param text    the text to be used as the bitref setting
   */
  public void setBitref(String text) {
    bitref = text;
  }

  /**
   * Sets the caseSelectorValue attribute. This method is referenced by the
   * input schema Digester parsing rules XML file, therefore any changes
   * made to this method's signature must be reflected in the parsing rules
   * as well.
   *
   * @param value the text to be used as the case selector value
   */
  public void setValue(String value) {
    caseSelectorValue = value;
    caseSelectors.add(value);
  }

  /**
   * Adds a datatype or a field which will be a subfield of the current
   * element. This is used in struct types, unions, and bitmaps. This
   * method is referenced by the input schema Digester parsing rules XML
   * file, therefore any changes made to this method's signature must be
   * reflected in the parsing rules as well.
   *
   * @param attributes an object that contains the information
   *          necessary to create the subfield object
   */
  @Override
  public void addElement(DataTypeAttributes attributes) {

    if (attributes == null) {
      log4jDebugLogger.error("DataTypeAttributes is null");
    }
    else {
      if (attributes instanceof FieldAttributes) {

        unionCases.put(caseSelectorValue, (FieldAttributes) attributes);
      }
      else {
        super.addElement(attributes);
      }
    }
  }

  /**
   * Creates the datatypes and fields that are children of the current
   * element. The child elements are added during parsing by method
   * {@link #addElement}, but cannot be are not fully instantiated until
   * parsing is completed.
   *
   * @param parent the list of elements (hierarchy level) which contains
   *          the current element
   */
  @Override
  public void createSubElements(FieldList parent) {

    super.createSubElements(parent);

    Field           field;
    FieldAttributes fieldAttributes;

    subFields = new FieldList(parent);

    for (String selector : caseSelectors) {

      fieldAttributes = unionCases.get(selector);
      if (fieldAttributes == null) {
        // A case with no defined field. Add it to the case
        // list as a void field.
        subFields.addField(selector, new Field(new VoidType(), selector));
      }
      else {
        fieldAttributes.createSubElements(subFields);
        field = fieldAttributes.createField(subFields);
        subFields.addField(selector, field);
      }
    }
  }

  /**
   * Creates the union field object using the specified attributes.
   *
   * @param parent the list of elements (hierarchy level) which contains
   *          the current element
   * @return the Field object that was created
   */
  @Override
  public Field createField(FieldList parent) {

    Field field = null;

    if (parent == null) {
      log4jDebugLogger.error("Failed to define field, null FieldList");
    }
    else if (name == null) {
      log4jDebugLogger.error("Field definition missing name");
    }

    else if ((subFields == null) || subFields.size() < 1) {
      log4jDebugLogger.error("Union field definition missing cases; name='" + name + "'");
    }
    else if ((subFields.isValid())) {

      // Get the discriminant field object.
      if (discriminant == null) {
        log4jDebugLogger.error("Union field definition missing discriminant; name='" + name + "'");
      }
      else {
        discriminantField = parent.getField(discriminant);

        if ((bitref != null) && (discriminantField != null)) {
          discriminantField = discriminantField.getField(bitref);
        }
        if (discriminantField == null) {
          log4jDebugLogger.error("Union field definition discriminant reference not found; "
                               + "name='" + name + "' discriminant='" + discriminant + "'");
        }
        else {
          // Don't need to separately output the discriminant if it occurs
          // immediately before the union in the data stream.
          if (discriminantField.equals(parent.getLastField())) {
            outputDiscriminant = DONT_OUTPUT_DISCRIMINANT;
          }

          DataType discriminantType = discriminantField.getType();

          if (discriminantType instanceof EnumType) {
            // It's possible that the input schema contains case values
            // as a mix of enum names or actual values, so make them
            // consistent.
            if (!reAssignEnumCaseKeys((EnumType)discriminantType, parent)) {
              return null;
            }
          }
          // Although the XML schema differentiates between 'field' and 'union', we
          // just handle a union as a field with a datatype of 'union'.
          typeName = "union";
          field = super.createField(parent);
        }
      }
    }
    return field;
  }

  /**
   * Checks the keys associated with the individual union cases to
   * determine whether they represent an Enum value or the Enum
   * name. If the name, the key is changed to be the value so that
   * all of them are consistent.
   *
   * @param discriminantType the discriminant datatype, which is an
   *        enumerated type
   * @param parent the list of elements (hierarchy level) which contains
   *          the current element
   * @return true if successful, otherwise false
   */
  private boolean reAssignEnumCaseKeys(EnumType  discriminantType,
                                       FieldList parent) {

    boolean result = false;

    if (discriminantType != null) {

      FieldList        newCases = new FieldList(parent);
      Iterator<String> iterator = subFields.mapIterator();
      Field            field    = null;
      String           oldKey   = null;
      int              newKey;

      while (iterator.hasNext()) {
        oldKey = iterator.next();
        field = subFields.getField(oldKey);

        if (field != null) {
          newKey = discriminantType.getMapping(oldKey);

          if (newKey == EnumType.NONEXISTANT_ENUM_VALUE) {
            // oldKey is not an enumeration name, it must be the value, so use it.
            newCases.addField(oldKey, field);
          }
          else {
            // oldKey is an enumeration name, so use the value instead.
            newCases.addField(String.valueOf(newKey), field);
          }
        }
      }
      subFields = newCases;
      result = true;
    }
    return result;
  }
}
