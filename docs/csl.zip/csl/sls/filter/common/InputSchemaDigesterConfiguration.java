package com.nortel.cdma.service.csl.sls.filter.common;
/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

import org.apache.commons.digester.Digester;
import org.xml.sax.InputSource;

/**
 * A configuration for the Apache Commons Digester appropriate for
 * parsing the XDRLiteConverter input schema file.
 */
public class InputSchemaDigesterConfiguration extends DigesterConfiguration {

  /**
   * Constructor.
   */
  public InputSchemaDigesterConfiguration() {

    super();
  }

  /**
   * Constructor that allows a parsing rules XML file to
   * be specified for configuring the digester.
   * @param parsingRules an XML file containing digester
   *        parsing rules
   */
  public InputSchemaDigesterConfiguration(InputSource parsingRules) {

    super(parsingRules);
  }

  /**
   * Creates and configures a Digester with parsing rules appropriate
   * for parsing the XDRLiteConverter datatypes file. The XML version
   * of these rules is as follows: (replace '?' with '*')
   *
   * <digester-rules>
   *    <pattern value="?/field>
   *       <object-create-rule classname=
   *        "com.nortel.cdma.service.csl.sls.filter.FieldAttributes"/>
   *       <set-next-rule methodname="addElement"/>
   *       <set-properties-rule/>  <!-- for attribute 'maxlength' in variableArray  -->
   *       <pattern value='name'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='datatype'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='displayname'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='description'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='arraysize'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='arrayelementtype'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='values'>
   *          <!-- Define the values of an enum or bitmap field -->
   *          <object-create-rule classname=
   *           "com.nortel.cdma.service.csl.sls.filter.ValueMap"/>
   *          <pattern value='value'>
   *             <call-method-rule methodname='setValue' paramcount='2'/>
   *             <call-param-rule paramnumber='0' attrname='name'/>
   *             <call-param-rule paramnumber='1'/>
   *          </pattern>
   *          <set-next-rule methodname='setMapping'/>
   *       </pattern>
   *    </pattern>
   *
   *    <pattern value='?/union'>
   *       <object-create-rule classname=
   *        "com.nortel.cdma.service.csl.sls.filter.UnionAttributes"/>
   *       <set-next-rule methodname="addElement"/>
   *       <set-properties-rule/>  <!-- for attributes 'discriminant' and 'outputDiscriminant'   -->
   *       <pattern value='name'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='discriminant'>
   *          <bean-property-setter-rule/>
   *          <set-properties-rule/>  <!-- for attribute 'bitref' -->
   *       </pattern>
   *       <pattern value='case'>
   *          <set-properties-rule/>  <!-- to set case value from attribute -->
   *       </pattern>
   *    </pattern>
   *
   *    <pattern value='?/typedef'>
   *       <object-create-rule classname=
   *        "com.nortel.cdma.service.csl.sls.filter.DataTypeAttributes"/>
   *       <set-next-rule methodname="addElement"/>
   *       <pattern value='name'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='datatype'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='displayname'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='description'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='values'>
   *          <!-- Define the values of an enum or bitmap field -->
   *          <object-create-rule classname=
   *           "com.nortel.cdma.service.csl.sls.filter.ValueMap"/>
   *          <pattern value='value'>
   *             <call-method-rule methodname='setValue' paramcount='2'/>
   *             <call-param-rule paramnumber='0' attrname='name'/>
   *             <call-param-rule paramnumber='1'/>
   *          </pattern>
   *          <set-next-rule methodname='setMapping'/>
   *       </pattern>
   *   </pattern>
   *</digester-rules>
   *
   * @return a configured Digester
   */
  @Override
  protected Digester configureDigester() {

    Digester newDigester = super.configureDigester();

    if (newDigester != null) {
      if (parsingRulesFile == null) {
        // Configure default parsing rules.
        newDigester.addObjectCreate("*/field",
                   "com.nortel.cdma.service.csl.sls.filter.common.FieldAttributes");
        newDigester.addSetNext("*/field", "addElement");
        newDigester.addSetProperties("*/field");  // for attribute 'maxlength' in variableArray
        newDigester.addBeanPropertySetter("*/field/name");
        newDigester.addBeanPropertySetter("*/field/datatype");
        newDigester.addBeanPropertySetter("*/field/displayname");
        newDigester.addBeanPropertySetter("*/field/description");
        newDigester.addBeanPropertySetter("*/field/arraysize");
        newDigester.addBeanPropertySetter("*/field/outputformat");
        newDigester.addBeanPropertySetter("*/field/arrayelementtype");

        newDigester.addObjectCreate("*/field/values",
                    "com.nortel.cdma.service.csl.sls.filter.common.ValueMap");
        newDigester.addCallMethod("*/field/values/value", "setValueObject", 3);
        newDigester.addCallParam("*/field/values/value", 0, "name");
        newDigester.addCallParam("*/field/values/value", 1);
        newDigester.addCallParam("*/field/values/value", 2, "displayname");
        newDigester.addSetNext("*/field/values", "setMapping");

        newDigester.addObjectCreate("*/union",
                   "com.nortel.cdma.service.csl.sls.filter.common.UnionAttributes");
        newDigester.addSetNext("*/union", "addElement");
        newDigester.addSetProperties("*/union");  // for attribute 'discriminant' and 'outputdiscriminant'
        newDigester.addBeanPropertySetter("*/union/name");
        newDigester.addBeanPropertySetter("*/union/displayname");
        newDigester.addBeanPropertySetter("*/union/description");
        newDigester.addBeanPropertySetter("*/union/discriminant");
        newDigester.addSetProperties("*/union/discriminant"); // for attribute 'bitref'

        newDigester.addSetProperties("*/union/case");  // to set case value from attribute

        newDigester.addObjectCreate("*/typedef",
                   "com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes");
        newDigester.addSetNext("*/typedef", "addElement");
        newDigester.addBeanPropertySetter("*/typedef/name");
        newDigester.addBeanPropertySetter("*/typedef/datatype");
        newDigester.addBeanPropertySetter("*/typedef/displayname");
        newDigester.addBeanPropertySetter("*/typedef/description");
        newDigester.addBeanPropertySetter("*/typedef/value");
        newDigester.addBeanPropertySetter("*/typedef/outputformat");

        newDigester.addObjectCreate("*/typedef/values",
                   "com.nortel.cdma.service.csl.sls.filter.common.ValueMap");
        newDigester.addCallMethod("*/typedef/values/value", "setValueObject", 3);
        newDigester.addCallParam("*/typedef/values/value", 0, "name");
        newDigester.addCallParam("*/typedef/values/value", 1);
        newDigester.addCallParam("*/typedef/values/value", 2, "displayname");
        newDigester.addSetNext("*/typedef/values", "setMapping");
      }
    }

    return newDigester;
  }
}
