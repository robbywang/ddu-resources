/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.common;

import com.nortel.cdma.service.csl.sls.filter.types.DataType;
import com.nortel.cdma.service.csl.sls.filter.types.UnionType;

//Debug logging
import org.apache.log4j.Logger;


/**
 * Associates a data type with a specific offset in a data stream. In addition to
 * several descriptive attributes (name, description, etc.) a Field has an offset
 * and a datatype. The offset indicates the specific location of the field in a
 * data stream relative to the start of the record, and the datatype determines
 * the length and structure (i.e. how the bits of the field should be interpreted).
 */
public class Field implements Cloneable {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(Field.class);

  /**
   * The name of the Field.
   */
  private String      name = null;

  /**
   * String constant used when generating a text representation of a field.
   */
  private static final String NAME_LABEL = "name";

  /**
   * A name used for display purposes. If not specified with the field definition
   * in the input schema, it remains null.
   */
  private String      displayName = null;

  /**
   * String constant used when generating a text representation of a field.
   */
  private static final String DISPLAYNAME_LABEL = "displayName";

  /**
   * A text description of the field. If not specified with the field definition
   * in the input schema, it remains null.
   */
  private String      description = null;

  /**
   * String constant used when generating a text representation of a field.
   */
  private static final String DESCRIPTION_LABEL = "description";

  /**
   * The data type associated with the Field.
   */
  private DataType    type = null;

  /**
   * The offset of the Field from the start of the input record.
   */
  private int         inputOffset = -1;

  /**
   * The offset of the Field from the start of the output record.
   */
  private int         outputOffset = -1;

  /**
   * String constant used when generating a text representation of a field.
   */
  private static final String FIELD_LABEL = "field";

  /**
   * String constant used when generating a text representation of a field.
   */
  private static final String UNION_LABEL = "union";

  /**
   * The field output format which is defined in input schema.
   */
  private String format = "default";


  /**
   * Constructs a Field with the given name and data type.
   *
   * @param fieldType   the data type of the Field
   * @param fieldName   the name of the Field
   */
  public Field(DataType fieldType, String fieldName) {

    if (fieldType == null) {
      log4jDebugLogger.error("Creating field without datatype");
    }
    else {
      type = fieldType;
    }

    if (fieldName == null) {
      log4jDebugLogger.error("Creating field without field name");
      name = "?";
    }
    else {
      name = fieldName;
    }
  }

  /**
   * Returns the name of the field.
   * @see #setName
   * @return    the name of the field
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the name of the field.
   * @see #getName
   * @param text    the new field name
   */

  public void setName(String text) {
    name = text;
  }

  /**
   * Returns the display name of the field.
   *
   * @return    the field's display name
   */
  public String getDisplayName() {
    return displayName;
  }

  /**
   * Returns the field description text.
   *
   * @return    the field description
   */
  public String getDescription() {
    return description;
  }

  /**
   * Sets the field datatype. Used when cloning the field.
   * @see #clone
   * @see #getType
   *
   * @param newtype the new type to be set for the field.
   */
  private void setType(DataType newtype) {
    type = newtype;
  }

  /**
   * Returns the field data type.
   * @see #setType
   * @return    the field data type object
   */
  public DataType getType() {
    return type;
  }

  /**
   * Returns the outputformat value.
   * @return the String value of output format
   */
  public String getOutputformat() {
    return format;
  }
  /**
   * Sets the attributes of the field based on information derived from an
   * attributes object.
   *
   * @param attributes  an object containing the attributes
   *                    needed to define the field
   */
  public void setAttributes(FieldAttributes attributes) {
    displayName = attributes.getDisplayname();
    description = attributes.getDescription();
    format =  attributes.getOutputformat();
  }

  /**
   * Marks the location of the field in the input buffer. The offset
   * of the field is set by this operation.
   *
   * @param buffer  the input buffer in which the field is being located
   * @return        the offset of the field in the buffer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  public int markFieldLocationInBuffer(InputBuffer buffer) throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException(errorString("InputBuffer is null"));
    }
    if (type == null) {
      throw new ProcessingException(missingTypeError());
    }
    inputOffset = buffer.getOffset();

    type.markFieldLocationInBuffer(buffer);

    return inputOffset;
  }

  /**
   * Returns the offset of the field in the input buffer.
   *
   * @return    the offset of the field in the input buffer
   */
  public int getInputOffset() {
    return inputOffset;
  }

  /**
   * Returns the offset of the field in the output buffer.
   *
   * @return    the offset of the field in the output buffer
   */
  public int getOutputOffset() {
    return outputOffset;
  }

  /**
   * Returns true if the field represents a numeric value (i.e. byte, integer,
   * long, or enum type).
   *
   * @return    true if the object is a numeric value
   */
  public boolean isNumeric() {

    if (type != null) {
      return type.isNumeric();
    }
    return false;
  }

  /**
   * Returns the field's value. This is only meaningful for numeric fields
   * that are 1, 2, or 4 bytes in length.
   *
   * @param buffer  the input buffer in which the field is located
   * @return        the value of the field, as an integer
   * @throws        ProcessingException if unable to parse the input data stream
   */
  public int getValue(InputBuffer buffer) throws ProcessingException {

    int value = 0;

    if (bufferNotNull(buffer)) {

      if (type == null) {
        throw new ProcessingException(missingTypeError());
      }
      value = type.getValue(buffer, inputOffset);
    }
    return value;
  }

  /**
   * Returns a subfield that has the specified name (if it exists).
   *
   * @param fieldName   the name of the subfield to be returned
   * @return            the subfield (if it exists), otherwise null
   */
  public Field getField(String fieldName)  {

    if ((fieldName != null) && (type != null)) {
      return type.getField(fieldName);
    }
    return null;
  }

  /**
   * Outputs the contents of the field.
   *
   * @param buffer  the input buffer in which the field is located
   * @param emitter the object that determines what aspect of the field to output
   * @throws        ProcessingException if unable to parse the input data stream
   */
  public void emitContents(InputBuffer buffer, FieldEmitter emitter)
    throws ProcessingException {

    if (bufferNotNull(buffer)) {
      if (emitter == null) {
        throw new ProcessingException(errorString("FieldEmitter is null"));
      }
      if (type == null) {
        throw new ProcessingException(missingTypeError());
      }
      if (inputOffset < 0) {
        throw new ParsingException(errorString("Offset not set"));
      }
      outputOffset = emitter.getOutputOffset();
      type.emitContents(buffer, inputOffset, emitter);
    }
  }

  /**
   * Returns a String (ASCII) interpratation of  the input buffer value.
   * @param sb the StringBuffer which contains the ASCII value
   * @param buffer the buffer containing the field value
   * @param level the level of the hierarchy, for indenting
   * @return a StringBuffer which contains the ASCII values of the fields in the buffer
   * @throws ProcessingException if the value could not be obtained
   * from the data buffer
   */
  public StringBuffer getASCIIOutput(StringBuffer sb, InputBuffer buffer, int level)
    throws ProcessingException {

    StringBuffer result = sb;
    if ((sb != null) && (buffer != null)) {
      String output = getASCIIFieldContents(buffer, level);
      sb.append(output);
    }
    return result;
  }

  /**
   * Returns a clone of this field. Any and all subfields are cloned as well.
   *
   * @return    an object that is a clone of this one
   */
  @Override
    public Field clone() {

    Field theClone = null;

    if (type == null) {
      log4jDebugLogger.error(missingTypeError());
    }
    else {
      try {
        theClone = (Field) super.clone();
        theClone.setType( type.clone());
      }
      catch (CloneNotSupportedException e) {
        // This class is a subclass of Object, which supports cloning.
        // Therefore we should never encounter this exception.
        log4jDebugLogger.error(errorString("Unable to clone field"), e);
      }
    }
    return theClone;
  }

  /**
   * Gives a field an opportunity to replace a reference to a specific
   * field which has been cloned with a reference to the clone. Data types
   * will override this method if they maintain a reference to other
   * fields.
   *
   * @param list  the list of cloned fields
   */
  public void updateReferences(FieldList list) {

    if (list == null) {
      log4jDebugLogger.error(errorString("FieldList is null"));
    }
    else {
      if (type == null) {
        log4jDebugLogger.error(missingTypeError());
        return;
      }
      type.updateReferences(list);
    }
  }

  /**
   * Checks whether the input buffer object is null.
   *
   * @param buffer  the input buffer
   * @return        true if the buffer is not null
   * @throws        ProcessingException if the buffer is null
   */
  private boolean bufferNotNull(InputBuffer buffer) throws ProcessingException {

    if (buffer == null) {
      throw new ProcessingException(errorString("InputBuffer is null"));
    }
    return true;
  }

  /**
   * Returns an error string with the field name appended.
   *
   * @param error the error string to be extended
   * @return      a string containing the error string with the
   *              field name appended
   */
  private String errorString(String error) {

    return error + "; name='" + name + "'";
  }

  /**
   * Returns an error string for the case where the field has no datatype.
   *
   * @return the error string indicating the field has no datatype
   */
  private String missingTypeError() {
    return errorString("Field has null datatype");
  }

  /**
   * Returns a string representation of the field definition.
   *
   * @param level the level of the hierarchy, for indenting
   * @return a string representation of the field
   */
  public String getXdrDefinition(int level) {

    StringBuffer sb = new StringBuffer();

    // Get the datatype definition.
    String typeDef = TextUtil.STRING_TERMINATOR;
    String label = FIELD_LABEL;

    if (type != null) {

      if (type instanceof UnionType) {

        label = UNION_LABEL;
        // If the discriminant is a reference to a bit in a bitmap,
        // output it as a field now.
        //Field discriminant = field.getD
        typeDef = type.getXdrDefinition(level);
      }
      else {
        typeDef = type.getXdrDefinition(level + 1);
      }

      if ((typeDef != null) && (!typeDef.equals(""))) {

        String attributes = type.getXdrDefinitionAttributes();
        if (attributes == null) {
          attributes = "";
        }
        sb.append(TextUtil.getDefinitionOpenString(level, label + attributes)
          + TextUtil.NEW_LINE);

        // Add the field name, displayname, description.
        sb.append(TextUtil.getDefinitionString(level + 1, NAME_LABEL, name));

        if (displayName != null) {
          sb.append(TextUtil.getDefinitionString(level + 1, DISPLAYNAME_LABEL,
            displayName));
        }

        if (description != null) {
          sb.append(TextUtil.getDefinitionString(level + 1, DESCRIPTION_LABEL,
            description));
        }

        // Add the datatype.
        sb.append(typeDef);

        sb.append(TextUtil.getDefinitionCloseString(level, label));
      }
    }

    return sb.toString();
  }

  /**
   * Returns a string containing the value of a field formatted with
   * name and type information.
   *
   * @param buffer the buffer containing the field value
   * @param isInBuffer true if the buffer is an input data
   *        buffer
   * @param level the level of the hierarchy, for indenting
   * @return a string representation of the field
   * @throws ProcessingException if the value could not be obtained
   * from the data buffer
   */
  public String getFieldValue(ExtendableBuffer buffer,
                              boolean isInBuffer, int level)
    throws ProcessingException {

    StringBuffer sb = new StringBuffer();
    int offset;

    if (isInBuffer) {
      offset = inputOffset;
    }
    else {
      offset = outputOffset;
    }
    if (offset < 0) {
      sb.append(TextUtil.STRING_TERMINATOR);
    }
    else {
      sb.append(TextUtil.toHexString(offset, 4) + " : ");

      // Add the field indent.
      sb.append(TextUtil.getIndent(level));

      // Add the name and type information.
      sb.append(name);

      if (type != null) {
        String typeClass[] = type.getClass().getName().split("\\.");
        String typeClassName = typeClass[typeClass.length - 1];
        sb.append(" : " + typeClassName);
      }

      try {
        sb.append(type.getValueAsString(buffer, isInBuffer, offset, level));
      }
      catch (ProcessingException e) {
        // e.printStackTrace(System.out);
        sb.append(TextUtil.NEW_LINE + TextUtil.STRING_TERMINATOR);
        throw e;
      }
    }
    return sb.toString();
  }

  /**
    * Gets Field string value for ASCII parsing.
    * @param buffer the buffer containing the field value
    * @param level the level of the hierarchy, for indenting
    * @return a string representation of the field
    * @throws ProcessingException if the value could not be obtained
    * from the data buffer
    */
   public String getASCIIFieldContents(InputBuffer buffer,
                                       int level)
     throws ProcessingException {

     StringBuffer sb = new StringBuffer("");

     if (buffer == null) {
       log4jDebugLogger.error("got null input buffer");
     }
     else {
       int offset = getInputOffset();

       if (offset < 0) {
         sb.append(TextUtil.STRING_TERMINATOR);
       }
       else {
         DataType type = getType();

         if (!(type instanceof UnionType)) {

           // Add the field indent.
         sb.append(TextUtil.getIndent(level));

           //Output the field display name (optional attribute in the schema).
           // If it is not defined in the schema, then output the field name (mandatory attribute).
           String fieldName = getDisplayName();
           if (fieldName == null){
             fieldName = getName();
           }
           sb.append(fieldName);
         }

         try {
           String format = getOutputformat();
           sb = type.getASCIIContent(sb, buffer, offset, level, format);
         }
         catch (ProcessingException e) {
           //e.printStackTrace(System.out);
           sb.append(TextUtil.NEW_LINE + TextUtil.STRING_TERMINATOR);
           throw e;
         }
       }
     }
     return sb.toString();
   }

}
