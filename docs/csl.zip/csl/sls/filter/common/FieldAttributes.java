/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.common;


import com.nortel.cdma.service.csl.sls.filter.types.DataType;

//Debug logging
import org.apache.log4j.Logger;

/**
 * Collects all of the attributes of a {@link Field} and creates the field.
 * When the XML input schema is parsed by Apache Commons Digester it creates a
 * {@link FieldAttributes} object for each field it encounters in the input schema
 * and populates the attributes from the information in the schema. The Digester then
 * invokes the createField method on the "parent" object, which is typically a
 * {@link FieldList}, but it could be another FieldAttributes (e.g. when subfields are
 * being created). The parent object invokes the FieldAttributes's
 * {@link FieldAttributes#createField}
 * method, which creates the Field object, sets the attributes, and associates the
 * appropriate data type object with it.
 */
public class FieldAttributes  extends DataTypeAttributes {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(FieldAttributes.class);

  /**
   * A reference to the field, which may or may not be the same as the field name.
   * For a field that is a union case, the reference is set to be the case value
   * rather than the field name.
   * @see UnionAttributes
   */
  private String       reference = null;

  /**
   * If the field is a fixed-size array, specifies the array size. If the
   * field is a variable-size array, specifies the maximum array size. The
   * arraysize is retrieved from the input schema as a string, but it must
   * be a valid numeric string, otherwise an exception will be thrown when
   * the field is created and the arraysize is converted to an integer.
   */
  private String       arraySize = null;

  /**
   * If the field is an array, specifies the data type of the array elements.
   */
  private String       arrayElementType = null;

  /**
   * Field output format.
   */
  private String       format = null;


  /**
   * Constructs a FieldAttributes object with uninitialized attributes. This
   * parameterless constructor is required by the input schema Digester
   * parsing rules.
   *
   */
  public FieldAttributes() {
  }

  /**
   * Sets the name attribute. Overrides the default implementation to set
   * the reference attribute as well.
   * This method is referenced by the input schema
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   *
   * @param text     the text to be used as the name.
   */
  @Override
    public void setName(String text) {
    name = text;
    reference = name;   // By default the reference is the same as the name.
  }

  /**
   * Sets the reference attribute.
   * @see #getReference
   * @param text    the field reference attribute
   */
  public void setReference(String text) {
    reference = text;
  }

  /**
   * Returns the reference attribute.
   * @see #setReference
   * @return    the field reference attribute.
   */
  public String getReference() {
    return reference;
  }

  /**
   * Sets the array size (for array type fields). This method is referenced
   * by the input schema Digester parsing rules XML file, therefore any changes
   * made to this method's signature must be reflected in the parsing rules as
   * well.
   * @see #getArraysize
   * @param text    a numeric string representing the array size
   */
  public void setArraysize(String text) {
    arraySize = text;
  }

  /**
   * Sets the maximum array size (for variable-length arrays). This method is
   * referenced by the input schema Digester parsing rules XML file, therefore
   * any changes made to this method's signature must be reflected in the parsing
   * rules as well.
   * @param text    a numeric string representing the maximum array size
   */
  public void setMaxlength(String text) {
    arraySize = text;
  }

  /**
   * Returns the arraysize attribute.
   * @see #setArraysize
   * @return    the arraysize attribute
   */
  public String getArraysize() {
    return arraySize;
  }

  /**
   * Sets the array element type (for array type fields). This method is referenced
   * by the input schema Digester parsing rules XML file, therefore any changes
   * made to this method's signature must be reflected in the parsing rules as
   * well.
   *
   * @param text    the name of the data type of the array elements.
   */
  public void setArrayelementtype(String text) {
    arrayElementType = text;
  }

  /**
   * Returns the array element type name (for array type fields).
   *
   * @return    the name of the data type of the array elements.
   */
  public String getArrayElementType() {
    return arrayElementType;
  }

  /**
   * Returns the outputformat value.
   * @return outputformat value
   * @see #setOutputformat
   */
  public String getOutputformat() {
    return format;
  }

  /**
   * Specifies the outputformat value.
   * @param szFormat the outputformat value
   * @see #getOutputformat
   */
  public void setOutputformat(String szFormat) {
    format = szFormat;
  }

  /**
   * Creates the Field object using the specified attributes.
   *
   * @param parent  the list to which this Field will be added.
   *                    Not used here, but it is used by the subclass
   *                    {@link UnionAttributes}.
   * @return            the Field object that was created.
   */
  public Field createField(FieldList parent) {

    Field field = null;

    if (parent == null) {
      log4jDebugLogger.error("Parent FieldList is null");
    }
    else if (name == null) {
      log4jDebugLogger.error("Field definition missing name");
    }
    else if (typeName == null) {
      log4jDebugLogger.error("Field definition missing datatype; name='"+ name + "'");
    }
    else {
      DataType type = parent.getType(typeName, this);

      if (type == null) {
        log4jDebugLogger.error("Field definition has undefined datatype; name='" + name
          + "' datatype='" + typeName + "'");
      }
      else if (type.getName() != null) {

        // Create a field with the specified name and type.
        field = new Field(type, name);
        field.setAttributes(this);
      }
      //else {
      // Type exists, but unable to refine it due to invalid attributes.
      // Error messages have already been generated.
      //}
    }
    return field;
  }
}
