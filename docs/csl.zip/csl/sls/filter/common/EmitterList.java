/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.common;

import java.util.Iterator;
import java.util.Map;
import java.util.HashMap;
import java.util.Collection;

//Debug logging.
import org.apache.log4j.Logger;

/**
 * Maintains a hashmap associating {@link FieldEmitter} objects with
 * {@link Field} names.
 */
public class EmitterList implements Iterable {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(EmitterList.class);

  /**
   * A hashmap that associates a FieldEmitter object with a field name.
   */
  private Map<String, FieldEmitter> map = null;


  /**
   * Constructs a new empty EmitterList.
   */
  public EmitterList() {
    map = new HashMap<String, FieldEmitter>();
  }

  /**
   * Returns the number of emitters in the list.
   *
   * @return the number of emitters in the list
   */
  public int size() {
    return map.size();
  }

  /**
   * Creates a new emitter and adds it to the map.
   *
   * @param attributes  an object containing the information needed to
   *                    create the emitter
   */
  public void createEmitter(EmitterAttributes attributes) {

    if (attributes != null) {
      FieldEmitter emitter = attributes.create();

      if (emitter != null) {
        map.put(attributes.getName(), emitter);
      }
      else {
        log4jDebugLogger.error("Failed to create emitter");
      }
    }
  }

  /**
   * Returns the emitter associated with the specified field name from the
   * map. If no match is found, the default emitter (field name = "*") is
   * returned, if it exists.
   *
   * @param fieldName the name of the field for which the associated
   *          emitter is requested
   * @return the emitter associated with the specified field, or the
   *         default
   */
  public FieldEmitter getEmitter(String fieldName) {

    FieldEmitter emitter = null;

    if (fieldName != null) {
      emitter = map.get(fieldName);

      if (emitter == null) {
        emitter = map.get("*");
      }
    }
    return emitter;
  }

  /**
   * Returns an iterator over the Emitters in the hash map.
   *
   * @return    an iterator over the Emitters
   */
  public Iterator<FieldEmitter> iterator() {

    Collection<FieldEmitter> values = map.values();
    return values.iterator();
  }
}
