/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.common;

/**
 * Abstract of a class for generating output associated with a given Field.
 * No assumptions are made as to what an implementation might choose to
 * output - it could be the contents of the Field, or the name, or both, or
 * the description, or nothing at all.
 */
public abstract class FieldEmitter {

  /**
   * The output buffer.
   */
  protected ExtendableBuffer buffer;

  /**
   * The contents of the input buffer.
   */
  protected byte[] inputBufferContents;

  /**
   * Return the value of the offset at which new data will be appended to
   * this buffer.
   *
   * @return the value of the current buffer offset
   */
  public int getOutputOffset() {
    return buffer.getOffset();
  }

  /**
   * Sets various attributes.
   *
   * @param attributes   an object containing the attributes collected from the
   *                     XML configuration file
   */
  public void setAttributes(EmitterAttributes attributes) {
    // Default does nothing.
  }

  /**
   * Specifies the output buffer to which the filtered output should be
   * sent.
   *
   * @param input the input buffer
   * @param output the output buffer to which the filtered data should be
   *          output
   */
  public void configure(InputBuffer input, ExtendableBuffer output) {

    if ((input != null) && (output != null)) {

      buffer = output;
      inputBufferContents = input.toByteArray();
    }
  }

  /**
   * Outputs the contents of the specified field.
   * Override this method to determine what to output for each field,
   * e.g. use field.getName(), getDescription() etc. to output field
   * info along with or instead of the field contents.
   *
   * @param field   the field to be emitted
   * @param input   the input data buffer
   * @return false if the output should be discarded, otherwise true
   * @throws        ProcessingException if unable to parse the input
   *                data stream
   */
  public boolean emit(Field field, InputBuffer input)
    throws ProcessingException {

    // Default does nothing.
    return true;
  }

  /**
   * Invoked after all of the fields have been processed, giving an
   * emitter the opportunity to do any required post-processing of
   * the output record.
   * @param field   the field to be emitted.
   * @param input   the data buffer containing the current field instance
   * @return false if the output should be discarded, otherwise true
   * @throws ProcessingException
   */
  public boolean postProcess(Field field, InputBuffer input)
    throws ProcessingException {

    // Default does nothing.
    return true;
  }

  /**
   * Append the contents of a field to the output stream.
   * Invoked by a field is outputting its contents.
   * Override this method to route the output to a particular stream
   * (e.g. the console) or manipulate the output in some other way.
   *
   * @param bytes       the byte array to be appended to the end of the buffer
   * @param srcOffset   offset within the array to the start of the data to be appended
   * @param inputSize   the length (in bytes) of the data in the byte array to be appended
   * @param padLeft     if true, add any required padding to the left of the data,
   *                    otherwise add it on the right
   */
  public void appendContent(byte[] bytes, int srcOffset, int inputSize, boolean padLeft) {

    // Default implementation does nothing.
  }

  /**
   * Append the contents of a field to the output stream. Uses the input buffer as
   * the data source.
   *
   * @param srcOffset   offset within the array to the start of the data to be appended
   * @param inputSize      the length (in bytes) of the data in the byte array to be appended
   * @param padLeft     if true, add any required padding to the left of the data,
   *                    otherwise add it on the right
   */
  public void appendContent(int srcOffset, int inputSize, boolean padLeft) {

    // Default implementation does nothing.
  }
}
