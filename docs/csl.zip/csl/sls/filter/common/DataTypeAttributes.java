/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.common;

import java.util.List;
import java.util.ArrayList;
import com.nortel.cdma.service.csl.sls.filter.types.DataType;

//Debug logging
import org.apache.log4j.Logger;

/**
 * Collects all of the attributes of a data type and creates the
 * {@link DataType} object.
 * <p>
 * The datatype definitions XML file is parsed by Apache Commons Digester.
 * For each datatype it encounters in the definitions file, it instantiates
 * a DataTypeAttributes object and populates the attributes with the
 * information in the definition. The Digester then invokes the addElement
 * method on the 'parent' object, which could be a {@link FieldList} or
 * another DataTypeAttributes object.
 */
public class DataTypeAttributes {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(DataTypeAttributes.class);

  /**
   * The name of the data type.
   */
  protected String     name;

  /**
   * A name used for display purposes. If not specified with the field definition
   * in the input schema, it remains null.
   */
  private String      displayName;

  /**
   * A text description of the field. If not specified with the field definition
   * in the input schema, it remains null.
   */
  private String      description;

  /**
   *  The vlaue of the datatype attribute.
   */
  private String   value;


  /**
   * The name of the datatype associated with the field. This will be used
   * to retrieve a {@link DataType} object to associate with the field.
   */
  protected String    typeName;

  /**
   * The name of the class that implements the datatype. This is used
   * to instantiate the datatype object.
   */
  private String      className;

  /**
   * The size (in bytes) of a field of this datatype.
   */
  private int         mInputSize = DataType.INVALID_INPUTSIZE;

  /**
   * If the field type is an enumeration, specifies the names associated
   * with the various field values.
   */
  private ValueMap    mapping;

  /**
   * The subfields of the field, if it is a struct, union, or bitmap.
   */
  protected FieldList   subFields;

  /**
   * The field output format which is defined in input schema.
   */
  private String format = "default";

  /**
   * The list of elements discovered by the XML parser at this level of the
   * hierarchy. Elements may be fields ('field' tag) or datatypes
   * ('typedef' tag).
   */
  protected List<DataTypeAttributes> attributesList;

  /**
   * Constructs a DataTypeAttributes object with uninitialized attributes. This
   * parameterless constructor is required by the datatype definitions Digester
   * parsing rules.
   */
  public DataTypeAttributes() {
    attributesList = new ArrayList<DataTypeAttributes>();
  }

  /**
   * Sets the name attribute. This method is referenced by the datatype
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   * @see #getName
   * @param text    the name
   */
  public void setName(String text) {
    name = text;
  }

  /**
   * Returns the name attribute.
   * @see #setName
   * @return    the name attribute
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the displayname attribute. This method is referenced by the datatype
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   * @see #getDisplayname
   * @param text    the string value to be assigned to the displayname attribute
   */
  public void setDisplayname(String text) {
    displayName = text;
  }

  /**
   * Returns the displayname attribute.
   * @see #setDisplayname
   * @return    the value of the displayname
   */
  public String getDisplayname() {
    return displayName;
  }

  /**
   * Sets the value object.
   * @see #getValue
   * @param text    the string value to be assigned to the value attribute
   */
  public void setValue(String text) {
    value = text;
  }

  /**
   * Returns the value attribute.
   * @see #setValue
   * @return   the integer value
   */
  public String getValue() {
    return value;
  }

  /**
   * Sets the description attribute. This method is referenced by the datatype
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   * @see #getDescription
   * @param text    the string to be assigned to the description attribute
   */
  public void setDescription(String text) {
    description = text;
  }

  /**
   * Returns the description attribute.
   * @see #setDescription
   * @return    the value of the description attribute
   */
  public String getDescription() {
    return description;
  }

  /**
   * Sets the typeName attribute. This method is referenced by the datatype
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   * <p>
   * Note that although the attribute is called <em>typeName</em> (in order
   * to distinguish it from the datatype attribute, which is the actual datatype
   * object), the method name is <em>setDatatype</em> because it must match the
   * element name in the input schema, which is <em>datatype</em>.</p>
   *
   * @param text    the string to be assigned to the typeName attribute
   */
  public void setDatatype(String text) {
    typeName = text;
  }

  /**
   * Sets the classname attribute. This method is referenced by the datatype
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   *
   * @param text    the class name
   */
  public void setClassname(String text) {
    className = text;
  }

  /**
   * Returns the inputSize value.
   * @return the value of the input size
   * @see #setInputsize
   */
  public int getInputsize() {
    return mInputSize;
  }

  /**
   * Sets the input size. This method is referenced by the datatype
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   * @param size the value of the field size
   * @see #getInputsize
   */
  public void setInputsize(int size) {

    mInputSize = size;
  }

  /**
   * Returns the outputformat value.
   * @return the String value of output format
   * @see #setOutputformat
   */
  public String getOutputformat() {
    return format;
  }

  /**
   * Sets outputformat attributes.
   * @param sFormat the string value of outputformat
   * @see #getOutputformat
   */
  public void setOutputformat(String sFormat) {
    format = sFormat;
  }

  /**
   * Sets the mapping object which contains a collection of name-value pairs.
   * The mapping is used by enum datatypes to associate a name with a specific value.
   * This method is referenced by the input schema Digester parsing rules XML file,
   * therefore any changes made to this method's signature must be reflected in the
   * parsing rules as well.
   * @see #getMapping
   * @param values  the name-value mapping object
   */
  public void setMapping(ValueMap values) {
    mapping = values;
  }

  /**
   * Returns the name-value mapping (for enum datatypes).
   * @see #setMapping
   * @return    the name-value mapping
   */
  public ValueMap getMapping() {
    return mapping;
  }

  /**
   * Returns the list of subfields (for struct datatypes).
   *
   * @return    the list of subfields
   */
  public FieldList getSubFields() {
    return subFields;
  }

  /**
   * Adds a datatype or a field which will be a subfield of the current
   * element. This is used in struct types, unions, and bitmaps. This
   * method is referenced by the input schema Digester parsing rules XML
   * file, therefore any changes made to this method's signature must be
   * reflected in the parsing rules as well.
   *
   * @param attributes an object that contains the information
   *          necessary to create the subfield object
   */
  public void addElement(DataTypeAttributes attributes) {

    if (attributes == null) {
      log4jDebugLogger.error("DataTypeAttributes is null");
    }
    else {
      attributesList.add(attributes);
    }
  }


  /**
   * Method overload to permit invocation with no parameters.
   */
  protected void createSubElements() {
    createSubElements(null);
  }

  /**
   * Creates the datatypes and fields that are children of the current
   * element. The child elements are added during parsing by method
   * {@link #addElement}, but cannot be are not fully instantiated until
   * parsing is completed.
   *
   * @param parent the list of elements (hierarchy level) which contains
   *          the current element
   */
  protected void createSubElements(FieldList parent) {

    DataType dataType;
    Field    field;
    String   fieldReference;

    FieldAttributes fieldAttributes;

    subFields = new FieldList(parent);

    for (DataTypeAttributes attributes : attributesList) {

      if (attributes instanceof FieldAttributes) {

        // Creating a field
        fieldAttributes = (FieldAttributes) attributes;
        fieldAttributes.createSubElements(subFields);

        field = fieldAttributes.createField(subFields);
        fieldReference = fieldAttributes.getReference();
        subFields.addField(fieldReference, field);
      }
      else {

        // Creating a data type (i.e. 'typedef')
        attributes.createSubElements(subFields);
        dataType = attributes.createType(subFields);
        subFields.addType(attributes.getName(), dataType);
      }
    }
  }

  /**
   * Creates the DataType object using the specified class name.
   *
   * @param parent the list of elements (hierarchy level) which contains
   *          the current element
   * @return the DataType object, or null if unsuccessful
   */
  public DataType createType(FieldList parent) {

    Exception exception = null;
    DataType  datatype;

    if (parent == null) {
      log4jDebugLogger.error("Null data type list; type name='" + name + "'");
      datatype = null;
    }
    else {
      if ( (name == null)
        || ((typeName == null) && (className == null)) ) {
        // Invalid input.
        log4jDebugLogger.error("Invalid data type definition: name=" + name
          + " typename="+typeName+" className="+className);
        datatype = null;
      }
      else {
        if (typeName != null) {

          // Creating a new type from an existing base type. This handles the
          // 'typedef' construct in the input schema.
          datatype = parent.getType(typeName, this);

          if (datatype == null) {
            log4jDebugLogger.error("Data type definition based on undefined datatype; name='" + name
              + "' datatype='" + typeName + "'");
          }
        }
        else {
          // If typeName is null, then className isn't.
          // Creating a new type from a class. This handles the root data
          // types defined in the datatypes XML file.
          try {
            Class classDefinition = Class.forName(className);
            Object object = classDefinition.newInstance();

            if ((object != null) && (object instanceof DataType)) {
              datatype = (DataType) object;
              datatype.setAttributes(this);
            }
            else {
              log4jDebugLogger.error("Could not instantiate: " + className
                + " as a DataType subclass");
              datatype = null;
            }
          }
          catch (IllegalAccessException e) {
            exception = e;
            datatype = null;
          }
          catch (ClassNotFoundException e) {
            exception = e;
            datatype = null;
          }
          catch (InstantiationException e) {
            exception = e;
            datatype = null;
          }
        }
      }
    }
    if (exception != null) {
      log4jDebugLogger.error("Could not instantiate " + className);
      datatype = null;
    }
    return datatype;
  }
}
