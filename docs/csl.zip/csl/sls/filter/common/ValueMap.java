/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.common;


import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;


/**
 * A mapping between strings and integer values. The values may be specified as
 * integers or as numeric strings which will be converted to integers. Hexadecimal
 * strings (e.g. "0x..." are supported.
 */
public class ValueMap implements Iterable<String> {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(ValueMap.class);

  /**
   * The actual mapping.
   */
  private TreeMap<String, Value> values = null;

  /**
   * Indicates whether the list of values is usable for parsing input data.
   * Will be set to false if an error occurs while parsing the input schema.
   * This allows parsing to continue (and identify any other errors) but
   * prevents the invalid schema from being used to process data.
   */
  private boolean valid = true;

  /**
   * Constructs a new empty ValueMap.
   */
  public ValueMap() {
    values =  new TreeMap<String, Value> ();
  }

  /**
   * Returns an indication of whether the list is valid for parsing data.
   *
   * @return    true if the list is valid, false otherwise.
   */
  public boolean isValid() {
    return (valid && values.size() > 0);
  }

  /**
   * Sets the state to indicate that the list is valid for parsing data.
   *
   * @param  flag the boolean state to be set
   */
  private synchronized void setValid(boolean flag) {
    valid = flag;
  }

  /**
   * Adds a Value object which contains name, value and display name. The value must be a numeric string,
   * which will be converted to an integer. Hexadecimal strings (e.g. "0x..." are
   * supported. This method is referenced by the input schema Digester
   * parsing rules XML file, therefore any changes made to this method's
   * signature must be reflected in the parsing rules as well.
   *
   * @param valueName the name associated with the value
   * @param stringValue the value, specified as a string
   * @param display the display name
   * @see #getValueObject
   */
  public void setValueObject(String valueName, String stringValue, String display) {

    if (valueName == null) {
      log4jDebugLogger.error("ValueMap entry missing name");
      setValid(false);
    }
    else {
      if ((stringValue == null) || (stringValue.length() == 0)) {
        log4jDebugLogger.error("ValueMap entry missing value; valueName='" + valueName + "'");
        setValid(false);
      }
      else {
        int value = 0;

        try {
          if (stringValue.startsWith("0x")) {
            value = Integer.parseInt(stringValue.substring(2), 16);
          }
          else {
            value = Integer.parseInt(stringValue);
          }
          if (display == null) {
            display = "";
          }
          setValueObject(valueName, value, display);
        }
        catch (NumberFormatException e) {
          log4jDebugLogger.error("Value is not numeric; valueName='" + valueName + "'");
          setValid(false);
        }
      }
    }
  }

  /**
   * Adds a name-value pair. This method is referenced by the input schema
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   *
   * @param valueName the name associated with the value
   * @param value the value, specified as an integer
   * @param display the display name
   * @see #getValueObject
   */
  public void setValueObject(String valueName, int value, String display) {

    Value oValue = new Value (valueName, value, display);
    values.put(valueName, oValue);
  }

  /**
   * Obtains a value from the mapping, by name.
   *
   * @param valueName   the name of the value to be obtained
   * @return            the value associated with the specified name
   */
  public int getValue(String valueName) {

    int value = -1;
    Value oValue = getValueObject (valueName);
    if (oValue != null) {
      value = oValue.getValue();
    }
    return value;
  }

  /**
   * Returns the Value object with specified name.
   * @param valueName the name of the value object
   * @return the Value object
   * @see #setValueObject
   */
  private Value getValueObject (String valueName) {

    Value result = null;
    if (valueName != null) {
      result = values.get(valueName);
    }
    return result;
  }

  /**
   * Returns the Value display name with specified name.
   * @param valueName the name of the value object
   * @return the Value display name
   */
  public String getDisplayname (String valueName) {
    String result = "";
    Value oValue = getValueObject (valueName);
    if (oValue != null) {
      result = oValue.getDisplayname();
    }
    return result;
  }

  /**
   *
   * Returns the Value display name with specified integer value.
   * @param iValue the integer value of the value object
   * @return the Value display name
   */
  public String getDisplayname (int iValue) {
    String result = "";
    String keyName = getKey(iValue);
    if (keyName != null) {
      Value oValue = getValueObject (keyName);
      if (oValue != null) {
        result = oValue.getDisplayname();
      }
    }
    return result;
  }

  /**
   * Returns the value name (key with the specified integer value.
   * @param iValue the integer value of the value object
   * @return the value name
   */
  public String getKey (int iValue) {
    String result = null;
    for (Iterator<String> iter = this.iterator(); iter.hasNext();) {
      String  key = iter.next();
      if (key != null) {
        int iValueInMap = getValue(key);
        if (iValueInMap == iValue) {
          result = key;
        }
      }
    }
    return result;
  }
  /**
   * Returns true if this map maps one or more keys to the specified value.
   *
   * @param iValue value whose presence in this map is to be tested
   * @return true if this map maps one or more keys to the specified value
   */
  public boolean containsValue(int iValue) {
    return (getKey(iValue) != null);
  }

  /**
   * Returns an iterator over all of the names in the map.
   *
   * @return    an iterator over all of the names in the map
   */
  public Iterator<String> iterator() {

    Set<String> keys = values.keySet();

    if (keys != null) {
      return keys.iterator();
    }
    return null;
  }

  /**
   * Inner class for the Value object.
   */

  class Value  {

    /**
     *  The Value object's name.
     */
    private String name;

    /**
     *  The Value object's integer value.
     */
    private int value;
    /**
     *  The Value's display name.
     */
    private String display;


    /**
     * constructor.
     * @param szName the value object name
     * @param iValue the value object value
     * @param szDispalyname the value object displayname
     */
    Value (String szName, int iValue, String szDispalyname) {
      this.name = szName;
      this.value = iValue;
      this.display = szDispalyname;
    }

    /**
     * Gets the Value name.
     * @return value name
     * @see #setName
     */
    public String getName () {
      return name;
    }

    /**
     * Gets the Value object integer value.
     * @return  the value of the object
     * @see #setValue
     */
    public int getValue () {
      return value;
    }

    /**
     * Gets the Value object's display name.
     * @return the display name
     * @see #setDisplayname
     */
    public String getDisplayname () {
      return display;
    }

    /**
     * Sets Value object's name.
     * @param sName the object name
     * @see #getName
     */
    public void setName (String sName) {
      name = sName;
    }

    /**
     * Sets Value object's value.
     * @param iValue the object value
     * @see #getValue
     */
    public void setValue (int iValue) {
      value = iValue;
    }

    /**
     * Sets Value object's display name.
     * @param sDisplayname the object display name
     * @see #getDisplayname
     */
    public void setDisplayname (String sDisplayname) {
      display = sDisplayname;
    }
  }
}
