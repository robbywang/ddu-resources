/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.filter.common;

import com.nortel.cdma.service.csl.sls.filter.Filter;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import org.apache.commons.digester.Digester;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.PatternLayout;
import org.xml.sax.InputSource;

import java.util.Properties;
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.xml.sax.SAXException;
import org.apache.commons.digester.xmlrules.XmlLoadException;
/**
 * Base class for all Filters.
 */
public abstract class ParsingFilter extends Filter {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(ParsingFilter.class);


  /**
   * The Digester instance used to parse the schema files. It needs to be
   * static so that it can be obtained through a static method call by
   * objects instantiated by the digester during parsing.
   */
  protected static Digester mDigester = null;

  /**
   * The source of the rule set for parsing the list of data types.
   */
  protected InputSource mDatatypeRulesFile = null;

  /**
   * The source of the list of data types.
   */
  protected InputSource mDatatypeFile = null;

  /**
   * The source of the rule set for parsing the input schema.
   */
  protected InputSource mInputSchemaRulesFile = null;

  /**
   * The source of the input schema. The input schema may consist of more
   * than one file. This reference is to the root file, which may reference
   * other files via the XML XInclude mechanism.
   */
  protected InputSource mInputSchemaFile = null;

  /**
   * The data structure containing the list of {@link com.nortel.cdma.service.csl.sls.filter.common.Field} objects as
   * specified by the input schema. This list is used to parse the data in
   * the input stream.
   */
  protected FieldList mInputFields = null;

  /**
   * The source of the rule set for parsing the output schema.
   */
  protected InputSource mOutputSchemaRulesFile = null;

  /**
   * The source of the output schema.
   */
  protected InputSource mOutputSchemaFile = null;

  /**
   * The data structure containing the list of {@link com.nortel.cdma.service.csl.sls.filter.common.Field} objects as
   * specified by the input schema. This list is used to parse the data in
   * the input stream.
   */
  protected EmitterList mEmitters = null;

  /**
   * The data structure used to wrap the input stream and associate it with
   * the list of input fields. The buffer can have arbitrary-length byte
   * arrays appended to it; parsing the data with the input field list
   * determines where one record ends and the next begins.
   */
  protected InputBuffer mBuffer = null;

  /**
   * Indicates whether the converter has been successfully configured.
   */
  protected boolean mbConfigured = false;

  /**
   * The default path for locating configuration files.
   */
  protected static final String mszDefaultfilePath = "/opt/cems/cfg/csl/";

  /**
   * The default name of the configuration file, in case it cannot be
   * obtained from the filter properties.
   */
  protected  String mszDefault_Config;

  /**
   * The name of the property that specifies the datatype parsing rules
   * file name.
   */
  protected static final String DATATYPE_RULES_PROPERTY = "datatypeRulesFile";

  /**
   * The name of the property that specifies the datatype definitions file
   * name.
   */
  protected static final String DATATYPES_PROPERTY = "datatypesFile";

  /**
   * The default name of the datatypes file, in case it cannot be
   * obtained from the configuration file.
   */
  protected  String mszDefault_DataType_file;

  /**
   * The name of the property that specifies the input schema parsing rules
   * file name.
   */
  protected static final String INPUT_RULES_PROPERTY = "inputRulesFile";

  /**
   * The name of the property that specifies the input schema file name.
   */
  protected static final String INPUT_SCHEMA_PROPERTY = "inputSchemaFile";

  /**
   * The default name of the input schema file, in case it cannot be
   * obtained from the configuration file.
   */
  protected String mszDefault_input_schema;

  /**
   * The name of the property that specifies the output schema rules file
   * name.
   */
  protected static final String OUTPUT_RULES_PROPERTY = "outputRulesFile";

  /**
   * The name of the property that specifies the output schema file name.
   */
  protected static final String OUTPUT_SCHEMA_PROPERTY = "outputSchemaFile";

  /**
   * The default name of the output schema file, in case it cannot be
   * obtained from the configuration file.
   */
  protected String mszDefault_Output_Schema;

  /**
   * The incoming CSL log data type which is either XDRlite or XDR. This
   * variable is configurable since ASCII parser may have to handle different
   * type based on the user's instruction.
   */
  protected static String mszCSL_Datatype = "XDRLite";

  /**
   * Default constructor for the Filter object.
   */
  public ParsingFilter() {
    super();
  }

  /**
   * Sets the state to indicate that the filter is configured.
   *
   * @param flag the state to be set
   */
  protected synchronized void setConfigured(boolean flag) {
    mbConfigured = flag;
  }

  /**
   * Returns true if the filter has been sucessfully configured to process
   * data.
   *
   * @return true if the filter has been sucessfully configured to process
   *         data, otherwise false
   */
  public boolean isConfigured() {
    return mbConfigured;
  }

  /**
   * Starts up the plug-in filter.
   */
  protected void localStartup() throws  InvalidDeploymentException {

    // Just in case we're re-configuring a running instance with a new
    // input schema, get rid of any existing input buffer in order to make
    // a fresh start.
    mBuffer = null;
    setConfigured(false);

    // Load the properties.
    if (!loadProperties()) {
      handleConfigurationFailure("Failed to load properties");
    }
    else {
      // Load the datatypes.
      FieldList datatypes;

      //DigesterConfiguration config = new DatatypesDigesterConfiguration (datatypeRulesFile);
      DigesterConfiguration config = getDataTypeDigesterConfig(mDatatypeRulesFile);
      DataTypeAttributes rootElement = new DataTypeAttributes();

      if (!parseSchema(config, mDatatypeFile, rootElement)) {
        handleConfigurationFailure("Failed to parse datatype schema");
      }
      else {
        rootElement.createSubElements();
        datatypes = rootElement.getSubFields();

        if ((datatypes == null) || (!datatypes.isValid())) {
          handleConfigurationFailure("Failed to parse datatype schema");
        }
        else {
          // Load the input schema.

          config = getInputDigesterConfig(mInputSchemaRulesFile);
          rootElement = new FieldAttributes();

          if (!parseSchema(config, mInputSchemaFile, rootElement)) {
            handleConfigurationFailure("Failed to parse input schema");
          }
          else {
            rootElement.createSubElements(datatypes);
            mInputFields = rootElement.getSubFields();

            if (!mInputFields.isValid()) {
              handleConfigurationFailure("Invalid input schema");
            }
            else {
              // Load the output schema.
              mEmitters = new EmitterList();

              config   = getOutputDigesterConfig(mOutputSchemaRulesFile);

              if (!parseSchema(config, mOutputSchemaFile, mEmitters)) {
                handleConfigurationFailure("Failed to parse output schema");
              }
              else {
                if (mEmitters.size() < 1) {
                  handleConfigurationFailure("No emitters configured");
                }
                else {
                  // Success if we hit this
                  setConfigured(true);
                  if ( log4jDebugLogger.isEnabledFor(Level.INFO) ) {
                    String configDetail = datatypes.size() + " datatypes; "
                      + mInputFields.size() + " input fields; "
                      + mEmitters.size() + " emitters";
                    log4jDebugLogger.info("XDRLite filter successfully configured: " + configDetail);
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  /**
   * Utility method to generate a configuration failure log and throw InvalidDeploymentException.
   *
   * @param reason the reason the configuration failed
   * @throws InvalidDeploymentException
   */
  private void handleConfigurationFailure(String reason) throws InvalidDeploymentException {
    if (reason == null) {
      reason = "";
    }
    String errorMsg = "CSL Configuration failed: " + reason;
    log4jDebugLogger.error(errorMsg);
  //  throw new InvalidDeploymentException(errorMsg);
  }

  /**
   * Loads the properties from a Java XML-based (@link Properties) file.
   * @return true if successful, otherwise false
   */
  protected boolean loadProperties() {

    boolean     result = false;
    Properties  properties = new Properties();
    InputStream configuration;

    try {
      if (mszConfigFile == null) {
        mszConfigFile = mszDefault_Config;
      }

      log4jDebugLogger.debug("config file=" + mszConfigFile);

      if (mszConfigFile.equalsIgnoreCase("local")){
        InputStream  dInputStream = this.getClass().getClassLoader().getResourceAsStream("datatypes_mapping.xml");
        InputStream  aInputStream = this.getClass().getClassLoader().getResourceAsStream("ascii_outputSchema.xml");
        InputStream  sInputStream = this.getClass().getClassLoader().getResourceAsStream("streamlog_v1.xml");

        mDatatypeRulesFile = getInputSource(properties, DATATYPE_RULES_PROPERTY, null, false);
        mInputSchemaRulesFile = getInputSource(properties, INPUT_RULES_PROPERTY, null, false);
        mOutputSchemaRulesFile = getInputSource(properties, OUTPUT_RULES_PROPERTY, null, false);

        if (dInputStream == null) {
          log4jDebugLogger.error("Configuration file not found:  datatypes_mapping.xml");
        }
        else {
          mDatatypeFile = new InputSource(dInputStream);
        }

        if (aInputStream == null) {
          log4jDebugLogger.error("Configuration file not found:  ascii_outputSchema.xml");
        }
        else {
          mOutputSchemaFile = new InputSource(aInputStream);
        }
        if (sInputStream == null) {
          log4jDebugLogger.error("Configuration file not found:  datatypes_mapping.xml");
        }
        else {
          mInputSchemaFile = new InputSource(sInputStream);
        }

        result = true;
      }
      else {
        configuration = new BufferedInputStream(new FileInputStream(mszConfigFile));

        if (configuration != null) {
          properties.loadFromXML(configuration);
          configuration.close();

          mDatatypeRulesFile = getInputSource(properties, DATATYPE_RULES_PROPERTY, null, false);
          mDatatypeFile = getInputSource(properties, DATATYPES_PROPERTY,
           mszDefault_DataType_file, true);

          mInputSchemaRulesFile = getInputSource(properties, INPUT_RULES_PROPERTY, null, false);
          mInputSchemaFile       = getInputSource(properties, INPUT_SCHEMA_PROPERTY,
            mszDefault_input_schema, true);
          mOutputSchemaRulesFile = getInputSource(properties, OUTPUT_RULES_PROPERTY, null, false);
          mOutputSchemaFile       = getInputSource(properties, OUTPUT_SCHEMA_PROPERTY,
            mszDefault_Output_Schema, true);
          result = true;
        }
      }
    }
    catch (FileNotFoundException e) {
      log4jDebugLogger.error("Configuration file not found: " + mszConfigFile);
    }
    catch (IOException e) {
      log4jDebugLogger.error("Failed to read: " + mszConfigFile, e);
    }
    return result;
  }

  /**
   * Converts a file name to an InputSource object.
   *
   * @param p an object containing the configuration properties
   * @param pName the name of the property to be used as the file reference
   * @param defaultValue the value to use as the file reference if the
   *          property can't be retrieved
   * @param warn when true generate a warning if the property is not found
   * @return the file as an InputSource object
   */
  protected InputSource getInputSource(Properties p, String pName,
                                       String defaultValue, boolean warn) {
    String fileRef = null;

    if ((p != null) && (pName != null)) {

      String property = p.getProperty(pName);

      if (property != null) {
        fileRef = property.trim();
      }
      else if (warn) {
        log4jDebugLogger.warn("Missing property: " + pName);
        // Only a warning because default value will be used.
      }
    }
    if ((fileRef == null) && (defaultValue != null))  {
      fileRef = defaultValue;
      log4jDebugLogger.debug("No property specified; using default='" + defaultValue + "'");
    }
    if (fileRef != null) {
      try {
        log4jDebugLogger.debug(pName+"=" + fileRef);
        InputStream stream = new BufferedInputStream(new FileInputStream(fileRef));
        InputSource source = new InputSource(stream);
        return source;
      }
      catch (FileNotFoundException e) {
        log4jDebugLogger.error("File not found: " + fileRef);
      }
    }
    return null;
  }

  /**
   * Parses an XML schema file using Apache Commons Digester. This is used
   * to parse both the list of data types and the input schema.
   *
   * @param config an object containing the Digester configuration
   * @param schema reference to a file containing the schema to be parsed
   * @param digesterTarget an object to be used as the root of the Digester
   *          "stack"
   * @return true if able to successfully parse the file, otherwise false
   *
   */
  protected synchronized boolean parseSchema(DigesterConfiguration config,
                                             InputSource schema,
                                             Object      digesterTarget){

    // This method is synchronized because the objects may reference the
    // class variable 'digester' during parsing.
    Exception exception = null;
    boolean   result    = false;

    if (config == null) {
      log4jDebugLogger.error("DigesterConfiguration is null");
    }
    else if (schema == null) {
      // Errors have already been generated. Just drop out.
    }
    else if (digesterTarget == null) {
      log4jDebugLogger.error("digesterTarget is null");
    }
    else {
      mDigester = config.getDigester();

      if (mDigester == null) {
        log4jDebugLogger.error("Failed to create Digester");
        return false;
      }
      try {
        mDigester.push(digesterTarget);
        mDigester.parse(schema);
        result = true;
      }

      catch (IOException e) {
        exception = e;
      }
      catch (SAXException e) {
        exception = e;
      }
      catch (XmlLoadException e) {
        exception = e;
      }
      catch (Exception e) {  // Catch all exceptions so we don't break the SLS.
        exception = e;
      }

      if (exception != null) {
        log4jDebugLogger.error("Failed to parse schema, exception thrown", exception);
      }
    }
    return result;
  }

  /**
   * Accepts input data for filtering. The input data is appended to the
   * existing input buffer and an attempt is made to parse the contents of
   * the buffer by invoking the buffer's
   * {@link InputBuffer#processContent processContent} method. If the
   * buffer contains a complete record (as defined by the input schema)
   * then an output buffer is generated and forwarded to the downstream
   * receivers. This is repeated until no more records can be parsed from
   * the input (the output is null) and the remaining data in the buffer is
   * retained until additional input is appended to it the next time this
   * method is invoked.
   * <p>
   * If not properly configured, the input data is ignored and no output is
   * generated.
   * </p>
   *
   * @param inputData the input data to be filtered
   * @param iOffset the offset in the byte array of the data to be filtered
   * @param inputDataLength the length (in bytes) of the input data
   */
  public void handleStream(byte[] inputData, int iOffset, int inputDataLength) {

    if (inputData != null) {

      if ( iOffset != 0 ) {
        byte[] newArray = new byte[inputDataLength];
        System.arraycopy(inputData, iOffset, newArray, 0, inputDataLength);
        inputData = newArray;
      }

      if (isConfigured()) {

        if (inputDataLength > 0) {
          log4jDebugLogger.debug("Received "+inputDataLength+" bytes");

          if (mBuffer == null) {
            mBuffer = new InputBuffer(mInputFields);

            // Set the InputBuffer record size field length
            // and alignment values.
            int iLength = 2;
            int iAlignment = 1;

            if (mszCSL_Datatype.equalsIgnoreCase("XDR")) {
              iLength = 4;
              iAlignment = 4;
            }
            mBuffer.setSizeFieldLength(iLength);
            mBuffer.setFieldAlignment(iAlignment);
          }

          mBuffer.append(inputData, inputDataLength);

          ExtendableBuffer output   = null;

          do {
            try {
              output = mBuffer.processContent(mEmitters);
            }
            catch (ParsingException e) {

              log4jDebugLogger.error(e.getMessage());
              logInputRecordDebug();
              mBuffer.discardToEOR();
              output = new ExtendableBuffer();
            }
            catch (ProcessingException e) {

              // A serious problem occurred while processing the data
              // stream that suggests the configuration is messed up
              // badly, or we've hit a bug. Output the error with
              // traceback, and stop processing.

              output = null;
              stopProcessing("Failure processing data; filter has been disabled", e);
            }
            catch (Exception e) {
              output = null;
              stopProcessing("Failure processing data; filter has been disabled", e);
            }

            processResults(output);

          } while (output != null);
        }
      }
    }
  }

  /**
   * Helper method to stop process data.
   * @param szError the error message
   * @param e th exception
   */
  private void stopProcessing (String szError, Exception e) {
    log4jDebugLogger.error(szError, e);
    logInputRecordDebug();
    setConfigured(false);
  }
  /**
   * Configures the filter to run stand-alone.
   *
   * @param szFilterName the name of the filter
   * @param args the command line arguments
   * @param bVerbose when true generate verbose output
   */
  protected void runStandAlone(String   szFilterName,
                               String[] args,
                               boolean  bVerbose) {

    Logger logger = Logger.getRootLogger();
    PatternLayout layout = new PatternLayout("%-5p: %-21c{1} - %m%n");
    logger.addAppender(new ConsoleAppender(layout));


    logger.setLevel(Level.OFF);
    logger = Logger.getLogger("com.nortel.cdma.service.csl");

    if (bVerbose) {
      logger.setLevel(Level.DEBUG);
    }
    if (szFilterName == null) {
      log4jDebugLogger.error("Filter name is null.");
    }
    else if (args == null) {
      log4jDebugLogger.error("No arguments provided.");
    }
    else if (args.length < 2) {
      log4jDebugLogger.error("Insufficient number of arguments.");
    }
    else {
      String szConfigFilename = args[0];
      String szFilename = args[1];

      if (szConfigFilename == null) {
        log4jDebugLogger.error("Configuration file name is null.");
      }
      else if (szFilename == null) {
        log4jDebugLogger.error("Data file name is null.");
      }
      else {
        FileInputStream oFileInputStream = null;
        BufferedReader oBufferedReader = null;

        try {
          File oFile = new File(szFilename);
          long lFileLength = oFile.length();

          oFileInputStream = new FileInputStream( szFilename );

          byte[] bytes = new byte[(int) lFileLength];

          try {
            int iBytesRead = oFileInputStream.read(bytes);

            Properties oProperties = new Properties();
            oProperties.put("name", szFilterName);
            oProperties.put("configfile", szConfigFilename);

            this.config(oProperties);

            try {
              this.startup();

              log4jDebugLogger.debug("dataFile=" + szFilename);

              this.handleStream(bytes, 0, iBytesRead);
            }
            catch (InitializationFailureException e) {
              e.printStackTrace();
            }
            catch (InvalidDeploymentException e) {
              e.printStackTrace();
            }
          }
          catch (IOException e) {
            e.printStackTrace();
          }
        }
        catch (FileNotFoundException e) {
          e.printStackTrace();
        }
        finally{
          try {
            if ( oFileInputStream != null ) {
              oFileInputStream.close();
            }
          }
          catch (IOException e) {
            e.printStackTrace();
          }

          try {
            if ( oBufferedReader != null ) {
              oBufferedReader.close();
            }
          }
          catch (IOException e) {
            e.printStackTrace();
          }
        }
      }
    }
  }

  /**
   * Logs a description and hex dump of the input data record
   * for debugging.
   */
  protected void logInputRecordDebug() {

    if (log4jDebugLogger.isDebugEnabled()) {
      log4jDebugLogger.debug(TextUtil.NEW_LINE + mBuffer.getInputDataDescription());
      log4jDebugLogger.debug(TextUtil.NEW_LINE + "---- Input Record ----"
        + TextUtil.toHexDump(mBuffer.toByteArray())
        + TextUtil.NEW_LINE);
    }
  }

  /**
   *  Gets the digester configuration based on the input source of data types.
   * @param input the InputSource object which contains the datatypes definition
   * @return DigesterConfiguration
   */
  protected abstract DigesterConfiguration getDataTypeDigesterConfig(InputSource input);

  /**
   *  Gets the digester configuration based on the input source of input schema.
   * @param input the InputSource object which contains the input schema definition
   * @return DigesterConfiguration
   */
  protected abstract DigesterConfiguration getInputDigesterConfig(InputSource input);

  /**
   *  Gets the digester configuration based on the input source of output schema.
   * @param input the InputSource object which contains the output schema definition
   * @return DigesterConfiguration
   */
  protected abstract DigesterConfiguration getOutputDigesterConfig(InputSource input);

  /**
   * Prints the parsing result.
   * @param mOutput mOutput the ExtendableBuffer  which contains the output info
   */
  protected abstract void processResults (ExtendableBuffer mOutput);
}
