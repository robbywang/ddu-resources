package com.nortel.cdma.service.csl.sls.filter.common;
/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

import org.apache.commons.digester.Digester;
import org.xml.sax.InputSource;

/**
 * A configuration for the Apache Commons Digester appropriate for
 * parsing the XDRLiteConverter datatypes file.
 */
public class DatatypesDigesterConfiguration extends DigesterConfiguration {

  /**
   * Constructor.
   */
  public DatatypesDigesterConfiguration() {

    super();
  }

  /**
   * Constructor that allows a parsing rules XML file to
   * be specified for configuring the digester.
   * @param parsingRules an XML file containing digester
   *        parsing rules
   */
  public DatatypesDigesterConfiguration(InputSource parsingRules) {

    super(parsingRules);
  }

  /**
   * Creates and configures a Digester with parsing rules appropriate
   * for parsing the XDRLiteConverter datatypes file. The XML version
   * of these rules is as follows:
   *
   * <digester-rules>
   *    <pattern value="datatypes/datatype">
   *       <object-create-rule classname=
   *         "com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes"/>
   *       <set-next-rule methodname="addElement"/>
   *       <pattern value='name'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='classname'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *       <pattern value='inputsize'>
   *          <bean-property-setter-rule/>
   *       </pattern>
   *    </pattern>
   * </digester-rules>
   *
   * @return a configured Digester
   */
  @Override
  protected Digester configureDigester() {

    Digester newDigester = super.configureDigester();

    if (newDigester != null) {
      if (parsingRulesFile == null) {
        // Configure default parsing rules.
        newDigester.addObjectCreate("datatypes/datatype",
                   "com.nortel.cdma.service.csl.sls.filter.common.DataTypeAttributes");
        newDigester.addSetNext("datatypes/datatype", "addElement");
        newDigester.addBeanPropertySetter("datatypes/datatype/name");
        newDigester.addBeanPropertySetter("datatypes/datatype/classname");
        newDigester.addBeanPropertySetter("datatypes/datatype/inputsize");
      }
    }
    return newDigester;
  }
}
