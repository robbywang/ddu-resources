/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.common;

import java.util.Iterator;

//Debug logging
import org.apache.log4j.Logger;


/**
 * A mapping between an array of bytes (the buffer) and
 * a list of fields ({@link FieldList}). Methods are provided to append data to
 * the buffer, mark a field in the buffer, get the value of a field in
 * the buffer, and generate the filtered output from the buffer.
 */
public class InputBuffer {

  /**
   * Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(InputBuffer.class);

  /**
   * The buffer containing the input data.
   */
  private ExtendableBuffer buffer = null;

  /**
   * The fields to be mapped onto the data.
   */
  private FieldList inputFields = null;

  /**
   * The byte offset in the buffer indicating the start of the next field. While
   * iterating over the fields in the inputFields list, the size of each field
   * is determined and the currentOffset is shifted by that amount to identify
   * the start of the next field.
   */
  private int currentOffset = 0;

  /**
   * The length for CSL log size field. It is 4 for XDR data
   * and 2 for XDRLite.
   */
  private int miSizeFieldLength = 2;

  /**
   * The byte alignment of the input fields. The size of each field must be
   * a multiple of the alignment value; i.e. an alignment of 4 means that
   * all fields will start and end on 4-byte boundries.
   */
  private int miFieldAlignment = 1;


  /**
   * Default constructor. Creates an input data buffer and associates a list
   * of fields with it.
   *
   * @param fields  the list of fields to be used to parse the input data
   */
  public InputBuffer(FieldList fields) {

    buffer = new ExtendableBuffer();

    if (fields != null) {
      inputFields = fields;
    }
    else {
      log4jDebugLogger.error("FieldList is null");
    }
  }

  /**
   * Returns the contents of the buffer as a byte array.
   *
   * @return    a byte array containing the contents of the buffer
   */
  public byte[] toByteArray() {

    if (buffer != null) {
      return buffer.toByteArray();
    }
    log4jDebugLogger.debug("Buffer is null ");
    return null;
  }

  /**
   * Appends an array of bytes to the end of the buffer.
   *
   * @param inputStream the byte array to be appended
   * @param length      the length (in bytes) of the array to be appended
   * @return            the offset at which the data was appended
   */
  public int append(byte[] inputStream, int length) {

    int result = -1;

    if (inputStream != null) {
      if (buffer == null) {
        buffer = new ExtendableBuffer();
      }
      try {
        result = buffer.append(inputStream, length);
      }
      catch (BufferUnderflowException e) {
        log4jDebugLogger.error("Input stream shorter than declared length");
      }
    }
    return result;
  }

  /**
   * Discard data from the specified offset to the first end of record
   * marker.
   *
   * @return the number of bytes remaining in the buffer
   */
  public int discardToEOR() {

    return buffer.discardToEOR(currentOffset);
  }

  /**
   * Marks a field in the buffer by shifting the offset the length of the field.
   *
   * @param length  the number of bytes in the field being marked
   * @return        the offset of the field in the buffer
   * @throws        BufferUnderflowException if there is insufficient data
   *                in the buffer to accommodate the field length
   */
  public int markFieldLocation(int length) throws BufferUnderflowException {
    int result = currentOffset;
    currentOffset += length;

    if (currentOffset > buffer.getLength()) {
      throw new BufferUnderflowException("");
    }

    return result;
  }

  /**
   * Returns the current buffer offset.
   *
   * @return    the current buffer offset
   */
  public int getOffset() {
    return currentOffset;
  }

  /**
   * Extracts the value of a given field from the buffer. This is only valid for
   * integer, short, and byte numeric fields.
   *
   * @param field   the field whose value is to be extracted
   * @return        the integer value of the field
   * @throws        ProcessingException if unable to parse the input data stream.
   */
  public int getValue(Field field) throws ProcessingException {

    if (field == null) {
      throw new ProcessingException("Field is null");
    }
    return field.getValue(this);
  }

  /**
   * Extracts a value from the buffer, given a specific offset and number of bytes.
   * This is only valid for length = 1, 2, or 4 bytes.
   *
   * @param offset  location within the buffer where the value is to be extracted
   * @param length  number of bytes that comprise the value to be extracted
   * @return        the integer value of the specified byte sequence
   * @throws BufferUnderflowException if there is not sufficient data in the buffer
   *                to accommodate the request
   * @throws ProcessingException if an invalid buffer offset value is specified
   */
  public int getValue(int offset, int length)
    throws BufferUnderflowException, ProcessingException {

    int result = 0;
    if (buffer != null) {
      result = buffer.getValue(offset, length);
    }
    return result;
  }

  /**
   * Parses the data in the buffer by mapping the associated list of input
   * fields on to the buffer. If the contents of the buffer are
   * insufficient to map the entire list of input fields, then processing
   * stops at that point and can be continued after additional data has
   * been appended to the buffer. If the entire list of input fields is
   * mapped to the buffer, then it has a complete record and the filter
   * output is generated.
   *
   * @param emitters a list of objects that produce the output
   * @return a buffer containing the output data. Will be null if a
   *         complete record could not be parsed from the input
   * @throws ProcessingException if unable to parse the input data stream
   */
  public ExtendableBuffer processContent(EmitterList emitters)
         throws ProcessingException {

    ExtendableBuffer output = null;

    if ( (emitters != null)
      && (buffer != null)
      && (inputFields != null) ) {

      if (markFieldLocations()) {

        // We have a complete log, so generate the output.
        output = emit(emitters);

        // After generating the output, discard the front of the buffer
        // corresponding to the input record length.
        buffer.discard(currentOffset);
        currentOffset = 0;
      }
    }
    return output;
  }

  /**
   * Iterates over all the fields in the input schema and invokes the
   * associated emitter to generate the output.
   *
   * @param emitters a list of objects that produce the output
   * @return a buffer containing the output data. Will be null if a
   *         complete record could not be parsed from the input
   * @throws ProcessingException if unable to parse the input data stream
   */
  public ExtendableBuffer emit(EmitterList emitters)
         throws ProcessingException {

    ExtendableBuffer output = new ExtendableBuffer();

    configureEmitters(emitters, output);

    // Iterate over all the fields and generate the output
    boolean outputIsValid = true;

    for (Field field : inputFields) {

      if (field == null) {
        throw new ProcessingException("Null input field");
      }

      String fieldName = field.getName();
      if (fieldName == null) {
        throw new ProcessingException("Field name is null");
      }

      FieldEmitter emitter = emitters.getEmitter(fieldName);

      if (emitter == null) {
        throw new ProcessingException("Emitter is null");
      }

      outputIsValid = emitter.emit(field, this);

      if (!outputIsValid) {
        // Allows an emitter to filter (eliminate) the entire
        // record simply by returning false.
        output = null;
        break;  // Break out of iteration over fields.
      }
    }
    return output;
  }

  /**
   * Iterates over all the input fields to mark field positions, which could vary,
   * depending on the presence of variable arrays and optional data.
   *
   * @return	true if a complete record was parsed, otherwise false
   * @throws    ProcessingException if unable to parse the input data stream
   */
  private boolean markFieldLocations() throws ProcessingException {

    currentOffset = 0;
    boolean endOfInput = false;
    int     inputSize  = buffer.getLength();

    if (inputSize < miSizeFieldLength) {

      endOfInput = true;
    }
    else {

      int inputRecordSize = buffer.getValue(0, miSizeFieldLength);

      for (Field field : inputFields) {

        if (field != null) {
          try {
            field.markFieldLocationInBuffer(this);
          }
          catch (BufferUnderflowException e) {

            // Tried to parse data beyond the end of the input buffer.
            endOfInput = true;
            break;
          }
          if (currentOffset > inputSize) {
            endOfInput = true;
            break;
          }
        }
      }

      if (endOfInput) {
        // The record extends beyond the end of the input buffer.

        if (currentOffset > inputRecordSize) {
          // The data doesn't match the schema.

          throw new ParsingException("Record size insufficient; size=" + inputRecordSize
                                   + " currentOffset=" + currentOffset);
        }
      }
      else {
        // A complete record has been parsed.

        // Check record size.
        if (currentOffset != inputRecordSize) {
          throw new ParsingException("Record size incorrect; size=" + inputRecordSize
                                     + " currentOffset=" + currentOffset);
        }

        if (log4jDebugLogger.isDebugEnabled()) {

          int remainder = buffer.getLength() - currentOffset;

          log4jDebugLogger.debug("Parsed " + currentOffset+" bytes; "
                                + remainder + " bytes remaining");
        }
      }
    }
    return !endOfInput;
  }

  /**
   * Outputs an ASCII description of the input buffer for
   * debugging.
   *
   * @return A string containing the input buffer description
   */
  public String getInputDataDescription() {

    return getDataDescription(buffer, true);
  }

  /**
   * Outputs an ASCII description of the specified buffer for
   * debugging.
   *
   * @param dataBuffer the buffer containing the data to be debugged
   * @param isInput true if the buffer is input data,
   *                false if it is output data
   * @return A string containing the input buffer description
   */
  public String getDataDescription(ExtendableBuffer dataBuffer,
                                   boolean isInput) {

    StringBuffer sb = new StringBuffer();

    for (Field field : inputFields) {

      try {
        sb.append("\n" + field.getFieldValue(dataBuffer, isInput, 0));

        if (sb.toString().endsWith(TextUtil.STRING_TERMINATOR)) {
          break;
        }
      }
      catch (ProcessingException e) {
        log4jDebugLogger.error(e);
      }
    }
    return sb.toString() + TextUtil.NEW_LINE;
  }

  /**
   * Utility method for configuring the emitters before generating output.
   *
   * @param emitters the list of emitters to be configured
   * @param outputBuffer the output buffer to be used by the emitters
   */
  private void configureEmitters(EmitterList emitters, ExtendableBuffer outputBuffer) {

    //for (FieldEmitter emitter : emitters) {  // cast problem?
    if ((emitters != null) && (outputBuffer != null)) {

      Iterator<FieldEmitter> eIterator = emitters.iterator();
      FieldEmitter emitter;

      while (eIterator.hasNext()) {
        emitter = eIterator.next();
        if (emitter != null) {
          emitter.configure(this, outputBuffer);
        }
      }
    }
  }

  /**
   * Set the length for record size field.
   * @param iLength the length for record size field
   * @see #getSizeFieldLength()
   */
  public void setSizeFieldLength (int iLength) {
    miSizeFieldLength = iLength;
  }

  /**
   * Returns the offset for record size.
   * @return the offset for record size
   * @see #setSizeFieldLength
   */
  public int getSizeFieldLength() {
    return miSizeFieldLength;
  }

  /**
   * Set the Field alignment.
   * @param iAlignment the field alignment value
   * @see #getFieldAlignment
   */
  public void setFieldAlignment (int iAlignment) {

    if (iAlignment < 1) {
      log4jDebugLogger.error("Invalid field alignment value. alignment='" + iAlignment + "'");
    }
    else {
      miFieldAlignment = iAlignment;
    }
  }

  /**
   * Returns the field alignment value.
   * @return the field alignment value
   * @see #setFieldAlignment
   */
  public int getFieldAlignment() {
    return miFieldAlignment;
  }

  /**
   * Get the current offset in the buffer.
   * @return the current offset
   */
  public int getCurrentOffset() {
    return currentOffset;
  }

  /**
   * Get the ExtendableBuffer.
   * @return the ExtendableBuffer
   */

  public ExtendableBuffer getBuffer()  {
    return buffer;
  }
}
