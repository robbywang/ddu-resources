/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.common;

import com.nortel.cdma.service.csl.sls.filter.types.DataType;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.ListIterator;
import java.util.Iterator;


//Debug logging.
import org.apache.log4j.Logger;

/**
 * A list of {@link Field} objects. Fields are stored sequentially in the order
 * they were added, but a hash is also maintained to permit efficient access to
 * an individual field by name. Iterators can be obtained over the fields or over
 * the field names.
 */
public class FieldList implements Iterable<Field> {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(FieldList.class);

  /**
   * The list containing the Field objects in the order they were added.
   */
  private List<Field> fields = null;

  /**
   * The hash allowing random access to the Field objects.
   */
  private Map<String, Field> fieldMap = null;

  /**
   * Indicates whether the list of fields is usable for parsing input data.
   * Will be set to false if an error occurs while parsing the input schema.
   * This allows parsing to continue (and identify any other errors) but
   * prevents the invalid schema from being used to process data.
   */
  private boolean valid = true;

  /**
   * The list of data types that may be used to define the fields.
   */
  private Map<String, DataType> datatypes = null;

  /**
   * The list of elements (hierarchy level) which contains
   * the current element.
   */
  private FieldList  parent;

  /**
   * The list of elements discovered by the XML parser at this level of the
   * hierarchy. Elements may be fields ('field' tag) or datatypes
   * ('typedef' tag).
   */
  private List<DataTypeAttributes> attributesList;



  /**
   * Constructs a new empty FieldList. The collection of predefined
   * datatypes is specified as a parameter.
   *
   * @param parentList the parent of this list
   */
  public FieldList(FieldList parentList)  {

    parent    = parentList;
    fields    = new ArrayList<Field>();
    fieldMap  = new HashMap<String, Field>();
    datatypes = new HashMap<String, DataType>();
    setValid(true);
  }

  /**
   * Constructs a new empty FieldList with no parent list.
   */
  public FieldList() {

    this(null);
  }

  /**
   * Returns an indication of whether the list is valid for parsing data.
   *
   * @return    true if the list is valid, false otherwise
   */
  public boolean isValid() {
    return valid;
  }

  /**
   * Sets the state to indicate that the list is valid for parsing data.
   *
   * @param flag the value to set the state to
   */
  private synchronized void setValid(boolean flag) {
    valid = flag;
  }

  /**
   * Returns the number of fields in the list.
   *
   * @return the number of fields in the list
   */
  public int size() {
    return fields.size();
  }

  /**
   * Sets the list of datatypes to the specified list. Utility menthod used
   * when cloning a FieldList object.
   *
   * @param dataTypeList the list of datatypes
   */
  private void setDataTypes(Map<String, DataType> dataTypeList) {
    datatypes = dataTypeList;
  }

  /**
   * Adds a data type object to the collection.
   * @param  typeName the data type name
   * @param datatype    the datatype object to be added
   */
  public void addType(String typeName, DataType datatype) {

    if (datatype == null) {
      log4jDebugLogger.error("Failed to create data type");
      setValid(false);
    }
    else {

      if (typeName == null) {
        setValid(false);
      }
      else {
        if (datatypes.containsKey(typeName)) {
          log4jDebugLogger.warn("Duplicate data type; name='" + typeName + "'");
        }
        else {
          datatypes.put(typeName, datatype);
        }
      }
    }
  }

  /**
   * Obtains a data type object from the collection. The datatype's refine method is
   * invoked before returning it, which allows a type to (if necessary) return a clone
   * of itself with slightly different attributes, based on the field with which it is
   * to be associated. For example, an enum field with a unique set of values would
   * cause a new enum type object to be created.
   *
   * @param name        the name of the datatype to obtain
   * @param attributes  field attributes which might be needed to refine the datatype
   * @return            the required DataType object
   */
  public DataType getType(String name, DataTypeAttributes attributes) {

    DataType type = null;

    if ((name != null) && (attributes != null)) {

      type = datatypes.get(name);

      if (type != null) {

        // Allow the type to refine itself into a new data type.
        type = type.cloneWithNewAttributes(attributes);
      }
      else if (parent != null) {
        type = parent.getType(name, attributes);
      }
    }
    return type;
  }

  /**
   * Adds a Field to the list. If a key is specified, the field is added to
   * the hash map as well, so that it can be randomly accessed.
   *
   * @param key the string used to identify the field for random access
   * @param field the Field object to be added to the list
   */
  public void addField(String key, Field field) {

    if (field == null) {
      log4jDebugLogger.error("Failed to create field");
      setValid(false);
    }
    else if (fields.contains(field)) {
      log4jDebugLogger.error("Adding duplicate field; name='" + field.getName() +"'");
      setValid(false);
    }
    else {
      fields.add(field);

      addFieldToMap(key, field);
    }
  }

  /**
   * Adds a field to the hashmap. All fields are stored in a single hashmap
   * at the root level of the hierarchy, so the parent method is invoked
   * if a parent exists.
   *
   * @param key the string used to identify the field for random access
   * @param field the Field object to be added to the list
   */
  private void addFieldToMap(String key, Field field) {

    if (key != null) {

      if (fieldMap.containsKey(key)) {
        log4jDebugLogger.error("Adding duplicate key; name='" + field.getName()
                              +"' key=" + key +"'");
        setValid(false);
      }
      else {
        fieldMap.put(key, field);
      }
    }
  }

  /**
   * Adds a datatype or a field which will be a subfield of the current
   * element. This is used in struct types, unions, and bitmaps. This
   * method is referenced by the input schema Digester parsing rules XML
   * file, therefore any changes made to this method's signature must be
   * reflected in the parsing rules as well.
   *
   * @param attributes an object that contains the information
   *          necessary to create the subfield object
   */
  public void addElement(DataTypeAttributes attributes) {

    attributesList.add(attributes);
  }

  /**
   * Obtains a specific Field from the list. A field identifier (key) can
   * be a combination of parent field and sub field separated by a 'dot'
   * character.
   *
   * @param key the identifier of the the required Field
   * @return the specified Field
   */
  public Field getField(String key) {

    Field field = null;

    if (key != null) {
      field = this.getField(key, null);
    }
    return field;
  }

    /**
   * Obtains a specific Field from the list. A field identifier (key) can
   * be a combination of parent field and sub field separated by a 'dot'
   * character.
   *
   * @param key the identifier of the the required Field
   * @param alternateKey the identifier of a field to return if the
   *        primary key is not found
   * @return the specified Field
   */
  public Field getField(String key, String alternateKey) {

    Field field = null;

    if (key != null) {

      String[] keyItems = key.split("\\.");

      int numberOfKeys = 1;

      if ((keyItems != null) && ((numberOfKeys = keyItems.length) > 1))  {

        if (numberOfKeys == 2) {

          // This is a parent.child field reference.
          field = getField(keyItems[0]);

          if ((field != null) ) {
            field = field.getField(keyItems[1]);
          }
        }
        else {
          log4jDebugLogger.error("Invalid key; key=" + key +"'");
        }
      }
      else {
        field = fieldMap.get(key);

        if (field == null) {
          // Field not found

          if (alternateKey != null) {

            field = fieldMap.get(alternateKey);
          }
          else if (parent != null) {
            // Check the parent level.

            field = parent.getField(key);
          }
        }
      }
    }
    return field;
  }

  /**
   * Obtains the first field from the list.
   *
   * @return        the first Field
   */
  public Field getFirstField() {

     if ( (fields != null)
       && (fields.size() > 0) ) {

      return fields.get(0);
     }
    return null;
  }

  /**
   * Returns the last field from the list.
   *
   * @return        the last Field
   */
  public Field getLastField() {

     if (fields != null) {
       int listSize = fields.size();

       if (listSize > 0) {
         return fields.get(listSize - 1);
       }
     }
    return null;
  }

  /**
   * Returns a 'deep' copy of this object, including clones of each field in
   * the list.
   *
   * @return    an object that is a clone of this one
   */
  @Override
  public FieldList clone() {

    FieldList theClone = new FieldList(parent);

    theClone.setDataTypes(datatypes);

    for (Field field : fields) {
      if (field != null) {
        theClone.addField(field.getName(), field.clone());
      }
    }
    for (Field field : theClone) {
      if (field != null) {
        field.updateReferences(theClone);
      }
    }
    return theClone;
  }

  /**
   * Returns an iterator over the Fields in the order they were added.
   *
   * @return an iterator over the Fields in the order they were added
   */
  public ListIterator<Field> iterator() {
    return fields.listIterator();
  }

  /**
   * Returns an iterator over the Field keys in the hash map.
   *
   * @return    an iterator over the Field keys
   */
  public Iterator<String> mapIterator() {

    Set<String> keys = fieldMap.keySet();
    if (keys != null) {
      return keys.iterator();
    }
    return null;
  }
}
