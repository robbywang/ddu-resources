/*
 * Copyright (c) 2006 Nortel, Inc. All Rights Reserved
 */
package com.nortel.cdma.service.csl.sls.filter.common;

//Debug logging
import org.apache.log4j.Logger;


/**
 * Collects all of the attributes of an {@link FieldEmitter} and creates
 * the emitter object. The XML output schema is parsed by Apache Commons
 * Digester. For each emitter it encounters in the output schema, it
 * creates an EmitterAttributes object and populates the attributes from
 * the elements in the schema. The Digester then invokes the
 * {@link EmitterList#createEmitter} method on the parent
 * {@link EmitterList} object. The parent object invokes the
 * EmitterAttributes's {@link EmitterAttributes#create} method, which then
 * creates the FieldEmitter object, and sets the attributes.
 *
 * @todo This class really shouldn't know about attributes like alignment,
 *       padvalue, priority, discriminantValue, etc.. There should be a
 *       mechanism that allows new emitters to define whatever attributes
 *       they need in the XML file without having to add new code here.
 */
public class EmitterAttributes {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(EmitterAttributes.class);

  /**
   * The name of the field with which this emitter is associated. A value
   * of '*' indicates all fields.
   */
  private String       name = null;

  /**
   * The name of the class that implements the emitter.
   */
  private String       className = null;

  /**
   * An attribute used by the {@link AlignedFieldContentEmitter}.
   */
  private int          alignment = 1;

  /**
   * An attribute used by the {@link AlignedFieldContentEmitter}.
   */
  private byte         padValue = 0;

  /**
   * An attribute used by the {@link FieldPriorityFilterEmitter}.
   */
  private int          priority = 0;

  /**
   * An attribute used by the {@link FieldPriorityFilterEmitter}.
   */
  private String       value = null;

  /**
   * An attribute used by the {@link FieldPriorityFilterEmitter}.
   */
  private String       discriminantValue = null;

  /**
   * Constructs an EmitterAttributes object with uninitialized attributes.
   * This parameterless constructor is required by the input schema Digester
   * parsing rules.
   *
   */
  public EmitterAttributes() {
  }

  /**
  * Sets the name attribute. This method is referenced by the output schema
  * Digester parsing rules XML file, therefore any changes made to this
  * method's signature must be reflected in the parsing rules as well.
  * @see #getName
  * @param text     the text to be used as the name
  */
  public void setName(String text) {
    name = text;
  }

  /**
   * Returns the name attribute.
   * @see #setName
   * @return    the name attribute
   */
  public String getName() {
    return name;
  }

  /**
   * Sets the emitter name attribute.
   * This method is referenced by the output schema
   * Digester parsing rules XML file, therefore any changes made to this
   * method's signature must be reflected in the parsing rules as well.
   *
   * @param text    the name of a class that implements {@link FieldEmitter}
   */
   public void setEmitter(String text) {
     className = text;
   }

   /**
    * Sets the priority attribute. This method is referenced by the output
    * schema Digester parsing rules XML file, therefore any changes made to
    * this method's signature must be reflected in the parsing rules as well.
    * @see #getPriority
    *
    * @param pValue   the priority value
    */
   public void setPriority(int pValue) {
     priority = pValue;
   }

   /**
   * Sets the priority attribute. This method is referenced by the output
   * schema Digester parsing rules XML file, therefore any changes made to
   * this method's signature must be reflected in the parsing rules as well.
   * @see #getPriority
   *
   * @param text   a numeric string representing the priority value of the field
   */
  public void setPriority(String text) {

    if (text != null) {
      try {
        priority = Integer.valueOf(text).intValue();
      }
      catch (NumberFormatException e) {
        // Just log it and go on.
        log4jDebugLogger.error("Invalid priority value: '" + text +"'");
      }
    }
  }

  /**
   * Returns the priority attribute.
   * @see #setPriority(String)
   *
   * @return    the priority attribute
   */
  public int getPriority() {
    return priority;
  }


  /**
   * Sets the alignment attribute. This method is referenced by the output
   * schema Digester parsing rules XML file, therefore any changes made to
   * this method's signature must be reflected in the parsing rules as well.
   * @see #getAlignment
   * @param aValue   the alignment value of the field
   */
  public void setAlignment(int aValue) {
    alignment = aValue;
  }

  /**
   * Sets the alignment attribute. This method is referenced by the output
   * schema Digester parsing rules XML file, therefore any changes made to
   * this method's signature must be reflected in the parsing rules as well.
   * @see #getAlignment
   * @param text   a numeric string representing the alignment value of the field
   */
  public void setAlignment(String text) {

    if (text != null) {
      try {
        alignment = Integer.valueOf(text).intValue();
      }
      catch (NumberFormatException e) {
        // Just log it and go on.
        log4jDebugLogger.error("Invalid alignment value: '" + text +"'");
      }
    }
  }

  /**
   * Returns the alignment attribute.
   * @see #setAlignment(String)
   * @return    the alignment attribute
   */
  public int getAlignment() {
    return alignment;
  }

  /**
   * Sets the padValue attribute. This method is referenced by the output
   * schema Digester parsing rules XML file, therefore any changes made to
   * this method's signature must be reflected in the parsing rules as well.
   *
   * @param stringValue   the padValue byte as specified in the schema
   */
  public void setPadvalue(String stringValue) {

    try {
      if (stringValue.startsWith("0x")) {
        padValue = (byte)(Integer.parseInt(stringValue.substring(2), 16) & 0xFF);
      }
      else {
        padValue = (byte)(Integer.parseInt(stringValue) & 0xFF);
      }
    }
    catch (NumberFormatException e) {
      // Just log it and go on.
      log4jDebugLogger.error("Invalid pad value: " + name + ":" + stringValue);
    }
  }

  /**
   * Returns the padValue attribute.
   * @return    the padValue attribute
   */
  public byte getPadValue() {

    return padValue;
  }

  /**
   * Sets the attribute value. This method is referenced by the output
   * schema Digester parsing rules XML file, therefore any changes made to
   * this method's signature must be reflected in the parsing rules as well.
   * @see #getValue
   * @param text   a numeric string representing the alignment value of the field
   */
  public void setValue(String text) {
    value = text;
  }

  /**
   * Returns the attribute value.
   * @see #setValue
   * @return    the attribute value
   */
  public String getValue() {
    return value;
  }

  /**
   * Sets the discriminantValue attribute. This method is referenced by the output
   * schema Digester parsing rules XML file, therefore any changes made to
   * this method's signature must be reflected in the parsing rules as well.
   * @see #getDiscriminantvalue
   * @param text the input discriminantValue attribute value
   */
  public void setDiscriminantvalue(String text) {
    discriminantValue = text;
  }

  /**
   * Returns the discriminantValue attribute.
   * @see #setDiscriminantvalue
   * @return    the discriminantvalue attribute
   */
  public String getDiscriminantvalue() {
    return discriminantValue;
  }

  /**
   * Creates the FieldEmitter object using the attribute settings.
   *
   * @return    the FieldEmitter object
   */
  public FieldEmitter create() {

    FieldEmitter emitter = null;
    Exception    exception = null;

    if (className != null) {
      try {
        Class classDefinition = Class.forName(className);
        Object object = classDefinition.newInstance();

        if (object instanceof FieldEmitter) {
          emitter = (FieldEmitter) object;
          emitter.setAttributes(this);
        }
        else {
          log4jDebugLogger.error("Could not instantiate: "+className+" as a FieldEmitter subclass");
        }
      }
      catch (IllegalAccessException e) {
        exception = e;
      }
      catch (ClassNotFoundException e) {
        exception = e;
      }
      catch (InstantiationException e) {
        exception = e;
      }
    }
    else {
      log4jDebugLogger.error("Missing emitter class name");
    }
    if (exception != null) {
      log4jDebugLogger.error("Could not instantiate "+className, exception);
    }
    return emitter;
  }
}
