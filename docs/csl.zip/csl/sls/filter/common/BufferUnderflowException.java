package com.nortel.cdma.service.csl.sls.filter.common;
/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

/**
 * Exception class for use when a datastream does not contain
 * enough data to form a complete record as defined by the
 * input schema.
 */
public class BufferUnderflowException extends ProcessingException {


  /**
   * Constructor.
   *
   * @param text detailed explanation of error
   */
  public BufferUnderflowException(String text) {
    super(text);
    this.messageDetail = text;
  }
}
