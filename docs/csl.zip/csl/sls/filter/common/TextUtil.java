package com.nortel.cdma.service.csl.sls.filter.common;
/**
 * <p>Copyright (c) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

import org.apache.log4j.Logger;

/**
 * A collection of utility procedures for text output of Streaming Log
 * schemas and data.
 *
 * @since NBSS 15.0
 */
public class TextUtil {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(TextUtil.class);


  /**
   * A string that is used to indicate a hexadecimal number.
   */
  private static final String HEX_PREFIX = "0x";

  /**
   * A string of whitespace that is used to indent hierarchical
   * information.
   * todo: make the space configuration
   */
  private static final String INDENT = "  ";

  /**
   * A character that is used to indicate the end of a text string.
   */
  public static final String STRING_TERMINATOR = "$";

  /**
   *  New line.
   */
  public static final String NEW_LINE = System.getProperty("line.separator");

  /**
    * Constant representing the number of chip bits.
    */
   private static int    CHIP_BITS = 16;

   /**
    * Constant representing the number of milliseconds per tick.
    */
   private static double MILLIS_PER_TICK = 1.25;

   /**
    * Constant time representing the difference betweeen 00:00 January 6, 1980
    * and 00:00 January 1, 1970.
    */
   private static long   CDMA_TIME_OFFSET = 315964800000L;

   /**
    * Formatting string to configure date formatter.
    */
   private static String mszDateFormatterString = "yyyy-MM-dd HH:mm:ss.SSS";

   /**
    * Date formatter object.
    */
   private static SimpleDateFormat mDateFormatter = new SimpleDateFormat(mszDateFormatterString);

  /**
   * Returns the hexadecimal representation of the specified value,
   * padded to the specified number of hex digits.
   *
   * @param value the value to be converted to hex
   * @param length the number of hex digits in the returned string
   * @return a string containing the hexadecimal number
   */
  public static String toHexString(int value, int length) {

    StringBuffer sb = new StringBuffer();
    String sValue   = (Integer.toHexString(value)).toUpperCase();

    int padLength = Math.max(0, length - sValue.length());

    for (int i = 0; i < padLength; i++) {

      sb.append("0");
    }
    sb.append(sValue);

    return sb.toString();
  }

  /**
   * Returns the hexadecimal representation of the specified byte
   * array.
   *
   * @param bytes the value to be converted to hex
   * @return a string containing the hexadecimal number
   */
  public static String toHexString(byte[] bytes) {


    String result = toIntString(bytes, 16, false);
    int iLeadingZeros =  (bytes.length * 2) - result.length();
    for (int i=iLeadingZeros; i > 0; i--) {
      //pad with 0
      result = "0" + result;
    }

    return result.toUpperCase();
  }

   /**
   * Returns the binary code decimal (BCD) representation of the specified byte
   * array.
   *
   * @param bytes the value to be converted to BCD string
   * @param iByteArraySize the byte array size
   * @return a string containing the BCD number
   */
   private static String toBCDString(byte[] bytes, int iByteArraySize) {

     String szResult = toHexString(bytes);
     int iDifference = iByteArraySize *2 - szResult.length();

     if (iDifference >0) {
       //need to pad 0 from left
       String szPad = "";
       for (int i= 0; i< iDifference; i++) {
         szPad += "0";
       }
       szResult = szPad + szResult;
     }
     return szResult;
   }

  /**
   * Returns the boolean representation of the specified byte
   * array. It is either true or false.
   *
   * @param bytes the value to be converted to boolean string
   * @return a boolean string, either true or false
   */
  private static String toBooleanString(byte[] bytes) {

    String szResult = "";

    if (bytes.length != 1) {
      log4jDebugLogger.error("got incorrect byte array to convert to boolean string");
      return szResult;
    }

    int iValue = bytes[0];

    if (iValue == 0) {
      szResult = Boolean.FALSE.toString();
    }
    else {
      szResult = Boolean.TRUE.toString();
    }
    return szResult;
  }

  /**
   *  Returns the String representation of the byte array in the
   * given radix.
   * @param bytes bytes the value to be converted
   * @param radix the radix of the String representation
   * @param signed when true value is signed rather than unsigned
   * @return Returns the String representation of the byte array
   */
  private static String toIntString(byte[] bytes, int radix, boolean signed) {

    String result = null;
    if (bytes != null) {
      try {
        BigInteger oBi = new BigInteger(bytes);

        if (!signed && (oBi.signum() < 0)) {
          //For the byte array, if the leftmost bit is 1, then it is treated as negative.
          // In this case, pad 0 from left to make the value positive
          byte [] abNew = new byte [bytes.length + 1];
          abNew[0] = 0;
          System.arraycopy(bytes, 0, abNew, 1, bytes.length);
          oBi = new BigInteger(abNew);
        }
        result = oBi.toString(radix);
      }
      catch (NumberFormatException e) {
        log4jDebugLogger.error("Unable to convert byte array to decimal string", e);
      }
    }
    return result;
  }

  /**
   * Returns the hexadecimal representation of the specified byte.
   *
   * @param b the byte to be converted to hex
   * @return a string containing the hexadecimal number
   */
  public static String toHex(byte b) {

    String sByte = Integer.toHexString(b);
    int length   = sByte.length();

    if (length < 2) {
      // Pad so we have two chars per byte.
      sByte = "0" + sByte;
    }
    else if (length > 2) {
      // Just use the last two characters.
      sByte = sByte.substring(length - 2, length);
    }
    sByte = sByte.toUpperCase();

    return sByte;
  }

  /**
   * Returns a string containing a formatted hex dump of the
   * specified byte array. The dump is formatted with the byte
   * offset on the left, and 16 bytes separated by spaces on
   * each line, e.g.
   * 0000 : 0D 82 32 55 AD 66 21 00 FE 1C 00 01 80 B3 1F 7A
   *
   * @param bytes the byte array to be dumped
   * @return a string containing the formatted hex dump
   */
  public static String toHexDump(byte[] bytes) {

    StringBuffer sb = new StringBuffer();
    int length = bytes.length;

    for (int i = 0; i < length; i++) {

      if (i % 16 == 0) {
        // Start new line
        sb.append(NEW_LINE + toHexString(i, 4) + " : ");
      }

      sb.append(toHex(bytes[i]) + " ");
    }
    return sb.toString();
  }

  /**
   * Returns a string containing the hexadecimal representation of the
   * value at the specified offset in the specified data buffer.
   *
   * @param buffer the data buffer from which to retrieve the value
   * @param offset the offset of the data in the buffer
   * @param size the size of the value (in bytes)
   * @return the hexadecimal representation of the specified value
   */
  public static String getValueAsHexString(ExtendableBuffer buffer,
                                           int offset,
                                           int size) {

    StringBuffer sb = new StringBuffer();

    if (offset < 0) {
      sb.append(STRING_TERMINATOR);
    }
    else {
      if (buffer != null) {

        byte[] bytes = new byte[size];

        try {
          System.arraycopy(buffer.toByteArray(), offset, bytes, 0, size);

          sb.append(" = " + HEX_PREFIX + toHexString(bytes));
        }
        catch (ArrayIndexOutOfBoundsException e) {
          sb.append(NEW_LINE + STRING_TERMINATOR);
        }
      }
    }
    return sb.toString();
  }

  /**
   * Returns a string of white space of the necessary length to
   * indent text to the specified hierarchy level.
   *
   * @param level the level of the hierarchy to be indented
   * @return a string of space characters
   */
  public static StringBuffer getIndent(int level) {

    StringBuffer sb = new StringBuffer();

    for (int i = 0; i < level; i++) {
      sb.append(INDENT);
    }
    return sb;
  }

  /**
   * Returns a string containing the specified label enclosed in
   * angle brackets for use as an XML tag. The string is indented
   * to the level specified.
   *
   * @param level the level of the hierarchy
   * @param label the text to be inserted in the tag
   * @return a string containing the indented tag
   */
  public static String getDefinitionOpenString(int level, String label) {

    String s = getIndent(level) + "<" + label + ">";

    return s;
  }

  /**
   * Returns a string containing the specified label enclosed in
   * angle brackets for use as an XML close tag. The string is indented
   * to the level specified.
   *
   * @param level the level of the hierarchy
   * @param label the text to be inserted in the tag
   * @return a string containing the indented tag
   */
  public static String getDefinitionCloseString(int level, String label) {

    return (getIndent(level) + getDefinitionCloseString(label));
  }

  /**
   * Returns a string containing the specified label enclosed in angle
   * brackets for use as an XML close tag. The string is not indented.
   *
   * @param label the text to be inserted in the tag
   * @return a string containing the indented tag
   */
  public static String getDefinitionCloseString(String label) {

    String s = "</" + label + ">" + NEW_LINE;

    return s;
  }

  /**
   * Returns a string containing an entire XML element, enclosed in
   * opening and closing tags.
   *
   * @param level the level of the hierarchy, for indenting
   * @param label the contents of the tag
   * @param element the contents of the element
   * @return a string containing the element formatted as XML
   */
  public static String getDefinitionString(int level, String label,
                                           String element) {

    String s = getDefinitionOpenString(level, label) + element
      + getDefinitionCloseString(label);

    return s;
  }

  /**
   * Returns a string where digital value is in decimal format.
   * @param bytes the byte array to be converted
   * @param signed when true value is signed rather than unsigned
   * @return a string value
   */
  private static String toDecString(byte[] bytes, boolean signed) {
    return toIntString(bytes, 10, signed);
  }

  /**
   * Returns a string where digital value is in binary format.
   * @param bytes the byte array to be converted
   * @return a string value
   */
  private static String toBinString(byte[] bytes) {
    return toIntString(bytes, 2, false);
  }
  /**
   * Returns a string that presents time stamp.
   * @param bytes the byte array to be converted
   * @return a string value
   */
  private static String toTimeString(byte[] bytes) {

    String timestamp = "";
    long lTimeValue;

    try {
      BigInteger value = new BigInteger(bytes);
      lTimeValue = value.longValue();
    }
    catch (NumberFormatException e) {
      log4jDebugLogger.error("Unable to convert byte array to time string", e);
      return timestamp;
    }

    // The time in binary log data represents CDMATime. Convert it to local time.
    long lUnixTime = convertCDMAToUnixTime(lTimeValue);

    Date oDate = new Date (lUnixTime);
    timestamp = mDateFormatter.format(oDate);

    return timestamp;
  }

   /**
   * Converts time from CDMA format to Unix format (seconds since
   * January 1st, 1970).
   *
   * @param cdmaTime  The time in CDMA format
   *
   * @return          The time in Unix format
   *
   * #see convertUnixToCDMATime
   */
  public static long convertCDMAToUnixTime(long cdmaTime) {
    cdmaTime >>= CHIP_BITS;
    cdmaTime *= MILLIS_PER_TICK;

    long  unixTime = cdmaTime + CDMA_TIME_OFFSET;

    return unixTime;
  }

  /**
   * Sets the time zone to be used when formatting timestamps.
   * @param timeZone the time zone to be used when formatting timestamps
   */
  public static void setTimeZone(TimeZone timeZone) {

    mDateFormatter.setTimeZone(timeZone);
    if (!("GMT".equals(timeZone.getID()))) {
      // Add time zone label to timestamps if not GMT
      mDateFormatter.applyPattern(mszDateFormatterString + " z");
    }
  }

  /**
   * Returns a textual representation of IP addresses.
   * @param bytes the byte array to be converted
   * @return a string value
   */
  private static String toIPAddressString (byte[] bytes) {

    String result = "";

    if (bytes.length != 4) {
      return result;
    }

    int iOne = bytes[0] & 0xFF;
    int iTwo = bytes[1] & 0xFF;
    int iThree = bytes[2] & 0xFF;
    int iFour = bytes[3] & 0xFF;
    result = iOne + "." + iTwo + "." + iThree + "." + iFour;
    return result;
  }

  /**
   * Returns the field value as a String object, where the output format is configurable.
   * @param buffer the data buffer from which to retrieve the value
   * @param offset the offset of the data in the buffer
   * @param size the size of byte array
   * @param format the data output format
   * @return the String object of the field value
   */
  public static String getValueAsString(InputBuffer buffer,
                                        int offset,
                                        int size,
                                        String format) {
    return getValueAsString(buffer, offset, size, format, false);
  }

  /**
   * Returns the field value as a String object, where the output format is configurable.
   * @param buffer the data buffer from which to retrieve the value
   * @param offset the offset of the data in the buffer
   * @param size the size of byte array
   * @param format the data output format
   * @param signed when true value is signed rather than unsigned
   * @return the String object of the field value
   */
  public static String getValueAsString(InputBuffer buffer,
                                        int offset,
                                        int size,
                                        String format,
                                        boolean signed) {

    StringBuffer sb = new StringBuffer();
    if (offset < 0) {
      sb.append(STRING_TERMINATOR);
    }
    else {
      if (buffer != null) {

        byte[] bytes = new byte[size];

        try {
          System.arraycopy(buffer.toByteArray(), offset, bytes, 0, size);
          OutputFormatEnum mFormat = OutputFormatEnum.HEX;
          if (format == null) {
            log4jDebugLogger.info("output format is not specified. Use default one  (" + mFormat.toString()
              + ") instead.");
          }
          else {
            try {
              mFormat = OutputFormatEnum.valueOf(format.toUpperCase());
            }
            catch (IllegalArgumentException  e) {
              log4jDebugLogger.error("Unsupported format (" + format + "). Use default format " +
                mFormat);
            }
          }
          //convert byte array to string based in the specified format
          switch (mFormat) {
            case HEX:
              sb.append(HEX_PREFIX + toHexString(bytes));
              break;
            case DEC:
              sb.append(toDecString(bytes, signed));
              break;
            case TIMESTAMP:
              sb.append(toTimeString(bytes));
              break;
            case BINARY:
              sb.append(toBinString(bytes));
              break;
            case IPADDRESS:
              sb.append(toIPAddressString(bytes));
              break;
            case FDN:
              //todo: will print card ME ID and FDN based
              sb.append(HEX_PREFIX +  toHexString(bytes));
              break;
            case STRING:
              sb.append(new String(bytes));
              break;
            case BOOL:
              sb.append(toBooleanString(bytes));
              break;
            case BCD:
              sb.append(toBCDString(bytes, size));
              break;
            case HIDDEN:
              //do nothing
              break;
            default:
              sb.append(HEX_PREFIX +  toHexString(bytes));
              break;
          }
        } catch (ArrayIndexOutOfBoundsException e) {
          sb.append(NEW_LINE + STRING_TERMINATOR);
        }
      }
    }
    return sb.toString();
  }

  /**
   * Declare enum representation for output format.
   */

  public enum OutputFormatEnum {
    /**
     * hex representation.
     */
    HEX,

    /**
     * decimal representation.
     */

    DEC,

    /**
     * binary representation.
     */
    BINARY,

    /**
     *  Textual representation of IP addresses.
     */
    IPADDRESS,

    /**
     * FDN representation.
     */
    FDN,

    /**
     * Timestamp representation.
     */
    TIMESTAMP,

    /**
     * String representation.
     */
     STRING,

    /**
     * Boolean representation.
     */
    BOOL,

    /**
     * BCD representation.
     */
    BCD,


    /**
     * Hidden: field info will not be present in the output.
     */
    HIDDEN
  };
}
