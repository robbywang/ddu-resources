/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.filter;

import com.nortel.cdma.service.csl.sls.common.PlugIn;

/**
 * Base class for all Filters.
 */
public abstract class Filter extends PlugIn {
  /**
   * Default constructor for the Filter object.
   */
  public Filter() {
    super();
    mszPluginType = "Filter";
  }

  /**
   * The IStreamReceiver interface implementation that handles the stream.
   * @param abInputBuffer the byte array to be handled
   * @param iOffset the offset in the byte array of the data to be handled
   * @param iLength the length of the byte array to be handled
   */
  public abstract void handleStream(byte[] abInputBuffer, int iOffset, int iLength);

  /**
   * Set CSL log data type which is either XDRLite  or XDR.
   * @param szDataType the string value of the CSL log data type
   */
  public abstract void setCSLDataType(String szDataType);
}
