package com.nortel.cdma.service.csl.sls.filter.ascii;
/**
 * <p>Copyright (C) 2006 Nortel Networks. All Rights Reserved.</p>
 * <p>
 * NORTEL NETWORKS CONFIDENTIAL. All information, copyrights, trade secrets<br>
 * and other intellectual property rights, contained herein are the property<br>
 * of Nortel Networks. This document is strictly confidential and must not be<br>
 * copied, accessed, disclosed or used in any manner, in whole or in part,<br>
 * without Nortel's express written authorization.
 * </p>
 */
import org.apache.commons.digester.Digester;
import org.xml.sax.InputSource;
import com.nortel.cdma.service.csl.sls.filter.common.DigesterConfiguration;

/**
 * A configuration for the Apache Commons Digester appropriate for
 * parsing the XDRLiteConverter input schema file.
 */
public class AsciiOutputSchemaDigesterConfig extends DigesterConfiguration {

  /**
   * Constructor.
   */
  public AsciiOutputSchemaDigesterConfig() {

    super();
  }

  /**
   * Constructor that allows a parsing rules XML file to
   * be specified for configuring the digester.
   * @param parsingRules an XML file containing digester
   *        parsing rules
   */
  public AsciiOutputSchemaDigesterConfig(InputSource parsingRules) {

    super(parsingRules);
  }

  /**
   * Creates and configures a Digester with parsing rules appropriate
   * for parsing the XDRLiteConverter datatypes file. The XML version
   * of these rules is as follows: (replace '?' with '*')
   *
   * @return a configured Digester
   */
  protected Digester configureDigester() {

    Digester newDigester = super.configureDigester();

    if (newDigester != null) {
      if (parsingRulesFile == null) {
        // Configure default parsing rules.
        newDigester.addObjectCreate("*/field",
        "com.nortel.cdma.service.csl.sls.filter.common.EmitterAttributes");
        newDigester.addSetNext("*/field", "createEmitter");
        newDigester.addSetProperties("*/field"); 
        newDigester.addBeanPropertySetter("*/field/emitter");
      }
    }

    return newDigester;
  }
}
