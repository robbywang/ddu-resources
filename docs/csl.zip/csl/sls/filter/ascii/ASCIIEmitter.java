/*
* Copyright (c) 2006 Nortel, Inc. All Rights Reserved
*/
package com.nortel.cdma.service.csl.sls.filter.ascii;
import com.nortel.cdma.service.csl.sls.filter.common.Field;
import com.nortel.cdma.service.csl.sls.filter.common.FieldEmitter;
import com.nortel.cdma.service.csl.sls.filter.common.InputBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.ProcessingException;
import com.nortel.cdma.service.csl.sls.filter.common.BufferUnderflowException;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;
import org.apache.log4j.Logger;

/**
 * An implementation of a FieldEmitter that outputs an XML file
 * containing an XDR version of the input schema.
 */
public class ASCIIEmitter extends FieldEmitter {

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(ASCIIEmitter.class);
  /**
   * Outputs field String value for ASCII parsing.
   *
   * @param field   the field to be emitted
   * @param input   the input data buffer
   * @return        a boolean value indicating if the action is ok
   * @throws        ProcessingException if unable to parse the input
   *                data stream
   */
  public boolean emit(Field field, InputBuffer input)
    throws ProcessingException {
    StringBuffer sb = new StringBuffer();
    if ((field != null) && (buffer != null)) {
      sb.append(TextUtil.NEW_LINE);
      StringBuffer output = field.getASCIIOutput(sb, input, 0);
      String szOutput = output.toString();
      byte[] bytes = szOutput.getBytes();
      if (bytes != null) {
        buffer.append(bytes, 0, bytes.length);
      }
    }
    return true;
  }
}
