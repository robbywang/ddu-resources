/**
 * Copyright (c) 2006 Nortel Networks, Inc. All Rights Reserved.
 */

package com.nortel.cdma.service.csl.sls.filter.ascii;

import com.nortel.cdma.service.csl.sls.filter.common.DigesterConfiguration;
import com.nortel.cdma.service.csl.sls.filter.common.DatatypesDigesterConfiguration;
import com.nortel.cdma.service.csl.sls.filter.common.InputSchemaDigesterConfiguration;
import com.nortel.cdma.service.csl.sls.filter.common.ParsingFilter;
import com.nortel.cdma.service.csl.sls.filter.common.ExtendableBuffer;
import com.nortel.cdma.service.csl.sls.filter.common.TextUtil;
import com.nortel.cdma.service.common.server.interfaces.IStreamReceiver;
import com.nortel.cdma.gsf.InitializationFailureException;
import com.nortel.cdma.gsf.InvalidDeploymentException;
import org.xml.sax.InputSource;
import org.apache.log4j.Logger;
import org.apache.log4j.Level;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.PatternLayout;

import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.TimeZone;
import java.util.Properties;
import java.util.ListIterator;
import java.util.zip.GZIPInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;

/**
 * To change this template use File | Settings | File Templates.
 */
public class ASCIIFilter extends ParsingFilter {

  /**
   * Version of the ASCII Parser, displayed in the parser output.
   * Increment whenever substantial changes are made.
   */
  private static final String mszVersion = "17.0";

  /**
   * A byte array to hold a log record.
   */
  private static byte [] mabRecord;

  /**
   *  Instance of debug logger.
   */
  private static final Logger log4jDebugLogger = Logger.getLogger(ASCIIFilter.class);

  /**
   *  Boolean flag indicates if the ASCII parser is running as stand-alone mode.
   */
  private static boolean bFromStandalone = false;

  /**
   *   The default name of the xdrlite configuration file.
   */
  protected  final String DEFAULT_CONFIG_FILE =
    mszDefaultfilePath + "asciifilter.xml";

  /**
   * The InputStream buffer size.
   */
  private static final int BUFFER_SIZE = 65536; //64 k

  /**
   * The name of the binary file to be parsed.
   */
  private String mszFileName;

  /**
   * Number of log records which have been parsed successfully.
   */
  private int miParsedRecords = 0;

  /**
   * Current offset in the data file.
   */
  private int miDataOffset;

  /**
   * Number of errors encountered.
   */
  private int miErrorCount = 0;
  
  /**
   * Number of skip encountered.
   */
  private int miSkipCount = 0;

  /**
   * Output file name.
   */
  private String mszOutFileName;


  /**
   * This array list has the parsed records, one record in a byte aray.
   */

  /*
   * Number of errors encountered.
   */
  private final int ERROR_VALUE = -1;

  /**
   * Constant for the inputfilename
   */
  private final String INPUTFILE = "inputfile";

  /**
   * Constant for the config file specified
   */
  private final String CFGFILE = "cfgfile";

  /**
   * Constant for the output file specified
   */
  private final String OUTPUTFILE = "outputfile";

  /**
   * Constant for the format of the input file.
   */
  private final String FORMAT = "format";

  /**
   * Constant for the verbose option
   */
  private final String VERBOSE = "verbose";
  
  /**
   * value of verbose option
   */
  private boolean mVerbose = false;


  /**
   * constructor.
   */
  public ASCIIFilter() {
    super();
    mszDefault_Config = DEFAULT_CONFIG_FILE;

    mabRecord = new byte[BUFFER_SIZE];
  }

  /**
   *  Gets the digester configuration based on the input source of data types.
   * @param input the InputSource object which contains the datatypes definition
   * @return DigesterConfiguration
   */
  protected DigesterConfiguration getDataTypeDigesterConfig(InputSource input) {
    return new DatatypesDigesterConfiguration (input);
  }

  /**
   *  Gets the digester configuration based on the input source of input schema.
   * @param input the InputSource object which contains the input schema definition
   * @return DigesterConfiguration
   */
  protected  DigesterConfiguration getInputDigesterConfig(InputSource input) {
    return new InputSchemaDigesterConfiguration(input);
  }

  /**
   *  Gets the digester configuration based on the input source of output schema.
   * @param input the InputSource object which contains the output schema definition
   * @return DigesterConfiguration
   */
  protected DigesterConfiguration getOutputDigesterConfig(InputSource input) {
    return new AsciiOutputSchemaDigesterConfig (input);
  }

  /**
   * Processes the parsing results. If the data stream comes from the command-line (e.g.
   * stand-alone parser), outputs the ASCII contents to the console. Otherwise, call next
   * level of handleStream
   * @param  mOutput mOutput the ExtendableBuffer which contains the output info
   */
  protected void processResults (ExtendableBuffer mOutput) {

    if (mOutput != null) {
      byte []  outBytes = mOutput.toByteArray();
      int iLength   = mOutput.getLength();
      if ((outBytes != null) && (iLength > 0)) {

        ++ miParsedRecords;

        if (bFromStandalone) {
          printResult(outBytes);
        }

        else {
          if (moHashSetStreamReceivers.size() ==0) {
            log4jDebugLogger.error("No IStreamReceiver is registered. Stop sending data");
            return;
          }

          for (IStreamReceiver oStreamReceiver : moHashSetStreamReceivers) {
            oStreamReceiver.handleStream(outBytes, 0, iLength);
          }
          log4jDebugLogger.debug("Sent "+ iLength+" bytes");

        }
      }
    }
  }

  /**
   * Set CSL log data type which is either XDRLite  or XDR.
   * @param szDataType the string value of the CSL log data type
   */
  public void setCSLDataType(String szDataType) {
    if (szDataType != null) {
      mszCSL_Datatype = szDataType;
    }
  }

  /**
   * Prints the ASCII contents of the parsing result.
   * @param baResults the byte array which contains the parsing results
   */
  private void printResult (byte [] baResults) {

    ArrayList<byte[]> alabContents = new ArrayList<byte[]>();
    StringBuffer sbHeader = getRecordHeader();
    String szHeader = sbHeader.toString();
    byte[] baHeader = szHeader.getBytes();

    alabContents.add(baHeader);
    alabContents.add(baResults);

    appendToFile(mszOutFileName,alabContents);

  }

  private StringBuffer getRecordHeader () {

    StringBuffer sbHeader = new StringBuffer();

    sbHeader.append(TextUtil.NEW_LINE);
    sbHeader.append(TextUtil.NEW_LINE);
    sbHeader.append("=================================================================");
    sbHeader.append(TextUtil.NEW_LINE);
    sbHeader.append(" File: ").append(mszFileName);
    sbHeader.append(TextUtil.NEW_LINE);
    sbHeader.append(" Offset: ").append(miDataOffset).append("  Record: ").append(miParsedRecords);
    sbHeader.append(TextUtil.NEW_LINE);
    sbHeader.append("=================================================================");

    return sbHeader;
  }

  /**
   * Method to run the ASCIIFilter stand alone.
   * @param oProperties containing command line parameters
   */
  private void runStandAlone(Properties oProperties) {

    bFromStandalone = true;
    boolean bVerbose = oProperties.containsKey(VERBOSE);

    // initialize debug logging.
    //initializeLogger(bVerbose);

    String szConfigFilename = oProperties.getProperty(CFGFILE);
    if (szConfigFilename == null){
      szConfigFilename = "local";
    }

    // call the config method of Filter
    callBaseConfig(szConfigFilename);

    // Process the config file
    int iReturn = parseConfigFile(szConfigFilename);

    if (iReturn == ERROR_VALUE) {
      log4jDebugLogger.error("Couldnt process config file: " + szConfigFilename);
      return;
    }

    // Load the schema file and return the time taken to process it.
    long lSchemaTimeTakenMillis = loadSchemaFile(bVerbose);

    if (lSchemaTimeTakenMillis == ERROR_VALUE) {
      return;
    }

    String szOutFileName = oProperties.getProperty(OUTPUTFILE);
    mszOutFileName = szOutFileName;

    // Put the common header on to the output file.
    appendCommonHeaderToFile(szOutFileName);

    String szInFileName = oProperties.getProperty(INPUTFILE);
    mszFileName = szInFileName;

    //Parse the binary input file and get the time taken for the parsing.
    long lParsingTimeTakenMillis = parseBinaryFile(szInFileName, bVerbose);

    if (lParsingTimeTakenMillis == ERROR_VALUE) {
      log4jDebugLogger.error("Couldnt process input file: " + szInFileName);
      return;
    }

    // Display summary of records parsed and time taken.
    displaySummary(lSchemaTimeTakenMillis, lParsingTimeTakenMillis, bVerbose);

    System.out.println("Output saved in file: " + szOutFileName);
  }

  /**
   * Method to display a summary of number of records parsed and time taken.
   * @param lSchemaTimeTakenMillis time taken to load the schema file
   * @param lParsingTimeTakenMillis time taken to parse the binary input file
   * @param bVerbose indicates if verbose is specified
   */
  private void displaySummary(long lSchemaTimeTakenMillis, long lParsingTimeTakenMillis, boolean bVerbose) {

    long iParsingTime =  lParsingTimeTakenMillis / 1000;
    String szParsingTimeUnit = "s";

    // If parsing time is less than a second, show it in milli seconds.
    if (iParsingTime == 0) {
      iParsingTime = lParsingTimeTakenMillis;
      szParsingTimeUnit = "ms";
    }

    long lSchemaTimeTaken = lSchemaTimeTakenMillis / 1000;

    log4jDebugLogger.warn("\n=================================================================\n" + 
                          " Loading schema files took " + lSchemaTimeTaken + " second(s)\n" + 
                          " Parse files took " + iParsingTime + szParsingTimeUnit + "\n" +
                          "    Parsed log size(bytes): " + miDataOffset + "\n" + 
                          "    Total parsed record(s): " + miParsedRecords + "\n" + 
                          "   Total skipped record(s): " + miSkipCount + "\n" + 
                          "     Total error record(s): " + miErrorCount + "\n" + 
                          "=================================================================\n\n");
  }

  /**
   * Method to parse binary input file.
   * @param szInFileName teh input file to be parsed
   * @param bVerbose indicates if verbose is specified
   * @return time taken to parse the file
   */
  private long parseBinaryFile(String szInFileName, boolean bVerbose) {

    long lParsing_start = System.currentTimeMillis();

    InputStream oInputStream = null;


    if (szInFileName.equalsIgnoreCase("stdin")){
      oInputStream = new DataInputStream(System.in);
    }
    else{
      try {
        oInputStream = openFile( mszFileName );
      }
      catch (IOException e) {
        log4jDebugLogger.error("Unable to open the file :" + mszFileName + e);
        return ERROR_VALUE;
      }
    }

    boolean bDone = false;
    int iLength = 0;

    ByteBuffer oByteBuffer = null;
    System.out.println("Starting to parse data...");

    // Iterate over all records and parse them.
    try {
      while ( ! bDone ) {
        oByteBuffer = getRecord(oInputStream);

        if (oByteBuffer == null) {
          continue;
        }

        byte [] bytes = oByteBuffer.array();
        iLength = oByteBuffer.limit();

        handleStream(bytes, 0, iLength);

        miDataOffset += iLength;
      }
    }
    catch (EOFException e) {
      log4jDebugLogger.debug("EOF reached for file: " + mszFileName);  
      bDone = true;
    }
    catch (IOException e) {
      long lParsing_end = System.currentTimeMillis();
      long lParsing_time_millisec = lParsing_end - lParsing_start;
      log4jDebugLogger.error("Unable to get record from DataInputStream: " + e.getMessage());

      return lParsing_time_millisec;
    }

    finally {
      if ( oInputStream != null ) {
        try {
          oInputStream.close();
        }
        catch (IOException e) {
          log4jDebugLogger.error("Unable to close DataInputStream for file: " + mszFileName + e);
         return ERROR_VALUE;
        }
      }
    }

    long lParsing_end = System.currentTimeMillis();
    long lParsing_time_millisec = lParsing_end - lParsing_start;

    return lParsing_time_millisec;
  }

  /**
   * Method to call the base config method of Filter class.
   * @param szConfigFilename
   */
  private void callBaseConfig(String szConfigFilename){
    Properties oProperties = new Properties();
    oProperties.put("name", "Stand-alone ASCII Filter");
    oProperties.put("configfile", szConfigFilename);
    config(oProperties);
  }

  /**
   * Initialized debug logs when run in stand-alone mode.
   * @param bVerbose indicates if the verbose option is specified
   * @deprecated
   */
  private void initializeLogger(boolean bVerbose) {

    Logger log4jDebugLogger = Logger.getRootLogger();
    PatternLayout layout = new PatternLayout("%-5p: %-21c{1} - %m%n");
    log4jDebugLogger.addAppender(new ConsoleAppender(layout));

    log4jDebugLogger.setLevel(Level.OFF);

    log4jDebugLogger = Logger.getLogger("com.nortel.cdma.service.csl");

    if (bVerbose) {
      log4jDebugLogger.setLevel(Level.DEBUG);
    }

  }

  /**
   * Method to fetch the common header for the output file.
   * @return the common header.
   */
  private StringBuffer getCommonHeader() {

    StringBuffer sbCommonHeader = new StringBuffer();
    Date timeStamp = new Date(System.currentTimeMillis());

    // Put common header into a StringBuffer.
    sbCommonHeader.append(TextUtil.NEW_LINE);
    sbCommonHeader.append("=================================================================");
    sbCommonHeader.append(TextUtil.NEW_LINE);
    sbCommonHeader.append("CSL ASCII Parser version ").append(mszVersion).append("       ").append(timeStamp);
    sbCommonHeader.append(TextUtil.NEW_LINE);
    sbCommonHeader.append("=================================================================");

    return sbCommonHeader;
  }

  /**
   * Method to append the common header in the output file.
   * @param szOutFileName the file to which the common header is to be appended
   */
  private void appendCommonHeaderToFile(String szOutFileName) {

    StringBuffer sbCommonHeader = getCommonHeader();
    String szCommonHeader = sbCommonHeader.toString();
    byte[] baCommonHeader = szCommonHeader.getBytes();

    ArrayList<byte[]> alabContents = new ArrayList<byte[]>();
    alabContents.add(baCommonHeader);

    int iPutStringReturn = appendToFile (szOutFileName, alabContents);

    // Error - Prompt user.
    if ( iPutStringReturn == ERROR_VALUE ) {
      log4jDebugLogger.error("Could not put common header on to the output file: " + szOutFileName);
    }
  }

  /**
   * Utility method to put bytes in a file.
   * @param szOutFileName the file name
   * @param abContents a list of byte arrays which is to be appended to the file
   * @return interger indicating the number of bytes written
   */
  private int appendToFile(String szOutFileName, ArrayList<byte[]> alabContents) {

    BufferedOutputStream oBufferedOutputStream = null;
    int iBytesWritten = 0;

    // Open the output file and append the contents.
    try {

      File oOutFile = new File(szOutFileName);
      FileOutputStream oFileOutputStream  = new FileOutputStream( oOutFile, true );
      oBufferedOutputStream = new BufferedOutputStream( oFileOutputStream, BUFFER_SIZE );
      ListIterator<byte[]> iterator = alabContents.listIterator();

      //StringBuffer sb = new StringBuffer();
      while( iterator.hasNext()) {
        byte[] abContents = iterator.next();
        int iBytesToBeWritten = abContents.length;
        oBufferedOutputStream.write(abContents,0,iBytesToBeWritten);
        //sb.append(new String( abContents));
        iBytesWritten += iBytesToBeWritten;
      }

      System.out.print(".");

    }
    catch (IOException e) {
        log4jDebugLogger.error("I/O exception encountered for file: " + szOutFileName);  

      return ERROR_VALUE;
    }
    finally {
      if ( oBufferedOutputStream != null ) {
        try {
          oBufferedOutputStream.close();
        }
        catch (IOException e) {
          log4jDebugLogger.error("I/O exception encountered whie closing file: " + szOutFileName, e);
          return ERROR_VALUE;
        }
        catch (Exception e) {
          log4jDebugLogger.error("Unknown exception encountered whie closing file: " + szOutFileName, e);
          return ERROR_VALUE;
        }
      }
    }

    return iBytesWritten;

  }

  /**
   * Method to parse the configuration file specified by the user.
   * @param szConfigFilename the name of the config filename
   * @return 0 if the parsing is successful
   *         -1 if the parsing failed
   */
  private int parseConfigFile(String szConfigFilename) {

    int iReturn = 0;
    InputStream  configuration = null;

    try {
      if (szConfigFilename.equalsIgnoreCase("local")){
        // do nothing
      }else{
        configuration = new BufferedInputStream(new FileInputStream(szConfigFilename));
      }
      if (configuration != null) {
        Properties p  = new Properties();
        p.loadFromXML(configuration);
        configuration.close();

        String   szTimeZone = p.getProperty("timezone");
        TimeZone oTimeZone = TimeZone.getTimeZone("GMT"); //default

        if (szTimeZone != null) {
          szTimeZone = szTimeZone.trim();
          if (szTimeZone.equals("local")) {
            oTimeZone = TimeZone.getDefault();
          }
          else {
            oTimeZone = TimeZone.getTimeZone(szTimeZone);
          }
        }
        TextUtil.setTimeZone(oTimeZone);
      }
    }
    catch (FileNotFoundException e) {
      log4jDebugLogger.error("Configuration file not found: " + szConfigFilename, e);
      return ERROR_VALUE;
    }
    catch (IOException e) {
      log4jDebugLogger.error("Failed to read: " + szConfigFilename, e);
      return ERROR_VALUE;
    }

    return iReturn;
  }

  /**
   * Method to load the schema file.
   * @param bVerbose indicates if verbose is specified by the user
   * @return time taken to load the schema file
   */
  private long loadSchemaFile(boolean bVerbose) {

    System.out.println("Loading schema files ...");

    long lLoad_schema_start = System.currentTimeMillis();

    try {
      startup();
    }
    catch (InitializationFailureException e) {
      log4jDebugLogger.error("Unable to run ASCII Parser :" + e.getMessage());
      return ERROR_VALUE;
    }
    catch (InvalidDeploymentException e) {
      log4jDebugLogger.error("Unable to run ASCII Parser :" + e.getMessage());
      return ERROR_VALUE;
    }

    long lLoad_schema_end = System.currentTimeMillis();
    long lSchema_loading_time_millis = (lLoad_schema_end - lLoad_schema_start); //in milli seconds

    System.out.println("Load schema files ... done!");

    return lSchema_loading_time_millis;
  }

  /**
   * Creates a DataInputStream by opening a connection to a specified file.
   * The file can be a regular file or compressed one.
   * @param szFilename the file to open
   * @return the DataInputStream object
   * @throws IOException if the file does not exist or cannot be read
   */
  private DataInputStream openFile( String szFilename ) throws IOException {

    System.out.println("szFilename = " + szFilename);

    DataInputStream oDataInputStream = null;

    try {
      FileInputStream in = new FileInputStream(szFilename);
      BufferedInputStream source = new BufferedInputStream(in);

      GZIPInputStream oGZIPInputStream = new GZIPInputStream(source);
      oDataInputStream = new DataInputStream( oGZIPInputStream );
    }
    catch (IOException e) {
      FileInputStream in = new FileInputStream(szFilename);
      BufferedInputStream source = new BufferedInputStream(in);

      oDataInputStream = new DataInputStream( source );
    }

    miDataOffset = 0;
    return ( oDataInputStream );
  }

  /**
   * Get the current record.
   * @param oDataInputStream
   * @return the record.
   * @throws IOException
   */
  private ByteBuffer getRecord( InputStream oDataInputStream ) throws IOException {

    ByteBuffer oByteBuffer = null;
    boolean bDone = false;

    while (!bDone) {
      try {
        int iBytesRead = oDataInputStream.read(mabRecord, 0, 2);

        if (iBytesRead == -1) {
          throw new EOFException("Reached End of File.");
        }

        int iLengthPayloadHi = (mabRecord[0] & 0xFF) << 8;
        int iLengthPayloadLo = mabRecord[1] & 0xFF;

        int iLengthPayload = iLengthPayloadHi + iLengthPayloadLo;

        int iAvailable = 0;
        int iNumRetries = 0;
        
        iAvailable = oDataInputStream.available();
        
        while(iAvailable < iLengthPayload - 2) {
          try {
            Thread.sleep( 10 );
            ++iNumRetries;
          }
          catch (InterruptedException e) {
            log4jDebugLogger.error("InterruptedException :  "+e.getMessage());
          }
                
          iAvailable = oDataInputStream.available();
                
          if(iNumRetries == 10){
            throw new IOException();
          }
        }

        if (iLengthPayload > 4) {

          iBytesRead = oDataInputStream.read( mabRecord, 2, iLengthPayload - 2 );

          if (iBytesRead == (iLengthPayload - 2)) {

            oByteBuffer = ByteBuffer.wrap( mabRecord );
            oByteBuffer.limit( iLengthPayload );

            int iFA = mabRecord[iLengthPayload - 2] & 0xFF;
            int iAE = mabRecord[iLengthPayload - 1] & 0xFF;

            if ( ( iFA == 0xFA ) && ( iAE == 0xAE ) ) {
              bDone = true;
            }
          }
        }

        if (!bDone) {
          log4jDebugLogger.error("\n=================================================================");
          log4jDebugLogger.error(" Record size '" + iLengthPayload + "' at offset '" + miDataOffset
                                 + "' does not match data,\n skipping to next EOR marker.");

          //if the actual log record size does not match the specified length,
          //then search the next 0xFAAE (EOR).
          boolean bFound = false;
          int     iBytesSkipped = iBytesRead + 2;

          byte[] abSkipBuffer = new byte[1];

          try {
            while (!bFound)  {
              oDataInputStream.read( abSkipBuffer, 0, 1);

              byte b1 = abSkipBuffer[0];           
              mabRecord[iBytesSkipped] = b1;
              iBytesSkipped++;
              if (b1 == (byte) 0xFA) {
                oDataInputStream.read( abSkipBuffer, 0, 1);
                byte b2 = abSkipBuffer[0];
                mabRecord[iBytesSkipped] = b2;

                iBytesSkipped++;

                if (b2 == (byte) 0xAE) {
                  bFound = true;
                }
              }
            }
          }
          catch (EOFException e) {
            log4jDebugLogger.debug("EOFException encountered for InputStream: " + oDataInputStream);
            bDone = true;
          }
          catch (IOException e)  {
            log4jDebugLogger.error("IOException encountered for InputStream: " + oDataInputStream);
            miErrorCount++;
          }
          
          log4jDebugLogger.error(" " + iBytesSkipped + " bytes discarded.");
          log4jDebugLogger.error("Skipped records: \n" + bin2Hex(mabRecord, iBytesSkipped));
          log4jDebugLogger.error("\n=================================================================");

          miDataOffset += iBytesSkipped;
          miSkipCount++;
        }
      }
      catch (IndexOutOfBoundsException e) {
        log4jDebugLogger.error("IndexOutOfBoundsException encountered for InputStream: "+oDataInputStream);
      }
    }
    return ( oByteBuffer );
  }



  /**
   * This method is invoked by the wrapper class CSLTool to run the ASCIIFilter.
   * @param oHashtableParameters the hashtable containing the command line
   * arguments and thier values
   */
  public void runASCIIFilter(Hashtable<String,String> oHashtableParameters,
    ArrayList<String> inputArrayListFiles) {

    Properties oProperties = new Properties();
    String ARG_CFG = "-cfg";
    String OUTPUTFILE_NAME = "OUTPUTFILE_NAME";
    String ARG_FORMAT = "-format";
    String FORMAT_XDRLITE = "xdrlite";
    String ARG_VERBOSE = "-verbose";
    String ASCIIFILTER_VERBOSE = "verbose";

    // Get the ASCII Filter config file.
    if (oHashtableParameters.containsKey(ARG_CFG)) {
      String szCfgFile = oHashtableParameters.get(ARG_CFG);
      oProperties.put(CFGFILE, szCfgFile);
    }
    else {
      //do nothing.Tool can function even without -cfg option.
    }

    // Get the output filename from the hash.
    if (oHashtableParameters.containsKey(OUTPUTFILE_NAME)) {
      String szOutputFile = oHashtableParameters.get(OUTPUTFILE_NAME);
      oProperties.put(OUTPUTFILE, szOutputFile);
    }

    // Get the format of the logs to be parsed. If not specified, the default
    // would be "xdrlite".
    if (oHashtableParameters.containsKey(ARG_FORMAT)) {
      String szFormat = oHashtableParameters.get(ARG_FORMAT);
      oProperties.put(FORMAT, szFormat);
    }
    else {
      oProperties.put(FORMAT, FORMAT_XDRLITE);
    }

    // Get the verbose option if specified.
    if (oHashtableParameters.containsKey(ARG_VERBOSE)) {
      oProperties.put(ASCIIFILTER_VERBOSE, "true");
      mVerbose = true;
    }

    // Iterate over input files and for each file, call the ascii parser
    // main method which does the parsing mechanism.
    for ( String szFilename : inputArrayListFiles ) {
      oProperties.put(INPUTFILE, szFilename);
      runStandAlone(oProperties);
    }

  }
  
  /**
   * parse binary records to Hex format
   * @param mabRecord
   * @param iLengthPayload
   * @return the Hex format records.
   */
  private String bin2Hex(byte [] mabRecord, int iLengthPayload) {
      StringBuffer szStringBuffer = new StringBuffer();
      for ( int i = 0 ; i < iLengthPayload ; ++i ) {
      if ( i % 16 == 0 ) {
          szStringBuffer.append( "\n" );
      }
      int iByte = (int) mabRecord[i] & 0xFF;
      if ( iByte < 16 ) {
          szStringBuffer.append( "0" );
      }
      
      String szByte = Integer.toHexString( iByte );
      szStringBuffer.append( szByte ).append(" ");
      }
      szStringBuffer.append( "\n" );
         
      return szStringBuffer.toString();
  }

}
